'use strict';
// ================================================================
//  共通名前空間 + 調整用パラメータ
//  挙動を変えたいときは基本ここの数値をいじればOK
// ================================================================
const MC = window.MC = {};

MC.CFG = {
  worldSize: 128,          // ワールド一辺(ブロック)
  fov: 70,                 // 縦FOV
  sensitivity: 0.5,        // マイクラ準拠(0..1, 0.5 = 100%)
  masterVolume: 1.0,

  // ---- プレイヤー ----
  eyeHeight: 1.62,
  eyeHeightSneak: 1.27,
  playerW: 0.6,
  playerH: 1.8,
  playerHSneak: 1.5,
  playerHGlide: 0.6,       // エリトラ滑空中(FALL_FLYING)は 0.6x0.6
  eyeHeightGlide: 0.4,
  // ---- リーチ(Java 1.21.11 の AttackRange / interaction range に準拠) ----
  // 目の位置から相手のヒットボックスまでの距離(視線方向のレイ)。min未満・max超は当たらない。
  // margin: ヒットボックスを全方向に広げる量 (プレイヤーの通常攻撃は 0)
  attackRange: {
    default: { min: 0, max: 3.0, margin: 0 },        // ENTITY_INTERACTION_RANGE = 3.0 (サバイバル)
    spear: { min: 2.0, max: 4.5, margin: 0.125 },    // スピアの attack_range コンポーネント
  },
  blockReach: 4.5,         // BLOCK_INTERACTION_RANGE (サバイバル)

  // ---- アイテム性能 ----
  windBurstVy: [1.14, 1.66, 2.09],     // メイス Wind Burst I/II/III の上向き速度(blocks/tick)。assetsのknockback_multiplier(1.2/1.75/2.2)に比例させた調整値 ≒ 7/14/21ブロック
  lungeImpulse: [0.6, 0.85, 1.1], // スピア Lunge I/II/III の加速量(視線方向)
  lungeHunger: [1, 2, 3],              // 消費する満腹度
  lungeMinFood: 6,
  windChargeKnock: 3.0,                // ウィンドチャージ爆風の強さ(自分用の調整値)
  windChargeRadius: 2.8,
  fireworkFlight: 3,                   // ロケットの飛行時間 Flight Duration(1〜3)。寿命 = 10×値 + rand(6) + rand(7) tick
  pearlCooldown: 20,                   // tick
  windChargeCooldown: 10,
  eatTicks: 32,

  // ---- 練習モード ----
  infiniteItems: true,     // 消費アイテムが減らない
  damagePlayer: false,     // 自分の体力が減る(Game Menuで切替)
  damageBot: false,        // Botの体力が減る(Game Menuで切替)
  npcAttacks: true,        // Botが戦う(false = 立っているだけ)
  botName: 'Bot',          // ヘルスネームタグの名前
  botRank: 'HT3',          // ヘルスネームタグのランク表示
  showNametag: true,       // ヘルスネームタグ表示
  botEatBelow: 8,          // Botがこの体力(半ハート単位=HP)以下で金リンゴを食べる
  showHitbox: true,        // ヒットボックス表示(Hキー)
  showDebug: true,         // F3 でも切替
};

MC.TICK = 1 / 20;
MC.DEG = Math.PI / 180;

// 防具ステータス(防御力表示 & ノックバック耐性用)
MC.ARMOR_POINTS = { head: 3, chest: 8, legs: 6, feet: 3 };
// ネザライト: 各部位 armor_toughness 3 / knockback_resistance 0.1。エリトラはどちらも 0
MC.ARMOR_TOUGHNESS = { head: 3, chest: 3, legs: 3, feet: 3 };

MC.rand = (a, b) => a + Math.random() * (b - a);
MC.randInt = (n) => Math.floor(Math.random() * n);
MC.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
MC.lerp = (a, b, t) => a + (b - a) * t;
MC.gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
