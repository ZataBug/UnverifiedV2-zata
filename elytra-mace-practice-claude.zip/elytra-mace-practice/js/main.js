'use strict';
// ================================================================
//  起動 / メインループ(20 TPS固定 + 描画は補間)
// ================================================================
(function () {
  const glCanvas = document.getElementById('gl');
  const guiCanvas = document.getElementById('gui');
  const GUI = MC.GUI;
  GUI.init(guiCanvas);

  let ready = false;
  const G = () => MC.Game;

  window.addEventListener('resize', () => { GUI.resize(); if (ready) MC.Render.resize(); });
  window.addEventListener('keydown', e => { if (ready) G().keyDown(e); });
  window.addEventListener('keyup', e => { if (ready) G().keyUp(e); });
  window.addEventListener('mousedown', e => {
    if (!ready) return;
    if (e.button === 1) e.preventDefault();
    G().mouseDown(e);
  });
  window.addEventListener('mouseup', e => { if (ready) G().mouseUp(e); });
  window.addEventListener('mousemove', e => { if (ready) G().mouseMove(e); });
  window.addEventListener('wheel', e => { if (ready) { e.preventDefault(); G().wheel(e); } }, { passive: false });
  window.addEventListener('contextmenu', e => e.preventDefault());
  window.addEventListener('blur', () => MC.Keys.down.clear());
  document.addEventListener('pointerlockchange', () => {
    if (!ready || !G().running) return;
    if (!document.pointerLockElement && GUI.screen === null) GUI.open('pause');
  });
  window.addEventListener('beforeunload', e => {
    if (ready && G().running) { e.preventDefault(); e.returnValue = ''; }
  });

  async function boot() {
    try {
      await MC.Assets.load(p => { GUI.loadProgress = p * 0.5; });
      await MC.Snd.init(p => { GUI.loadProgress = 0.5 + p * 0.5; });
      document.getElementById('cross').src = window.ASSET_DATA['textures/gui/sprites/hud/crosshair.png'];
      MC.Game.init();
      MC.Render.init(glCanvas);
      MC.Render.resize();
      ready = true;
      GUI.loaded = true;
    } catch (err) {
      console.error(err);
      GUI.error = String(err);
      document.getElementById('err').textContent = 'Error: ' + err;
    }
  }

  let last = performance.now(), acc = 0, fpsAcc = 0, fpsN = 0;
  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (ready) {
      const g = G();
      fpsAcc += dt; fpsN++;
      if (fpsAcc > 0.5) { g.fps = fpsN / fpsAcc; fpsAcc = 0; fpsN = 0; }
      let alpha = 1;
      if (g.running && !g.simPaused()) {
        acc += dt;
        let n = 0;
        while (acc >= 0.05 && n < 5) { g.tick(); MC.Render.Hand.tick(); acc -= 0.05; n++; }
        if (n === 5) acc = 0;
        alpha = acc / 0.05;
      } else acc = 0;
      MC.Render.frame(dt, alpha);
    }
    GUI.draw();
  }
  requestAnimationFrame(frame);
  boot();
})();
