'use strict';
// ================================================================
//  GUI (2Dキャンバス)  マイクラのGUI座標系(整数スケール)で描く
//   screen: null(ゲーム中) | 'start' | 'inventory' | 'keys' | 'pause'
// ================================================================
MC.GUI = {
  screen: 'start',
  scale: 3, W: 320, H: 240,
  mx: 0, my: 0,           // GUI座標のマウス位置
  hoverSlot: -1,
  buttons: [],
  drag: null,
  keyScroll: 0,
  listening: null,        // キー割り当て待ち中の action id
  loadProgress: 0, loaded: false,
  _glintCanvas: null,

  init(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.resize();
  },

  resize() {
    const dpr = window.devicePixelRatio || 1;
    const w = window.innerWidth, h = window.innerHeight;
    this.canvas.width = Math.floor(w * dpr); this.canvas.height = Math.floor(h * dpr);
    this.canvas.style.width = w + 'px'; this.canvas.style.height = h + 'px';
    this.dpr = dpr;
    // マイクラの「自動」GUIスケール
    let s = 1;
    while (s < 8 && Math.floor(w / (s + 1)) >= 320 && Math.floor(h / (s + 1)) >= 240) s++;
    this.scale = s;
    this.W = Math.ceil(w / s); this.H = Math.ceil(h / s);
    this.pxScale = s * dpr;
    const cr = document.getElementById('cross');
    if (cr) { cr.style.width = 15 * s + 'px'; cr.style.height = 15 * s + 'px'; }
  },

  toGui(e) { return [e.clientX / this.scale, e.clientY / this.scale]; },

  // ---------------------------------------------------------- 基本描画
  spr(path, x, y, w, h) {
    const im = MC.Assets.image(path);
    this.ctx.drawImage(im, x, y, w == null ? im.width : w, h == null ? im.height : h);
  },
  slice9(path, x, y, w, h, b) {
    const im = MC.Assets.image(path), c = this.ctx, iw = im.width, ih = im.height;
    c.drawImage(im, 0, 0, b, b, x, y, b, b);
    c.drawImage(im, iw - b, 0, b, b, x + w - b, y, b, b);
    c.drawImage(im, 0, ih - b, b, b, x, y + h - b, b, b);
    c.drawImage(im, iw - b, ih - b, b, b, x + w - b, y + h - b, b, b);
    c.drawImage(im, b, 0, iw - 2 * b, b, x + b, y, w - 2 * b, b);
    c.drawImage(im, b, ih - b, iw - 2 * b, b, x + b, y + h - b, w - 2 * b, b);
    c.drawImage(im, 0, b, b, ih - 2 * b, x, y + b, b, h - 2 * b);
    c.drawImage(im, iw - b, b, b, ih - 2 * b, x + w - b, y + b, b, h - 2 * b);
    c.drawImage(im, b, b, iw - 2 * b, ih - 2 * b, x + b, y + b, w - 2 * b, h - 2 * b);
  },
  rect(x, y, w, h, color) { this.ctx.fillStyle = color; this.ctx.fillRect(x, y, w, h); },
  text(s, x, y, color, shadow, sc) {
    if (sc && sc !== 1) { const c = this.ctx; c.save(); c.translate(x, y); c.scale(sc, sc); MC.Font.draw(c, s, 0, 0, color, shadow); c.restore(); }
    else MC.Font.draw(this.ctx, s, x, y, color, shadow);
  },
  textC(s, cx, y, color, shadow, sc) {
    sc = sc || 1; this.text(s, cx - Math.floor(MC.Font.width(s) * sc / 2), y, color, shadow, sc);
  },

  /** アイテムアイコン(16x16)。エンチャント光沢つき */
  item(stack, x, y, opts) {
    if (!stack) return;
    const d = MC.ITEMS[stack.id], c = this.ctx;
    const im = MC.Assets.image(d.tex);
    if (d.glint) {
      if (!this._gc) { this._gc = document.createElement('canvas'); this._gc.width = this._gc.height = 16; this._gx = this._gc.getContext('2d'); this._gx.imageSmoothingEnabled = false; this._glintTint = null; }
      const g = this._gx;
      g.clearRect(0, 0, 16, 16);
      g.globalCompositeOperation = 'source-over';
      g.drawImage(im, 0, 0, 16, 16);
      g.globalCompositeOperation = 'source-atop';
      if (!this._glintTint) {
        const gi = MC.Assets.image('misc/enchanted_glint_item');
        const t = document.createElement('canvas'); t.width = t.height = 128;
        const tx = t.getContext('2d'); tx.drawImage(gi, 0, 0);
        tx.globalCompositeOperation = 'multiply'; tx.fillStyle = '#a060ff'; tx.fillRect(0, 0, 128, 128);
        tx.globalCompositeOperation = 'destination-in'; tx.drawImage(gi, 0, 0);
        this._glintTint = t;
      }
      const t = performance.now() / 1000, s = 32;
      const ox = -((t * 6) % s), oy = (t * 2.5) % s;
      g.globalAlpha = 0.75;
      for (let i = 0; i < 3; i++) for (let j = -1; j < 2; j++) g.drawImage(this._glintTint, ox + i * s, oy + j * s - s / 2, s, s);
      g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
      c.drawImage(this._gc, x, y);
    } else c.drawImage(im, x, y, 16, 16);
    if (stack.count > 1 && !(opts && opts.noCount)) {
      const s = String(stack.count);
      MC.Font.draw(c, s, x + 19 - 2 - MC.Font.width(s), y + 6 + 3, '#FFFFFF', true);
    }
    const G = MC.Game;
    if (G && G.cooldownFrac) {
      const f = G.cooldownFrac(stack.id);
      if (f > 0) { const h = Math.ceil(16 * f); this.rect(x, y + 16 - h, 16, h, 'rgba(255,255,255,0.5)'); }
    }
  },

  tooltip(stack, mx, my) {
    const lines = MC.Item.tooltip(stack);
    let w = 0; for (const l of lines) w = Math.max(w, MC.Font.width(l[0]));
    let h = 8; if (lines.length > 1) h += 2 + (lines.length - 1) * 10;
    let x = mx + 12, y = my - 12;
    if (x + w + 8 > this.W) x = mx - 12 - w - 8;
    if (y + h + 6 > this.H) y = this.H - h - 6;
    if (y < 4) y = 4;
    const c = this.ctx;
    c.fillStyle = 'rgba(16,0,16,0.94)';
    c.fillRect(x - 3, y - 4, w + 6, h + 8);
    c.fillStyle = '#5000ff';
    c.fillRect(x - 3, y - 3, w + 6, 1); c.fillRect(x - 3, y + h + 2, w + 6, 1); c.fillRect(x - 3, y - 3, 1, h + 6); c.fillRect(x + w + 2, y - 3, 1, h + 6);
    let yy = y;
    lines.forEach((l, i) => { MC.Font.draw(c, l[0], x, yy, l[1], true); yy += i === 0 ? 12 : 10; });
  },

  button(x, y, w, label, onClick, opts) {
    opts = opts || {};
    const hover = !opts.disabled && this.mx >= x && this.mx < x + w && this.my >= y && this.my < y + 20;
    const sp = opts.disabled ? 'gui/sprites/widget/button_disabled' : hover ? 'gui/sprites/widget/button_highlighted' : 'gui/sprites/widget/button';
    this.slice9('textures/' + sp.replace('gui/', 'gui/') + '.png', x, y, w, 20, 3);
    this.textC(label, x + w / 2, y + 6, opts.disabled ? '#A0A0A0' : (opts.color || (hover ? '#FFFFA0' : '#FFFFFF')), true);
    this.buttons.push({ x, y, w, h: 20, onClick, disabled: opts.disabled });
  },
  slider(x, y, w, label, v, onChange) {
    const hover = this.mx >= x && this.mx < x + w && this.my >= y && this.my < y + 20;
    this.slice9('textures/gui/sprites/widget/slider' + (hover || (this.drag && this.drag.onChange === onChange) ? '_highlighted' : '') + '.png', x, y, w, 20, 1);
    const hx = x + Math.round((w - 8) * v);
    this.spr('gui/sprites/widget/slider_handle' + (hover ? '_highlighted' : ''), hx, y, 8, 20);
    this.textC(label, x + w / 2, y + 6, '#FFFFFF', true);
    this.buttons.push({ x, y, w, h: 20, slider: true, onChange });
  },
  tiledBg(alpha) {
    this.rect(0, 0, this.W + 1, this.H + 1, '#2b2b2b');
    const im = MC.Assets.image('gui/menu_background'), c = this.ctx;
    const pat = c.createPattern(im, 'repeat');
    c.save(); c.scale(2, 2); c.fillStyle = pat; c.globalAlpha = alpha == null ? 1 : alpha; c.fillRect(0, 0, this.W / 2 + 1, this.H / 2 + 1); c.restore();
    c.fillStyle = 'rgba(0,0,0,0.6)'; c.fillRect(0, 0, this.W, this.H);
  },

  // ---------------------------------------------------------- メイン
  draw() {
    const c = this.ctx, G = MC.Game;
    c.setTransform(this.pxScale, 0, 0, this.pxScale, 0, 0);
    c.imageSmoothingEnabled = false;
    c.clearRect(0, 0, this.W + 1, this.H + 1);
    this.buttons = [];
    const cross = document.getElementById('cross');
    if (this.screen === 'start') { this.drawStart(); if (cross) cross.style.display = 'none'; return; }
    this.drawHud();
    if (cross) cross.style.display = this.screen ? 'none' : 'block';
    if (this.screen === 'inventory') this.drawInventory();
    else if (this.screen === 'pause') this.drawPause();
    else if (this.screen === 'keys') this.drawKeys();
  },

  drawStart() {
    if (!MC.Assets.ready) {
      this.rect(0, 0, this.W + 1, this.H + 1, '#202020');
      const bw = 200, bx = this.W / 2 - bw / 2, by = this.H / 2;
      this.rect(bx, by, bw, 6, '#444444'); this.rect(bx, by, bw * this.loadProgress, 6, '#55FF55');
      return;
    }
    this.tiledBg(1);
    this.textC('Elytra Mace Practice', this.W / 2, this.H / 2 - 50, '#FFFFFF', true, 3);
    this.textC('Minecraft Java 1.21.11 style  -  128x128 grass world', this.W / 2, this.H / 2 - 18, '#AAAAAA', true);
    const bw = 200, bx = this.W / 2 - bw / 2, by = this.H / 2 + 6;
    if (!this.loaded) {
      this.rect(bx, by + 6, bw, 6, '#222222');
      this.rect(bx, by + 6, bw * this.loadProgress, 6, '#55FF55');
      this.textC('Loading...', this.W / 2, by + 20, '#FFFFFF', true);
    } else {
      this.button(bx, by, bw, 'Click to Play', () => MC.Game.startPlaying());
      this.textC('WASD move / Mouse look / E inventory / R reset', this.W / 2, by + 34, '#AAAAAA', true);
    }
  },

  drawHud() {
    const G = MC.Game, c = this.ctx, W = this.W, H = this.H, cx = Math.floor(W / 2);
    const inv = MC.Inventory;
    // 被ダメージ表示
    if (G.hurtFlash > 0.01) this.rect(0, 0, W + 1, H + 1, 'rgba(255,0,0,' + (0.3 * G.hurtFlash).toFixed(3) + ')');

    // 攻撃インジケータ
    if (!this.screen) {
      const p = G.attackProgress();
      if (p < 1) {
        const ix = cx - 8, iy = Math.floor(H / 2) - 7 + 16;
        this.spr('gui/sprites/hud/crosshair_attack_indicator_background', ix, iy, 16, 4);
        c.drawImage(MC.Assets.image('gui/sprites/hud/crosshair_attack_indicator_progress'), 0, 0, Math.ceil(16 * p), 4, ix, iy, Math.ceil(16 * p), 4);
      }
    }

    // ホットバー
    const hy = H - 22;
    this.spr('gui/sprites/hud/hotbar', cx - 91, hy, 182, 22);
    this.spr('gui/sprites/hud/hotbar_selection', cx - 91 - 1 + inv.selected * 20, hy - 1, 24, 23);
    for (let i = 0; i < 9; i++) this.item(inv.slots[i], cx - 90 + i * 20 + 2, H - 19);
    // オフハンド
    this.spr('gui/sprites/hud/hotbar_offhand_left', cx - 91 - 29, H - 23, 29, 24);
    this.item(inv.slots[inv.OFF], cx - 91 - 26, H - 19);

    // ハート(実際の体力。半ハート単位) / 吸収 / 防具 / 空腹
    const hp = Math.max(0, Math.ceil(G.P.hp)), absorb = Math.ceil(G.absorption / 2);
    for (let i = 0; i < 10; i++) {
      const x = cx - 91 + i * 8, y = H - 39 + (hp <= 4 && G.tickCount % 4 === i % 4 ? -1 : 0);
      this.spr('gui/sprites/hud/heart/container', x, y, 9, 9);
      if (i * 2 + 1 < hp) this.spr('gui/sprites/hud/heart/full', x, y, 9, 9);
      else if (i * 2 + 1 === hp) this.spr('gui/sprites/hud/heart/half', x, y, 9, 9);
    }
    for (let i = 0; i < absorb; i++) {
      const x = cx - 91 + i * 8, y = H - 49;
      const half = (i === absorb - 1) && (G.absorption % 2 === 1);
      this.spr('gui/sprites/hud/heart/' + (half ? 'absorbing_half' : 'absorbing_full'), x, y, 9, 9);
    }
    const ap = inv.armorPoints();
    if (ap > 0) {
      const y = H - 49 - (absorb > 0 ? 10 : 0);
      for (let i = 0; i < 10; i++) {
        const x = cx - 91 + i * 8, v = i * 2 + 1;
        this.spr('gui/sprites/hud/armor_' + (v < ap ? 'full' : v === ap ? 'half' : 'empty'), x, y, 9, 9);
      }
    }
    const food = Math.ceil(G.food);
    for (let i = 0; i < 10; i++) {
      const x = cx + 91 - 9 - i * 8, y = H - 39, v = i * 2 + 1;
      this.spr('gui/sprites/hud/food_empty', x, y, 9, 9);
      if (v < food) this.spr('gui/sprites/hud/food_full', x, y, 9, 9); else if (v === food) this.spr('gui/sprites/hud/food_half', x, y, 9, 9);
    }

    // 持ち替え時のアイテム名
    if (G.nameTimer > 0 && inv.held()) {
      const a = Math.min(1, G.nameTimer / 10 * 1);
      const t = MC.Item.tooltip(inv.held())[0];
      c.globalAlpha = a;
      this.textC(t[0], cx, H - 59 - (absorb > 0 || ap > 0 ? 0 : -10), t[1], true);
      c.globalAlpha = 1;
    }

    // チャット(ログ)
    let y = H - 62;
    for (let i = G.msgs.length - 1; i >= 0; i--) {
      const m = G.msgs[i];
      const age = (performance.now() - m.t) / 1000;
      if (age > 8 && !this.screen) continue;
      const al = this.screen ? 1 : MC.clamp(1 - (age - 6) / 2, 0, 1);
      c.globalAlpha = al;
      this.rect(2, y - 1, MC.Font.width(m.text) + 4, 10, 'rgba(0,0,0,0.4)');
      this.text(m.text, 4, y, m.color || '#FFFFFF', true);
      c.globalAlpha = 1;
      y -= 10;
      if (y < 40) break;
    }

    // デバッグ
    if (MC.CFG.showDebug) {
      const L = G.debugLines();
      L.forEach((s, i) => { const w = MC.Font.width(s); this.rect(1, 1 + i * 10, w + 2, 9, 'rgba(0,0,0,0.45)'); this.text(s, 2, 2 + i * 10, '#E0E0E0', false); });
    }
  },

  // ---------------------------------------------------------- インベントリ
  drawInventory() {
    const G = MC.Game, inv = MC.Inventory, c = this.ctx;
    this.rect(0, 0, this.W + 1, this.H + 1, 'rgba(0,0,0,0.6)');
    const ox = Math.floor((this.W - 176) / 2), oy = Math.floor((this.H - 166) / 2);
    c.drawImage(MC.Assets.image('gui/container/inventory'), 0, 0, 176, 166, ox, oy, 176, 166);
    this.text('Crafting', ox + 97, oy + 8, '#404040', false);
    // スロット配置
    const S = [];
    for (let k = 0; k < 4; k++) S.push([39 - k, 8, 8 + k * 18]);
    S.push([40, 77, 62]);
    for (let k = 0; k < 4; k++) S.push([41 + k, 98 + (k % 2) * 18, 18 + (k >> 1) * 18]);
    for (let r = 0; r < 3; r++) for (let q = 0; q < 9; q++) S.push([9 + r * 9 + q, 8 + q * 18, 84 + r * 18]);
    for (let q = 0; q < 9; q++) S.push([q, 8 + q * 18, 142]);
    const emptyIcon = { 39: 'helmet', 38: 'chestplate', 37: 'leggings', 36: 'boots', 40: 'shield' };
    this.hoverSlot = -1;
    for (const [i, sx, sy] of S) {
      const x = ox + sx, y = oy + sy;
      if (!inv.slots[i] && emptyIcon[i]) this.spr('gui/sprites/container/slot/' + emptyIcon[i], x, y, 16, 16);
      this.item(inv.slots[i], x, y);
      if (this.mx >= x && this.mx < x + 16 && this.my >= y && this.my < y + 16) this.hoverSlot = i;
    }
    // 選択中ホットバーの目印
    // プレイヤー表示
    const pv = MC.Preview.render(this.mx - (ox + 51), this.my - (oy + 8 + 38));
    if (pv) c.drawImage(pv, ox + 26, oy + 8, 49, 70);
    // ホバー枠
    if (this.hoverSlot >= 0) {
      const f = S.find(s => s[0] === this.hoverSlot);
      c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(ox + f[1], oy + f[2], 16, 16);
    }
    // 操作ボタン
    this.button(ox + 176 + 6, oy, 90, 'Controls...', () => this.open('keys'));
    this.button(ox + 176 + 6, oy + 24, 90, 'Game Menu', () => this.open('pause'));
    // カーソルが持つアイテム
    if (inv.cursor) this.item(inv.cursor, this.mx - 8, this.my - 8);
    else if (this.hoverSlot >= 0 && inv.slots[this.hoverSlot]) this.tooltip(inv.slots[this.hoverSlot], this.mx, this.my);
  },

  // ---------------------------------------------------------- 一時停止
  drawPause() {
    const G = MC.Game, cfg = MC.CFG;
    this.rect(0, 0, this.W + 1, this.H + 1, 'rgba(0,0,0,0.6)');
    const cx = this.W / 2, y0 = Math.floor(this.H / 2) - 70;
    this.textC('Game Menu', cx, y0 - 22, '#FFFFFF', true);
    this.button(cx - 155, y0, 310, 'Back to Game', () => G.closeScreen());
    this.slider(cx - 155, y0 + 28, 150, 'Sensitivity: ' + Math.round(cfg.sensitivity * 200) + '%', cfg.sensitivity, v => { cfg.sensitivity = v; G.saveSettings(); });
    this.slider(cx + 5, y0 + 28, 150, 'FOV: ' + Math.round(cfg.fov), (cfg.fov - 30) / 80, v => { cfg.fov = Math.round(30 + v * 80); G.saveSettings(); });
    this.slider(cx - 155, y0 + 52, 150, 'Volume: ' + Math.round(cfg.masterVolume * 100) + '%', cfg.masterVolume, v => { cfg.masterVolume = v; MC.Snd.setMaster(v); G.saveSettings(); });
    this.button(cx + 5, y0 + 52, 150, 'Infinite Items: ' + (cfg.infiniteItems ? 'ON' : 'OFF'), () => { cfg.infiniteItems = !cfg.infiniteItems; G.saveSettings(); });
    this.button(cx - 155, y0 + 76, 150, 'Bot: ' + (cfg.npcAttacks ? 'Fight' : 'Idle'), () => { cfg.npcAttacks = !cfg.npcAttacks; G.saveSettings(); });
    this.button(cx + 5, y0 + 76, 150, 'Reset Positions', () => { G.resetPositions(); G.closeScreen(); });
    this.button(cx - 155, y0 + 100, 150, 'Your Damage: ' + (cfg.damagePlayer ? 'ON' : 'OFF'), () => { cfg.damagePlayer = !cfg.damagePlayer; G.saveSettings(); });
    this.button(cx + 5, y0 + 100, 150, 'Bot Damage: ' + (cfg.damageBot ? 'ON' : 'OFF'), () => { cfg.damageBot = !cfg.damageBot; G.saveSettings(); });
    this.button(cx - 155, y0 + 124, 150, 'Health Nametag: ' + (cfg.showNametag ? 'ON' : 'OFF'), () => { cfg.showNametag = !cfg.showNametag; G.saveSettings(); });
    this.button(cx + 5, y0 + 124, 150, 'Reset Inventory', () => { G.resetInventory(); });
    this.button(cx - 155, y0 + 148, 310, 'Controls...', () => this.open('keys'));
  },

  // ---------------------------------------------------------- キー設定
  drawKeys() {
    const K = MC.Keys, cx = this.W / 2;
    this.tiledBg(1);
    this.textC('Controls', cx, 12, '#FFFFFF', true);
    const top = 30, bottom = this.H - 32, rowH = 24;
    const defs = K.defs;
    const total = defs.length * rowH;
    this.keyScroll = MC.clamp(this.keyScroll, 0, Math.max(0, total - (bottom - top)));
    const c = this.ctx;
    c.save(); c.beginPath(); c.rect(0, top, this.W, bottom - top); c.clip();
    // 衝突検出
    const used = {};
    for (const d of defs) { const code = K.bind[d.id]; if (code) (used[code] = used[code] || []).push(d.id); }
    defs.forEach((d, i) => {
      const y = top + i * rowH - this.keyScroll;
      if (y < top - rowH || y > bottom) return;
      this.text(d.label, cx - 155, y + 6, '#FFFFFF', true);
      const code = K.bind[d.id], conflict = code && used[code].length > 1;
      const listening = this.listening === d.id;
      let label = listening ? '> ' + K.label(code) + ' <' : K.label(code);
      this.button(cx + 5, y, 100, label, () => { this.listening = d.id; }, { color: listening ? '#FFFF55' : conflict ? '#FF5555' : '#FFFFFF' });
      this.button(cx + 109, y, 46, 'Reset', () => { K.bind[d.id] = d.def; K.save(); }, { disabled: K.bind[d.id] === d.def });
    });
    c.restore();
    this.rect(0, top - 1, this.W, 1, '#000000'); this.rect(0, bottom, this.W, 1, '#000000');
    this.button(cx - 155, this.H - 26, 100, 'Reset All', () => { for (const d of defs) K.bind[d.id] = d.def; K.save(); });
    this.button(cx + 5, this.H - 26, 150, 'Done', () => this.back());
    if (this.listening) this.textC('Press a key or mouse button  (Esc = cancel)', cx, this.H - 40 + 0, '#FFFF55', true);
  },

  // ---------------------------------------------------------- 画面遷移 / 入力
  open(name) { this.prev = this.screen === 'keys' ? this.prev : this.screen; this.screen = name; this.listening = null; MC.Game.onScreenChange(); },
  back() { const p = this.prev && this.prev !== 'keys' ? this.prev : null; this.listening = null; this.screen = p === 'start' ? 'pause' : p; MC.Game.onScreenChange(); },

  mouseDown(e) {
    [this.mx, this.my] = this.toGui(e);
    if (this.listening) {
      MC.Keys.set(this.listening, 'Mouse' + e.button); this.listening = null; return;
    }
    for (const b of this.buttons) {
      if (this.mx >= b.x && this.mx < b.x + b.w && this.my >= b.y && this.my < b.y + b.h) {
        if (b.disabled || e.button !== 0) return;
        MC.Snd.play('ui.button.click', { vol: 0.25 });
        if (b.slider) { this.drag = b; this._slide(b); } else b.onClick();
        return;
      }
    }
    if (this.screen === 'inventory' && this.hoverSlot >= 0 && (e.button === 0 || e.button === 2)) {
      MC.Inventory.click(this.hoverSlot, e.button === 2 ? 1 : 0, e.shiftKey);
    }
  },
  mouseUp() { this.drag = null; },
  mouseMove(e) {
    [this.mx, this.my] = this.toGui(e);
    if (this.drag) this._slide(this.drag);
  },
  _slide(b) { b.onChange(MC.clamp((this.mx - b.x - 4) / (b.w - 8), 0, 1)); },
  wheel(e) { if (this.screen === 'keys') this.keyScroll += Math.sign(e.deltaY) * 12; },
};
