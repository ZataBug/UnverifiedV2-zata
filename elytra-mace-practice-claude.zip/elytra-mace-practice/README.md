# Elytra Mace Practice (Minecraft Java 1.21.11 風)

## 遊び方
`index.html` をダブルクリックでChromeなどで開き、「Click to Play」。サーバー不要・オフライン動作。

| 操作 | 初期キー(変更可) |
|---|---|
| 移動 | W/A/S/D(**常に視点の向き基準**) |
| ジャンプ / 空中で再度押すとエリトラ展開 | Space |
| スプリント / スニーク | Ctrl(またはWダブルタップ) / Shift |
| 攻撃 / 使う | 左クリック / 右クリック(長押し対応) |
| インベントリ | E |
| オフハンド入れ替え | F |
| 位置リセット | R |
| デバッグ表示(落下距離など) | F3 |
| ホットバー | 1〜9 / ホイール |

※ Ctrl+W はブラウザのタブを閉じます。気になる場合は インベントリ→Controls で Sprint を別キーに変更してください(閉じようとしたら確認ダイアログは出ます)。

キー設定: インベントリ(E)右の「Controls...」、またはEsc→Game Menu。クリックして新しいキー/マウスボタンを押すだけ。重複は赤字、Resetで戻せます。設定は保存されます。

## ホットバー初期構成
Mace(Wind Burst III) / Elytra / Netherite Spear(Lunge III) / Ender Pearl / Wind Charge / Netherite Axe / Netherite Sword / Golden Apple / Firework Rocket。ネザライト防具装備済み。
エリトラ・チェストプレートは手に持って右クリックで入れ替え。インベントリ内のクリック/Shiftクリック/数字キー入れ替えもマイクラ準拠。

## 仕様メモ
- 128x128の草ワールド。端は見えない壁(近づくと青い格子)で出られません。ブロック判定は通常のボクセル衝突。
- ダメージは受けません(ノックバック・被弾音・赤フラッシュのみ)。NPCも同様。Esc→Game Menu の「NPC Attacks」でNPCが殴ってきます。
- メイス: 落下距離>1.5(滑空中は不可)でスマッシュ。ダメージ内訳はチャット欄に表示。Wind Burst IIIで約20ブロック打ち上がります。
- エリトラ滑空中は落下距離が1に抑えられ、急降下(縦速度が-0.5 b/tick超)でのみ加算されます(バニラ準拠)。エリトラを外すとスマッシュ可能。
- アイテムは無限(Game Menuで切替可)。Lunge=満腹度3消費(満腹度6未満では不可)。

## 調整
`js/config.js` に Wind Burst の高さ、Lunge の勢い、花火の飛行時間(fireworkFlight)、ウィンドチャージの強さなどがあります。値の一部は実機とのズレがあり得るので、気になる所はここで調整してください。

## 軽量化とアイテムの追加
使う素材だけ `assets/` に入っています(約1.7MB)。元のパックは別途お持ちのzipを使います。
新アイテムを足すには:
1. `js/items.js` に定義を追加
2. `assets_manifest.json` に必要なテクスチャ/サウンドイベントを追加
3. `python tools/sync_assets.py <元のアセットzip>` を実行(`assets/` に必要分をコピーし `assets_data.js` を再生成。`--prune` で不要分を削除)

挙動が必要なアイテムは `js/game.js` の `useItem` / `attack` にも処理が要ります(「これを追加して」と頼んでくれれば対応します)。
