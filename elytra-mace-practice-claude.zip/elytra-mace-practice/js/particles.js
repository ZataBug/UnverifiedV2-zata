'use strict';
// ================================================================
//  パーティクル: 1ドローコールのインスタンス描画ビルボード
//  アトラス(32x32セル)に使うテクスチャを並べ、アニメは連番フレームで進める
// ================================================================
MC.Particles = {
  MAX: 2500,
  cell: 32, cols: 16,
  index: {},          // 名前 -> セル番号
  list: [],

  init(scene) {
    const A = MC.Assets;
    const names = [];
    const add = (n) => names.push(n);
    for (let i = 0; i < 12; i++) add('particle/gust_' + i);
    for (let i = 0; i < 7; i++) add('particle/small_gust_' + i);
    for (let i = 0; i < 8; i++) add('particle/generic_' + i);
    for (let i = 0; i < 8; i++) add('particle/spark_' + i);
    for (let i = 0; i < 8; i++) add('particle/sweep_' + i);
    add('particle/critical_hit'); add('particle/damage'); add('particle/flame');
    add('block/dirt'); add('block/grass_block_top'); add('item/golden_apple');

    const cv = document.createElement('canvas');
    cv.width = this.cols * this.cell; cv.height = Math.ceil(names.length / this.cols) * this.cell;
    const cx = cv.getContext('2d'); cx.imageSmoothingEnabled = false;
    names.forEach((n, i) => {
      const im = A.image(n);
      const x = (i % this.cols) * this.cell, y = Math.floor(i / this.cols) * this.cell;
      cx.drawImage(im, x, y, this.cell, this.cell);
      this.index[n] = i;
    });
    this.atlasW = cv.width; this.atlasH = cv.height;
    const tex = new THREE.CanvasTexture(cv);
    tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false;

    const base = new THREE.PlaneGeometry(1, 1);
    const g = new THREE.InstancedBufferGeometry();
    g.index = base.index;
    g.setAttribute('position', base.getAttribute('position'));
    g.setAttribute('uv', base.getAttribute('uv'));
    const M = this.MAX;
    this.aPos = new THREE.InstancedBufferAttribute(new Float32Array(M * 3), 3); this.aPos.setUsage(THREE.DynamicDrawUsage);
    this.aSize = new THREE.InstancedBufferAttribute(new Float32Array(M), 1); this.aSize.setUsage(THREE.DynamicDrawUsage);
    this.aCol = new THREE.InstancedBufferAttribute(new Float32Array(M * 4), 4); this.aCol.setUsage(THREE.DynamicDrawUsage);
    this.aUV = new THREE.InstancedBufferAttribute(new Float32Array(M * 4), 4); this.aUV.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('iPos', this.aPos); g.setAttribute('iSize', this.aSize);
    g.setAttribute('iCol', this.aCol); g.setAttribute('iUV', this.aUV);
    g.instanceCount = 0;
    const mat = new THREE.ShaderMaterial({
      uniforms: { map: { value: tex } },
      transparent: true, depthWrite: false, side: THREE.DoubleSide,
      vertexShader: `
        attribute vec3 iPos; attribute float iSize; attribute vec4 iCol; attribute vec4 iUV;
        varying vec2 vUv; varying vec4 vCol;
        void main(){
          vec3 right = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
          vec3 up = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
          vec3 p = iPos + (right * position.x + up * position.y) * iSize;
          vUv = iUV.xy + uv * iUV.zw; vCol = iCol;
          gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
        }`,
      fragmentShader: `
        uniform sampler2D map; varying vec2 vUv; varying vec4 vCol;
        void main(){ vec4 c = texture2D(map, vUv) * vCol; if (c.a < 0.04) discard; gl_FragColor = c; }`,
    });
    this.mesh = new THREE.Mesh(g, mat);
    this.mesh.frustumCulled = false; this.mesh.renderOrder = 10;
    scene.add(this.mesh);
    this.geo = g;
  },

  /**
   * 1個スポーン
   * o: { name|frames:[names], pos:[x,y,z], vel:[x,y,z], size, life(tick), grav, drag, color:[r,g,b], alpha,
   *      fade:true, shrink:true, sub:[u,v,w,h] (0..1 のテクスチャ切り出し), anim:true (framesを寿命で再生), spin }
   */
  spawn(o) {
    if (this.list.length >= this.MAX) this.list.shift();
    const frames = o.frames || [o.name];
    const p = {
      x: o.pos[0], y: o.pos[1], z: o.pos[2],
      vx: o.vel ? o.vel[0] : 0, vy: o.vel ? o.vel[1] : 0, vz: o.vel ? o.vel[2] : 0,
      size: o.size == null ? 0.1 : o.size, life: o.life || 20, age: 0,
      grav: o.grav || 0, drag: o.drag == null ? 0.98 : o.drag,
      col: o.color || [1, 1, 1], alpha: o.alpha == null ? 1 : o.alpha,
      fade: !!o.fade, shrink: !!o.shrink, sub: o.sub || null, frames, anim: !!o.anim,
      ground: o.ground !== false, bright: o.bright,
    };
    this.list.push(p);
    return p;
  },

  /** 毎フレーム: dt は秒 */
  update(dt, world) {
    const t = dt * 20;              // tick換算
    const L = this.list;
    let w = 0;
    const cs = this.cell / this.atlasW, ch = this.cell / this.atlasH;
    for (let i = 0; i < L.length; i++) {
      const p = L[i];
      p.age += t;
      if (p.age >= p.life) continue;
      p.vy -= p.grav * 0.04 * t;
      const dr = Math.pow(p.drag, t);
      p.vx *= dr; p.vy *= dr; p.vz *= dr;
      p.x += p.vx * t; p.y += p.vy * t; p.z += p.vz * t;
      if (p.ground && p.y < 0.02) { p.y = 0.02; p.vy = 0; p.vx *= 0.7; p.vz *= 0.7; }
      L[w++] = p;
    }
    L.length = w;
    const n = Math.min(w, this.MAX);
    const aP = this.aPos.array, aS = this.aSize.array, aC = this.aCol.array, aU = this.aUV.array;
    for (let i = 0; i < n; i++) {
      const p = L[i];
      const f = p.age / p.life;
      aP[i * 3] = p.x; aP[i * 3 + 1] = p.y; aP[i * 3 + 2] = p.z;
      aS[i] = p.size * (p.shrink ? (1 - f * f) : 1);
      aC[i * 4] = p.col[0]; aC[i * 4 + 1] = p.col[1]; aC[i * 4 + 2] = p.col[2];
      aC[i * 4 + 3] = p.alpha * (p.fade ? 1 - f : 1);
      let name = p.frames[0];
      if (p.anim) name = p.frames[Math.min(p.frames.length - 1, Math.floor(f * p.frames.length))];
      const idx = this.index[name];
      const cx = (idx % this.cols) * cs, cy = 1 - (Math.floor(idx / this.cols) + 1) * ch;
      if (p.sub) { aU[i * 4] = cx + p.sub[0] * cs; aU[i * 4 + 1] = cy + (1 - p.sub[1] - p.sub[3]) * ch; aU[i * 4 + 2] = p.sub[2] * cs; aU[i * 4 + 3] = p.sub[3] * ch; }
      else { aU[i * 4] = cx; aU[i * 4 + 1] = cy; aU[i * 4 + 2] = cs; aU[i * 4 + 3] = ch; }
    }
    this.geo.instanceCount = n;
    this.aPos.needsUpdate = this.aSize.needsUpdate = this.aCol.needsUpdate = this.aUV.needsUpdate = true;
  },

  // ----------------------------------------------------------------
  //  エフェクト集
  // ----------------------------------------------------------------
  /** 突風(ウィンドチャージ/ウィンドバースト)。large=true でメイス用の大きい渦 */
  gust(x, y, z, large) {
    const frames = [];
    const n = large ? 12 : 7;
    for (let i = 0; i < n; i++) frames.push((large ? 'particle/gust_' : 'particle/small_gust_') + i);
    const count = large ? 5 : 3;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2, r = large ? MC.rand(0, 1.6) : MC.rand(0, 0.8);
      this.spawn({ frames, anim: true, pos: [x + Math.cos(a) * r, y + MC.rand(0, large ? 0.8 : 0.4), z + Math.sin(a) * r],
        size: large ? MC.rand(1.6, 2.6) : MC.rand(0.9, 1.5), life: (large ? 12 : 9) + MC.randInt(4), grav: 0, drag: 1, ground: false, alpha: 0.95 });
    }
  },
  portal(x, y, z, n) {
    for (let i = 0; i < n; i++) {
      const c = MC.rand(0.5, 1);
      this.spawn({ frames: ['particle/generic_' + MC.randInt(8)], pos: [x + MC.rand(-0.4, 0.4), y + MC.rand(0, 1.8), z + MC.rand(-0.4, 0.4)],
        vel: [MC.rand(-0.2, 0.2), MC.rand(-0.15, 0.15), MC.rand(-0.2, 0.2)], size: MC.rand(0.06, 0.14), life: 18 + MC.randInt(14),
        color: [c * 0.55, c * 0.2, c], drag: 0.92, grav: -0.2, shrink: true, ground: false });
    }
  },
  crit(x, y, z, n) {
    for (let i = 0; i < n; i++) {
      this.spawn({ name: 'particle/critical_hit', pos: [x, y, z], vel: [MC.rand(-0.35, 0.35), MC.rand(0, 0.35), MC.rand(-0.35, 0.35)],
        size: MC.rand(0.1, 0.16), life: 12 + MC.randInt(6), grav: 0.5, drag: 0.9, color: [0.9, 0.78, 0.55], shrink: true, ground: false });
    }
  },
  hearts(x, y, z, n) {
    for (let i = 0; i < n; i++) {
      this.spawn({ name: 'particle/damage', pos: [x + MC.rand(-0.3, 0.3), y, z + MC.rand(-0.3, 0.3)], vel: [MC.rand(-0.1, 0.1), MC.rand(0.08, 0.2), MC.rand(-0.1, 0.1)],
        size: 0.14, life: 22, grav: 0.05, drag: 0.95, fade: true, ground: false });
    }
  },
  sweep(x, y, z) {
    const frames = []; for (let i = 0; i < 8; i++) frames.push('particle/sweep_' + i);
    this.spawn({ frames, anim: true, pos: [x, y, z], size: 1.0, life: 6, drag: 1, ground: false });
  },
  /** ブロック破片(メイスの地面叩きつけ) */
  dust(x, y, z, n, power) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = MC.rand(0.1, 0.45) * power;
      const green = Math.random() < 0.6;
      this.spawn({ name: green ? 'block/grass_block_top' : 'block/dirt', sub: [MC.randInt(3) / 4, MC.randInt(3) / 4, 0.25, 0.25],
        pos: [x + Math.cos(a) * MC.rand(0.2, 1.4), y + 0.05, z + Math.sin(a) * MC.rand(0.2, 1.4)],
        vel: [Math.cos(a) * s * 0.5, MC.rand(0.15, 0.5) * power, Math.sin(a) * s * 0.5],
        size: MC.rand(0.07, 0.13), life: 26 + MC.randInt(14), grav: 1, drag: 0.96, color: green ? [0.57, 0.74, 0.35] : [0.7, 0.55, 0.45] });
    }
  },
  spark(x, y, z, vx, vy, vz) {
    const frames = []; for (let i = 7; i >= 0; i--) frames.push('particle/spark_' + i);
    this.spawn({ frames, anim: true, pos: [x, y, z], vel: [vx, vy, vz], size: 0.13, life: 14 + MC.randInt(8), grav: 0.1, drag: 0.9,
      color: [1, 0.75 + Math.random() * 0.2, 0.35], ground: false });
  },
  smoke(x, y, z) {
    const c = MC.rand(0.5, 0.8);
    this.spawn({ frames: ['particle/generic_' + MC.randInt(8)], pos: [x, y, z], vel: [MC.rand(-0.02, 0.02), 0.02, MC.rand(-0.02, 0.02)],
      size: MC.rand(0.12, 0.2), life: 20 + MC.randInt(12), color: [c, c, c], alpha: 0.8, fade: true, drag: 0.95, ground: false });
  },
  crumbs(x, y, z, n) {
    for (let i = 0; i < n; i++) {
      this.spawn({ name: 'item/golden_apple', sub: [MC.randInt(3) / 4, MC.randInt(3) / 4, 0.25, 0.25], pos: [x, y, z],
        vel: [MC.rand(-0.06, 0.06), MC.rand(0.0, 0.1), MC.rand(-0.06, 0.06)], size: 0.06, life: 14, grav: 1, drag: 0.95, ground: false });
    }
  },
};
