'use strict';
// ================================================================
//  リソースフォルダ読み込み(マイクラのリソースパック方式)
//   フォルダの中の「場所」と「名前」さえ合っていれば、そのファイルが反映されます。
//     textures/item/mace.png / sounds/item/mace/smash_air1.ogg ...
//
//   1) http(s)で開いた場合 : index.html の隣の assets/minecraft/ を自動で読む
//   2) file:// などで開いた場合: 「フォルダを選ぶ」で assets/minecraft を含むフォルダを選ぶ
//      (選んだフォルダは記憶されます。ブラウザはChrome/Edge系)
// ================================================================
MC.Pack = {
  mode: null,          // 'http' | 'folder'
  httpBase: 'assets/minecraft/',
  root: null,          // フォルダ選択時のルート(textures/ を含むフォルダ)
  folderName: '',
  _dirs: new Map(),

  /** 読み込み元を決める(必要なら選択UIを出す) */
  async open() {
    const need = (window.ASSET_LIST && window.ASSET_LIST.textures) || [];
    if (!need.length) throw new Error('js/asset_list.js が空です。tools/sync_assets.py で生成してください');
    if (/^https?:$/.test(location.protocol)) {
      try {
        const r = await fetch(this.httpBase + need[0], { method: 'GET', cache: 'no-cache' });
        if (r.ok) { this.mode = 'http'; return; }
      } catch (e) {}
    }
    await this.pickFolder(need);
  },

  // ------------------------------------------------------------ フォルダ選択
  async pickFolder(need) {
    const box = document.getElementById('pick'), msg = document.getElementById('pick-msg');
    const bSel = document.getElementById('pick-select'), bLast = document.getElementById('pick-last');
    let last = null;
    try { last = await this._idbGet('dir'); } catch (e) {}
    bLast.style.display = last ? 'inline-block' : 'none';
    if (last) bLast.textContent = '前回のフォルダを使う: ' + last.name;
    box.style.display = 'flex';
    if (!window.showDirectoryPicker) {
      msg.textContent = 'このブラウザはフォルダ選択に対応していません。Chrome/Edgeで開くか、ローカルサーバー(python -m http.server)経由で開いてください。';
      bSel.disabled = true;
    }
    return new Promise(resolve => {
      const tryHandle = async (h) => {
        msg.textContent = '確認中...';
        try {
          if (h.requestPermission && (await h.requestPermission({ mode: 'read' })) !== 'granted') { msg.textContent = 'フォルダへのアクセスが許可されませんでした'; return; }
          const root = await this._findRoot(h);
          if (!root) { msg.textContent = '「' + h.name + '」の中に textures フォルダ(assets/minecraft)が見つかりません。assets/minecraft を含むフォルダを選んでください。'; return; }
          this.root = root; this.folderName = h.name; this._dirs.clear();
          // 必要なファイルが揃っているか(場所と名前が合っているか)
          const missing = [];
          await Promise.all(need.map(async p => { if (!(await this._fileHandle(p))) missing.push(p); }));
          if (missing.length) {
            missing.sort();
            msg.textContent = '次のファイルが見つかりません (' + missing.length + '件)。フォルダ内の場所と名前を確認してください:\n' + missing.slice(0, 8).join('\n') + (missing.length > 8 ? '\n...' : '');
            return;
          }
          try { await this._idbSet('dir', h); } catch (e) {}
          this.mode = 'folder';
          box.style.display = 'none';
          resolve();
        } catch (e) { msg.textContent = 'エラー: ' + e.message; }
      };
      bSel.onclick = async () => {
        try { const h = await window.showDirectoryPicker({ id: 'mcmace-assets', mode: 'read' }); await tryHandle(h); }
        catch (e) { if (e.name !== 'AbortError') msg.textContent = 'エラー: ' + e.message; }
      };
      bLast.onclick = () => last && tryHandle(last);
    });
  },

  /** 選ばれたフォルダの中から textures/ を含むフォルダを探す */
  async _findRoot(h) {
    const tries = [[], ['minecraft'], ['assets', 'minecraft'], ['assets'], ['resources', 'assets', 'minecraft']];
    for (const t of tries) {
      try {
        let d = h;
        for (const n of t) d = await d.getDirectoryHandle(n);
        await d.getDirectoryHandle('textures');
        return d;
      } catch (e) {}
    }
    return null;
  },

  async _dir(parts) {
    const key = parts.join('/');
    if (this._dirs.has(key)) return this._dirs.get(key);
    let d = this.root;
    for (const n of parts) d = await d.getDirectoryHandle(n);
    this._dirs.set(key, d);
    return d;
  },
  async _fileHandle(path) {
    const parts = path.split('/'), name = parts.pop();
    try { return await (await this._dir(parts)).getFileHandle(name); } catch (e) { return null; }
  },

  // ------------------------------------------------------------ 読み込み
  async bytes(path) {
    if (this.mode === 'http') {
      const r = await fetch(this.httpBase + path);
      if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + path);
      return r.arrayBuffer();
    }
    const fh = await this._fileHandle(path);
    if (!fh) throw new Error('not found: ' + path);
    return (await fh.getFile()).arrayBuffer();
  },

  /** 画像を読み込んで HTMLImageElement を返す(blob経由なのでfile://でもWebGLで使える) */
  async image(path) {
    const buf = await this.bytes(path);
    const url = URL.createObjectURL(new Blob([buf], { type: 'image/png' }));
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => { URL.revokeObjectURL(url); res(im); };
      im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('bad image: ' + path)); };
      im.src = url;
    });
  },

  // ------------------------------------------------------------ IndexedDB(フォルダの記憶)
  _idb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('mcmace', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  },
  async _idbGet(k) { const db = await this._idb(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); },
  async _idbSet(k, v) { const db = await this._idb(); return new Promise((res, rej) => { const q = db.transaction('kv', 'readwrite').objectStore('kv').put(v, k); q.onsuccess = () => res(); q.onerror = () => rej(q.error); }); },
};
