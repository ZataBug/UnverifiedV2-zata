'use strict';
// ================================================================
//  描画: メインシーン / 一人称の手 / インベントリのプレビュー
// ================================================================
MC.Render = {
  fovCur: 70,

  init(canvas) {
    const G = MC.Game;
    this.glCanvas = canvas;
    const r = this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    r.setSize(window.innerWidth, window.innerHeight, false);
    r.outputEncoding = THREE.LinearEncoding;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x78a7ff);
    this.camera = new THREE.PerspectiveCamera(MC.CFG.fov, window.innerWidth / window.innerHeight, 0.05, 1500);
    this.camera.rotation.order = 'YXZ';

    G.world.build(this.scene);
    MC.Particles.init(this.scene);

    // NPC
    const npc = this.npcModel = new MC.Models.Humanoid('entity/player/wide/kai');
    npc.setEquipment({ head: MC.Item.make('netherite_helmet'), chest: MC.Item.make('netherite_chestplate'), legs: MC.Item.make('netherite_leggings'), feet: MC.Item.make('netherite_boots') });
    this.scene.add(npc.root);
    this.nametag = this.makeNametag('NPC');
    this.scene.add(this.nametag);

    this.spriteMap = new Map();
    this.Hand.init(this);
    this.Preview.init();
    MC.Preview = this.Preview;
  },

  makeNametag(text) {
    const w = MC.Font.width(text) + 2, h = 10;
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
    x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(0, 0, w, h);
    MC.Font.draw(x, text, 1, 1, '#FFFFFF', true);
    const t = new THREE.CanvasTexture(c); t.magFilter = t.minFilter = THREE.NearestFilter; t.generateMipmaps = false;
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthWrite: false }));
    s.scale.set(w * 0.025, h * 0.025, 1);
    return s;
  },

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.Hand.camera.aspect = w / h; this.Hand.camera.updateProjectionMatrix();
  },

  syncEquipment() { this.Preview.dirty = true; },

  projectileSprite(p) {
    let s = this.spriteMap.get(p);
    if (!s) {
      const tex = MC.Assets.tex(p.kind === 'pearl' ? 'item/ender_pearl' : 'item/wind_charge');
      s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, alphaTest: 0.1 }));
      s.scale.set(0.5, 0.5, 1);
      this.scene.add(s); this.spriteMap.set(p, s);
    }
    return s;
  },

  /** 毎フレーム */
  frame(dt, alpha) {
    const G = MC.Game, P = G.P, N = G.N, cam = this.camera, L = MC.lerp;
    // カメラ
    const ex = L(P.px, P.x, alpha), ey = L(P.py, P.y, alpha) + (P.sneaking ? MC.CFG.eyeHeightSneak : MC.CFG.eyeHeight), ez = L(P.pz, P.z, alpha);
    cam.position.set(ex, ey, ez);
    let roll = 0;
    if (P.hurtTime > 0) roll = Math.sin((P.hurtTime - alpha) / 10 * Math.PI) * 0.18;
    cam.rotation.set(P.pitch, P.yaw, roll);
    const target = MC.CFG.fov * (P.sprinting ? 1.1 : 1);
    this.fovCur += (target - this.fovCur) * Math.min(1, dt * 12);
    if (Math.abs(cam.fov - this.fovCur) > 0.01) { cam.fov = this.fovCur; cam.updateProjectionMatrix(); }
    const fwd = G.look(P);
    MC.Snd.setListener({ x: ex, y: ey, z: ez }, fwd);
    G.world.updateBorder(P.x, P.z);

    // エリトラ音
    if (G.elytraLoop) {
      const f = P.vx * P.vx + P.vy * P.vy + P.vz * P.vz;
      const vol = f >= 1e-7 ? MC.clamp(f / 4, 0, 1) : 0;
      G.elytraLoop.set(vol, vol > 0.8 ? 1 + (vol - 0.8) : 1);
    }

    // NPC
    const m = this.npcModel;
    m.root.position.set(L(N.px, N.x, alpha), L(N.py, N.y, alpha), L(N.pz, N.z, alpha));
    m.root.rotation.y = N.rotY;
    const ndx = P.x - N.x, ndz = P.z - N.z, nd = Math.hypot(ndx, ndz) || 1;
    m.head.rotation.x = -Math.atan2((G.eyeY(P) - (N.y + 1.62)), nd) * 0.9;
    m.animate(N.limb, L(N.prevLimbAmt, N.limbAmt, alpha));
    if (N.swingT > 0) m.rArm.rotation.x = -Math.sin((6 - N.swingT) / 6 * Math.PI) * 1.6;
    if (N.hurtTime > 0) m.setTint(1, 0.4, 0.4); else m.setTint(1, 1, 1);
    this.nametag.position.set(m.root.position.x, m.root.position.y + 2.15, m.root.position.z);

    // 飛び道具
    const alive = new Set(G.projs);
    for (const [p, s] of this.spriteMap) if (!alive.has(p)) { this.scene.remove(s); s.material.dispose(); this.spriteMap.delete(p); }
    for (const p of G.projs) {
      const s = this.projectileSprite(p);
      s.position.set(L(p.px, p.x, alpha), L(p.py, p.y, alpha), L(p.pz, p.z, alpha));
    }

    MC.Particles.update(dt, G.world);

    const r = this.renderer;
    r.autoClear = true;
    r.render(this.scene, cam);
    // 手(深度を消して上から描く)
    if (MC.GUI.screen !== 'start') {
      r.autoClear = false; r.clearDepth();
      this.Hand.render(alpha, dt);
      r.autoClear = true;
    }
  },
};

// ================================================================
//  一人称の手 / 手持ちアイテム(ItemInHandRendererの再現)
// ================================================================
MC.Render.Hand = {
  height: 1, oHeight: 1, shownKey: null, shownStack: null, meshes: {},

  init() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(MC.CFG.fov, window.innerWidth / window.innerHeight, 0.01, 10);
    this.root = new THREE.Group(); this.root.matrixAutoUpdate = false;
    this.scene.add(this.root);
    // 素手用の腕
    const A = MC.Assets;
    const mat = new THREE.MeshBasicMaterial({ map: A.tex('entity/player/wide/steve'), vertexColors: true, alphaTest: 0.5 });
    this.arm = new THREE.Group();
    const geo = MC.Models.boxGeo(4, 12, 4, 40, 16, 64, 64);
    const am = new THREE.Mesh(geo, mat); am.position.set(0, -6 / 16, 0);
    const sleeve = new THREE.Mesh(MC.Models.boxGeo(4, 12, 4, 40, 32, 64, 64, 0.25), mat); sleeve.position.copy(am.position);
    this.arm.add(am, sleeve);
    this.root.add(this.arm); this.arm.visible = false;
    const held = MC.Inventory.held();
    this.shownKey = held ? MC.Inventory.selected + ':' + held.id : '-';
    this.shownStack = held;
  },

  getMesh(def) {
    const key = def.name;
    if (!this.meshes[key]) {
      const g = MC.Models.itemMesh(def);
      const wrap = new THREE.Group(); wrap.matrixAutoUpdate = false;
      wrap.matrix.copy(MC.Models.displayMatrix(def.model));
      wrap.add(g); wrap.userData.glint = g.userData.glint;
      wrap.visible = false;
      this.root.add(wrap);
      this.meshes[key] = wrap;
    }
    return this.meshes[key];
  },

  /** ゲームtickごと */
  tick() {
    const G = MC.Game, inv = MC.Inventory;
    const held = inv.held();
    const key = held ? inv.selected + ':' + held.id : '-';
    const reequip = key !== this.shownKey;
    const f = G.attackStrength(0);
    const target = reequip ? 0 : f * f * f;
    this.oHeight = this.height;
    this.height += MC.clamp(target - this.height, -0.4, 0.4);
    if (this.height < 0.1) { this.shownKey = key; this.shownStack = held; }
  },

  render(alpha, dt) {
    const G = MC.Game, cfg = MC.CFG;
    const cam = this.camera;
    if (Math.abs(cam.fov - cfg.fov) > 0.01) { cam.fov = cfg.fov; cam.updateProjectionMatrix(); }
    for (const k in this.meshes) this.meshes[k].visible = false;
    this.arm.visible = false;
    const st = this.shownStack;
    const e = 1 - MC.lerp(this.oHeight, this.height, alpha);       // 0=上がりきった状態
    const p = G.swinging ? (G.swingTicks + alpha) / 6 : 0;
    const M = new THREE.Matrix4();
    const T = (x, y, z) => M.multiply(new THREE.Matrix4().makeTranslation(x, y, z));
    const RX = d => M.multiply(new THREE.Matrix4().makeRotationX(d * MC.DEG));
    const RY = d => M.multiply(new THREE.Matrix4().makeRotationY(d * MC.DEG));
    const RZ = d => M.multiply(new THREE.Matrix4().makeRotationZ(d * MC.DEG));
    const side = 1;
    const def = st ? MC.ITEMS[st.id] : null;
    const sq = Math.sqrt(p);
    const t = performance.now() / 1000;

    if (!st) {
      // 素手(腕)
      const g = -0.3 * Math.sin(sq * Math.PI), h = 0.4 * Math.sin(sq * Math.PI * 2), i = -0.4 * Math.sin(p * Math.PI);
      T(side * (g + 0.64), h - 0.6 + e * -0.6, i - 0.72);
      RY(side * 45);
      const j = Math.sin(p * p * Math.PI), k = Math.sin(sq * Math.PI);
      RY(side * k * 70); RZ(side * j * -20);
      RY(-10); RX(100);
      T(0, 0.02, 0.05);
      this.root.matrix.copy(M); this.root.matrixWorldNeedsUpdate = true;
      this.arm.visible = true;
      this.arm.matrixAutoUpdate = true;
    } else {
      const mesh = this.getMesh(def);
      mesh.visible = true;
      if (mesh.userData.glint) { mesh.userData.glint.offset.set((t / 3) % 1, (t / 4.5) % 1); }
      const using = (G.eating > 0 && def.type === 'food');
      if (using) {
        // 食事アニメーション
        const total = MC.CFG.eatTicks;
        const f = total - G.eating - alpha + 1, gg = f / total;
        if (gg < 0.8) T(0, Math.abs(Math.cos(f / 4 * Math.PI) * 0.1), 0);
        const hh = 1 - Math.pow(Math.max(0, gg), 27);
        T(hh * 0.6 * side, hh * -0.5, 0);
        RY(side * hh * 90); RX(hh * 10); RZ(side * hh * 30);
      } else {
        const gx = -0.4 * Math.sin(sq * Math.PI), hy = 0.2 * Math.sin(sq * Math.PI * 2), iz = -0.2 * Math.sin(p * Math.PI);
        T(side * gx, hy, iz);
      }
      T(side * 0.56, -0.52 + e * -0.6, -0.72);
      if (!using) {
        const f = Math.sin(p * p * Math.PI), g2 = Math.sin(sq * Math.PI);
        RY(side * (45 + f * -20));
        RZ(side * g2 * -20);
        RX(g2 * -80);
        RY(side * -45);
        if (def.type === 'spear') T(0, 0, -0.9 * Math.sin(p * Math.PI));
      }
      if (def.type === 'spear' && G.spearCharge > 0) {
        const c = Math.min(1, G.spearCharge / 10);
        T(-0.1 * c, 0.1 * c, 0.15 * c); RX(-10 * c);
      }
      this.root.matrix.copy(M);
    }
    if (!st) { this.arm.updateMatrix(); }
    this.root.updateMatrixWorld(true);
    MC.Render.renderer.render(this.scene, this.camera);
  },
};

// ================================================================
//  インベントリ内のプレイヤー表示
// ================================================================
MC.Render.Preview = {
  init() {
    const r = this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, preserveDrawingBuffer: true });
    r.setClearColor(0x000000, 0);
    this.scene = new THREE.Scene();
    this.model = new MC.Models.Humanoid('entity/player/wide/steve');
    this.scene.add(this.model.root);
    const w = 49 / 30 / 2;
    this.camera = new THREE.OrthographicCamera(-w, w, 64 / 30, -6 / 30, 0.1, 20);
    this.camera.position.set(0, 0, 5); this.camera.lookAt(0, 0, 0);
    this.size = 0;
    this.dirty = true;
  },
  render(dx, dy) {
    const G = MC.GUI;
    const pw = Math.round(49 * G.pxScale), ph = Math.round(70 * G.pxScale);
    if (this.size !== pw) { this.renderer.setPixelRatio(1); this.renderer.setSize(pw, ph, false); this.size = pw; }
    const m = this.model;
    m.setEquipment(MC.Inventory.equipment());
    const f = Math.atan(dx / 40), g = Math.atan(dy / 40);
    m.root.rotation.y = f * 20 * MC.DEG * 1.0;
    m.head.rotation.x = g * 20 * MC.DEG;
    m.root.rotation.x = 0;
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement;
  },
};
