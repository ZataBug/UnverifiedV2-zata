'use strict';
// ================================================================
//  モデル生成
//   - boxGeo: マイクラ式UV展開の直方体
//   - Humanoid: プレイヤーモデル(スキン + 防具 + エリトラ)
//   - itemMesh: 2Dテクスチャを厚み付きに押し出した手持ちアイテム
//  モデル座標は「足元が原点・+Zが正面・+Yが上」、単位はブロック
// ================================================================
MC.Models = {};

/**
 * マイクラ式の直方体。size=(w,h,d) px, uv=(u,v) テクスチャ開始位置, tw/th=テクスチャサイズ
 * 中心が原点のジオメトリを返す。inflate で全方向に膨らませる(防具/上着)。
 * mirror=true で左右反転(旧式防具テクスチャの左腕/左脚用)
 */
MC.Models.boxGeo = function (w, h, d, u, v, tw, th, inflate, mirror) {
  inflate = inflate || 0;
  const x0 = -w / 2 - inflate, x1 = w / 2 + inflate;
  const y0 = -h / 2 - inflate, y1 = h / 2 + inflate;
  const z0 = -d / 2 - inflate, z1 = d / 2 + inflate;
  const pos = [], uvs = [], idx = [], col = [];
  const S = 1 / 16;
  // face: corners(4: 左上, 右上, 右下, 左下 - 画像上での並び), 領域(u0,v0,u1,v1), 明るさ
  const faces = [];
  // 画像上の領域
  const R = [u, v + d, u + d, v + d + h];                  // 右側面(-X)
  const F = [u + d, v + d, u + d + w, v + d + h];          // 前(+Z)
  const L = [u + d + w, v + d, u + d + w + d, v + d + h];  // 左側面(+X)
  const B = [u + d + w + d, v + d, u + d + w + d + w, v + d + h]; // 後(-Z)
  const T = [u + d, v, u + d + w, v + d];                  // 上
  const D = [u + d + w, v, u + d + w + w, v + d];          // 下
  const left = mirror ? R : L, right = mirror ? L : R;
  // 前(+Z)  画像: 左→右 = -X → +X
  faces.push({ c: [[x0, y1, z1], [x1, y1, z1], [x1, y0, z1], [x0, y0, z1]], r: F, b: 0.8, m: mirror });
  // 後(-Z)  画像: 左→右 = +X → -X
  faces.push({ c: [[x1, y1, z0], [x0, y1, z0], [x0, y0, z0], [x1, y0, z0]], r: B, b: 0.8, m: mirror });
  // 右側面(-X) 画像: 左→右 = -Z → +Z
  faces.push({ c: [[x0, y1, z0], [x0, y1, z1], [x0, y0, z1], [x0, y0, z0]], r: right, b: 0.6, m: mirror });
  // 左側面(+X) 画像: 左→右 = +Z → -Z
  faces.push({ c: [[x1, y1, z1], [x1, y1, z0], [x1, y0, z0], [x1, y0, z1]], r: left, b: 0.6, m: mirror });
  // 上(+Y) 画像: 上→下 = -Z → +Z, 左→右 = -X → +X
  faces.push({ c: [[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]], r: T, b: 1.0, m: mirror });
  // 下(-Y) 画像: 上→下 = +Z → -Z, 左→右 = -X → +X
  faces.push({ c: [[x0, y0, z1], [x1, y0, z1], [x1, y0, z0], [x0, y0, z0]], r: D, b: 0.5, m: mirror });
  let n = 0;
  for (const f of faces) {
    let [a, b, c2, d2] = f.r;
    let ul = a, ur = c2;
    if (f.m) { ul = c2; ur = a; }
    const vt = v1 => 1 - v1 / th;
    const U = (px) => px / tw;
    const quad = [[U(ul), vt(b)], [U(ur), vt(b)], [U(ur), vt(d2)], [U(ul), vt(d2)]];
    for (let i = 0; i < 4; i++) {
      pos.push(f.c[i][0] * S, f.c[i][1] * S, f.c[i][2] * S);
      uvs.push(quad[i][0], quad[i][1]);
      col.push(f.b, f.b, f.b);
    }
    idx.push(n, n + 2, n + 1, n, n + 3, n + 2);
    n += 4;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
};

// ------------------------------------------------------------
//  プレイヤー型モデル
// ------------------------------------------------------------
MC.Models.Humanoid = class Humanoid {
  /**
   * skin: 'entity/player/wide/steve' など(64x64)
   */
  constructor(skin) {
    const M = MC.Models, A = MC.Assets, S = 1 / 16;
    this.root = new THREE.Group();
    this.body = new THREE.Group();   // 全体のピッチ(エリトラ飛行用)を掛けられる
    this.root.add(this.body);
    this.root.scale.setScalar(0.9375);
    this.materials = [];

    const skinTex = A.tex(skin);
    const mat = (tex, extra) => {
      const m = new THREE.MeshBasicMaterial(Object.assign({ map: tex, vertexColors: true, alphaTest: 0.5, transparent: false }, extra || {}));
      this.materials.push(m);
      return m;
    };
    const skinMat = mat(skinTex);
    const mk = (g, m, px, py, pz) => { const mesh = new THREE.Mesh(g, m); mesh.position.set(px * S, py * S, pz * S); return mesh; };
    const part = (px, py, pz) => { const gp = new THREE.Group(); gp.position.set(px * S, py * S, pz * S); return gp; };

    // 各パーツのピボット(関節)
    this.head = part(0, 24, 0);
    this.torso = part(0, 24, 0);
    this.rArm = part(-5, 22, 0);
    this.lArm = part(5, 22, 0);
    this.rLeg = part(-1.9, 12, 0);
    this.lLeg = part(1.9, 12, 0);
    for (const p of [this.head, this.torso, this.rArm, this.lArm, this.rLeg, this.lLeg]) this.body.add(p);

    const bg = M.boxGeo;
    // スキン本体(64x64)
    this.head.add(mk(bg(8, 8, 8, 0, 0, 64, 64), skinMat, 0, 4, 0));
    this.torso.add(mk(bg(8, 12, 4, 16, 16, 64, 64), skinMat, 0, -6, 0));
    this.rArm.add(mk(bg(4, 12, 4, 40, 16, 64, 64), skinMat, -1, -4, 0));
    this.lArm.add(mk(bg(4, 12, 4, 32, 48, 64, 64), skinMat, 1, -4, 0));
    this.rLeg.add(mk(bg(4, 12, 4, 0, 16, 64, 64), skinMat, 0, -6, 0));
    this.lLeg.add(mk(bg(4, 12, 4, 16, 48, 64, 64), skinMat, 0, -6, 0));
    // スキン上着レイヤー
    this.head.add(mk(bg(8, 8, 8, 32, 0, 64, 64, 0.5), skinMat, 0, 4, 0));
    this.torso.add(mk(bg(8, 12, 4, 16, 32, 64, 64, 0.25), skinMat, 0, -6, 0));
    this.rArm.add(mk(bg(4, 12, 4, 40, 32, 64, 64, 0.25), skinMat, -1, -4, 0));
    this.lArm.add(mk(bg(4, 12, 4, 48, 48, 64, 64, 0.25), skinMat, 1, -4, 0));
    this.rLeg.add(mk(bg(4, 12, 4, 0, 32, 64, 64, 0.25), skinMat, 0, -6, 0));
    this.lLeg.add(mk(bg(4, 12, 4, 0, 48, 64, 64, 0.25), skinMat, 0, -6, 0));

    // 防具(素材ごとに作り、装備状態で表示切替)
    this.armor = {};           // material -> {head, chest, legs, feet: [meshes]}
    this._armorBuilt = {};
    this.armorGroups = { head: [], chest: [], legs: [], feet: [] };

    // エリトラ
    const wingTex = A.tex('entity/equipment/wings/elytra');
    const wingMat = mat(wingTex);
    this.wings = new THREE.Group();
    this.wings.position.set(0, 24 * S, -2 * S);       // 背中側
    this.torso.add(this.wings);
    const wingGeoL = bg(10, 20, 2, 22, 0, 64, 32, 0, false);
    const wingGeoR = bg(10, 20, 2, 22, 0, 64, 32, 0, true);
    this.wingL = part(5, 0, 0); this.wingR = part(-5, 0, 0);
    const wl = new THREE.Mesh(wingGeoL, wingMat); wl.position.set(0, -10 * S, -1 * S);
    const wr = new THREE.Mesh(wingGeoR, wingMat); wr.position.set(0, -10 * S, -1 * S);
    // 左翼の箱は x∈[0,10], 右翼は x∈[-10,0] になるよう中心をずらす
    wl.position.x = 5 * S; wr.position.x = -5 * S;
    this.wingL.add(wl); this.wingR.add(wr);
    this.wings.add(this.wingL, this.wingR);
    this.wings.visible = false;
    this.setWingPose(0);
    this.wingMat = wingMat;

    this.limbSwing = 0; this.limbAmount = 0;
  }

  /** 防具メッシュを(必要なら)作る */
  _ensureArmor(material) {
    if (this._armorBuilt[material]) return this._armorBuilt[material];
    const M = MC.Models, S = 1 / 16, A = MC.Assets, bg = M.boxGeo;
    const t1 = A.tex('entity/equipment/humanoid/' + material);
    const t2 = A.tex('entity/equipment/humanoid_leggings/' + material);
    const m1 = new THREE.MeshBasicMaterial({ map: t1, vertexColors: true, alphaTest: 0.1 });
    const m2 = new THREE.MeshBasicMaterial({ map: t2, vertexColors: true, alphaTest: 0.1 });
    this.materials.push(m1, m2);
    const mk = (g, m, px, py, pz) => { const mesh = new THREE.Mesh(g, m); mesh.position.set(px * S, py * S, pz * S); return mesh; };
    const set = { head: [], chest: [], legs: [], feet: [] };
    // 外側レイヤー(膨らみ1.0): ヘルメット/チェストプレート/ブーツ
    const helm = mk(bg(8, 8, 8, 0, 0, 64, 32, 1.0), m1, 0, 4, 0); this.head.add(helm); set.head.push(helm);
    const chest = mk(bg(8, 12, 4, 16, 16, 64, 32, 1.0), m1, 0, -6, 0); this.torso.add(chest); set.chest.push(chest);
    const ra = mk(bg(4, 12, 4, 40, 16, 64, 32, 1.0), m1, -1, -4, 0); this.rArm.add(ra); set.chest.push(ra);
    const la = mk(bg(4, 12, 4, 40, 16, 64, 32, 1.0, true), m1, 1, -4, 0); this.lArm.add(la); set.chest.push(la);
    const rb = mk(bg(4, 12, 4, 0, 16, 64, 32, 1.0), m1, 0, -6, 0); this.rLeg.add(rb); set.feet.push(rb);
    const lb = mk(bg(4, 12, 4, 0, 16, 64, 32, 1.0, true), m1, 0, -6, 0); this.lLeg.add(lb); set.feet.push(lb);
    // 内側レイヤー(膨らみ0.5): レギンス = 胴 + 両脚
    const lbody = mk(bg(8, 12, 4, 16, 16, 64, 32, 0.5), m2, 0, -6, 0); this.torso.add(lbody); set.legs.push(lbody);
    const rl = mk(bg(4, 12, 4, 0, 16, 64, 32, 0.5), m2, 0, -6, 0); this.rLeg.add(rl); set.legs.push(rl);
    const ll = mk(bg(4, 12, 4, 0, 16, 64, 32, 0.5, true), m2, 0, -6, 0); this.lLeg.add(ll); set.legs.push(ll);
    for (const k in set) for (const m of set[k]) { m.visible = false; this.armorGroups[k].push({ mat: material, mesh: m }); }
    this._armorBuilt[material] = set;
    return set;
  }

  /**
   * equip: {head,chest,legs,feet} にそれぞれ item stack(or null)
   * chest が elytra のときは翼を表示
   */
  setEquipment(equip) {
    for (const slot of ['head', 'chest', 'legs', 'feet']) {
      const st = equip[slot];
      const matName = st && MC.ARMOR_MATERIAL[st.id];
      if (matName) this._ensureArmor(matName);
      for (const g of this.armorGroups[slot]) g.mesh.visible = !!matName && g.mat === matName;
    }
    this.wings.visible = !!(equip.chest && equip.chest.id === 'elytra');
  }

  /** 翼を広げる度合い 0(たたむ)〜1(全開) */
  setWingPose(t) {
    const rest = 15 * MC.DEG;
    const xr = rest + (t * (-80 * MC.DEG) * 0);       // ピッチはほぼ一定
    const zr = rest + t * (60 * MC.DEG);
    this.wingL.rotation.set(xr, 0, zr);
    this.wingR.rotation.set(xr, 0, -zr);
  }

  /** 歩行アニメ */
  animate(swing, amount, tickTime) {
    const a = Math.cos(swing * 0.6662) * 1.4 * amount;
    this.rLeg.rotation.x = a;
    this.lLeg.rotation.x = -a;
    this.rArm.rotation.x = -a * 0.7;
    this.lArm.rotation.x = a * 0.7;
  }

  setTint(r, g, b) {
    for (const m of this.materials) m.color.setRGB(r, g, b);
  }
};

// ------------------------------------------------------------
//  アイテムメッシュ(2Dテクスチャを押し出し)
//  マイクラの builtin/generated と同じ: 1x1ブロックに正規化、厚み1/16
// ------------------------------------------------------------
MC.Models._itemGeoCache = {};
MC.Models.itemGeometry = function (name) {
  const cache = MC.Models._itemGeoCache;
  if (cache[name]) return cache[name];
  const px = MC.Assets.pixels(name);
  const W = px.w, H = px.h, d = px.data.data;
  const op = (x, y) => x >= 0 && y >= 0 && x < W && y < H && d[(y * W + x) * 4 + 3] > 8;
  const pos = [], uv = [], idx = [], nrm = [];
  const T = 1 / 16 / 2;                // 半分の厚み
  let n = 0;
  const quad = (p, u0, v0, nx, ny, nz) => {
    for (let i = 0; i < 4; i++) { pos.push(p[i][0], p[i][1], p[i][2]); nrm.push(nx, ny, nz); }
    uv.push(u0[0], u0[1], u0[0], u0[1], u0[0], u0[1], u0[0], u0[1]);
    idx.push(n, n + 1, n + 2, n, n + 2, n + 3); n += 4;
  };
  const sx = 1 / W, sy = 1 / H;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!op(x, y)) continue;
    const x0 = x * sx - 0.5, x1 = (x + 1) * sx - 0.5;
    const y1 = 0.5 - y * sy, y0 = 0.5 - (y + 1) * sy;
    const uc = [(x + 0.5) / W, 1 - (y + 0.5) / H];
    // 前面(+Z)と背面(-Z) - ピクセル全体のUVを張る
    const ua = x / W, ub = (x + 1) / W, va = 1 - (y + 1) / H, vb = 1 - y / H;
    // 前面
    for (const [z, flip] of [[T, false], [-T, true]]) {
      const base = n;
      const P = flip ? [[x1, y1, z], [x0, y1, z], [x0, y0, z], [x1, y0, z]] : [[x0, y1, z], [x1, y1, z], [x1, y0, z], [x0, y0, z]];
      for (const p of P) { pos.push(p[0], p[1], p[2]); nrm.push(0, 0, flip ? -1 : 1); }
      if (!flip) uv.push(ua, vb, ub, vb, ub, va, ua, va); else uv.push(ub, vb, ua, vb, ua, va, ub, va);
      idx.push(base, base + 2, base + 1, base, base + 3, base + 2); n += 4;
    }
    // 側面(隣が透明なら)
    if (!op(x - 1, y)) quad([[x0, y1, -T], [x0, y1, T], [x0, y0, T], [x0, y0, -T]], uc, 0, -1, 0, 0);
    if (!op(x + 1, y)) quad([[x1, y1, T], [x1, y1, -T], [x1, y0, -T], [x1, y0, T]], uc, 0, 1, 0, 0);
    if (!op(x, y - 1)) quad([[x0, y1, -T], [x1, y1, -T], [x1, y1, T], [x0, y1, T]], uc, 0, 0, 1, 0);
    if (!op(x, y + 1)) quad([[x0, y0, T], [x1, y0, T], [x1, y0, -T], [x0, y0, -T]], uc, 0, 0, -1, 0);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nrm, 3));
  g.setIndex(idx);
  cache[name] = g;
  return g;
};

/** アイテム定義から手持ち用メッシュ(+エンチャント光沢)を作る */
MC.Models.itemMesh = function (def) {
  const name = def.handTex || def.tex;
  const geo = MC.Models.itemGeometry(name);
  const tex = MC.Assets.tex(name);
  const mat = new THREE.MeshBasicMaterial({ map: tex, alphaTest: 0.1, side: THREE.DoubleSide });
  const group = new THREE.Group();
  const mesh = new THREE.Mesh(geo, mat);
  group.add(mesh);
  if (def.glint) {
    const gt = MC.Assets.tex('misc/enchanted_glint_item', { repeat: true }).clone();
    gt.needsUpdate = true;
    gt.wrapS = gt.wrapT = THREE.RepeatWrapping;
    gt.repeat.set(0.5, 0.5);
    const gm = new THREE.MeshBasicMaterial({
      map: gt, color: 0x4a2490, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
    });
    const gmesh = new THREE.Mesh(geo, gm);
    gmesh.scale.set(1.001, 1.001, 1.04);
    group.add(gmesh);
    group.userData.glint = gt;
  }
  return group;
};

/** displayトランスフォーム(first-person right hand) */
MC.Models.DISPLAY = {
  generated: { rot: [0, -90, 25], tr: [1.13, 3.2, 1.13], sc: [0.68, 0.68, 0.68] },
  handheld: { rot: [0, -90, 25], tr: [1.13, 3.2, 1.13], sc: [0.68, 0.68, 0.68] },
  handheld_mace: { rot: [0, -90, 25], tr: [0, 3, 0.8], sc: [0.9, 0.9, 0.9] },
  spear: { rot: [-20, 90, -35], tr: [3.13, 2.0, 0.13], sc: [1.36, 1.36, 0.68] },
};

MC.Models.displayMatrix = function (model) {
  const d = MC.Models.DISPLAY[model] || MC.Models.DISPLAY.generated;
  const m = new THREE.Matrix4();
  const t = new THREE.Matrix4().makeTranslation(d.tr[0] / 16, d.tr[1] / 16, d.tr[2] / 16);
  const rx = new THREE.Matrix4().makeRotationX(d.rot[0] * MC.DEG);
  const ry = new THREE.Matrix4().makeRotationY(d.rot[1] * MC.DEG);
  const rz = new THREE.Matrix4().makeRotationZ(d.rot[2] * MC.DEG);
  const s = new THREE.Matrix4().makeScale(d.sc[0], d.sc[1], d.sc[2]);
  m.multiply(t).multiply(rx).multiply(ry).multiply(rz).multiply(s);
  return m;
};
