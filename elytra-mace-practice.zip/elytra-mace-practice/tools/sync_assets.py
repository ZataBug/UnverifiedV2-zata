#!/usr/bin/env python3
"""
アセット同期ツール
------------------
assets_manifest.json に書かれたテクスチャ/サウンドだけを、元のアセットパック
(minecraft-assets-1_21_11.zip か、展開済みフォルダ)から assets/ にコピーし、
必要なファイルの一覧 js/asset_list.js を書き出します(URL/データ埋め込みなし)。

使い方:
  python tools/sync_assets.py <アセットパックのzip または 展開フォルダ>
  python tools/sync_assets.py <パック> --prune     # マニフェストに無いファイルを assets/ から削除
  python tools/sync_assets.py --rebuild-only       # コピーはせず asset_list.js だけ作り直す

新しいアイテムを足すとき:
  1) js/items.js にアイテム定義を足す
  2) assets_manifest.json に必要なテクスチャ/サウンドイベントを足す
  3) 上のコマンドを実行
"""
import sys, os, json, fnmatch, base64, zipfile, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DST = os.path.join(ROOT, "assets", "minecraft")


class Pack:
    def __init__(self, path):
        self.zip = None
        self.dir = None
        if os.path.isdir(path):
            self.dir = self._find_dir(path)
        else:
            self.zip = zipfile.ZipFile(path)
            self.names = {}
            for n in self.zip.namelist():
                m = re.search(r"assets/minecraft/(.+)$", n)
                if m and not n.endswith("/"):
                    self.names[m.group(1)] = n

    @staticmethod
    def _find_dir(p):
        for base, dirs, _ in os.walk(p):
            if base.replace("\\", "/").endswith("assets/minecraft"):
                return base
        sys.exit("assets/minecraft が見つかりません: " + p)

    def list(self):
        if self.zip:
            return list(self.names.keys())
        out = []
        for base, _, files in os.walk(self.dir):
            for f in files:
                out.append(os.path.relpath(os.path.join(base, f), self.dir).replace(os.sep, "/"))
        return out

    def read(self, rel):
        if self.zip:
            return self.zip.read(self.names[rel])
        with open(os.path.join(self.dir, rel), "rb") as f:
            return f.read()

    def has(self, rel):
        return rel in self.names if self.zip else os.path.exists(os.path.join(self.dir, rel))


def write(rel, data):
    p = os.path.join(DST, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "wb") as f:
        f.write(data)


def sync(pack_path, prune):
    manifest = json.load(open(os.path.join(ROOT, "assets_manifest.json"), encoding="utf-8"))
    pack = Pack(pack_path)
    allfiles = pack.list()
    wanted = set()

    for pat in manifest["textures"]:
        hits = [f for f in allfiles if fnmatch.fnmatch(f, pat)]
        if not hits:
            print("  ! 見つかりません:", pat)
        for h in hits:
            wanted.add(h)
            if pack.has(h + ".mcmeta"):
                wanted.add(h + ".mcmeta")

    sounds = json.loads(pack.read("sounds.json").decode("utf-8"))
    used = {}
    pending = list(manifest["sounds"])
    while pending:
        ev = pending.pop()
        if ev in used:
            continue
        if ev not in sounds:
            print("  ! サウンドイベントが見つかりません:", ev)
            continue
        used[ev] = sounds[ev]
        for s in sounds[ev]["sounds"]:
            name = s if isinstance(s, str) else s["name"]
            if isinstance(s, dict) and s.get("type") == "event":
                pending.append(name)
                continue
            rel = "sounds/" + name + ".ogg"
            if pack.has(rel):
                wanted.add(rel)
            else:
                print("  ! サウンドファイルなし:", rel)

    for rel in sorted(wanted):
        write(rel, pack.read(rel))
    with open(os.path.join(DST, "sounds.json"), "w", encoding="utf-8") as f:
        json.dump(used, f, ensure_ascii=False)
    wanted.add("sounds.json")

    if prune:
        for base, _, files in os.walk(DST):
            for fn in files:
                rel = os.path.relpath(os.path.join(base, fn), DST).replace(os.sep, "/")
                if rel not in wanted:
                    os.remove(os.path.join(base, fn))
                    print("  - 削除:", rel)
    print("コピー完了: %d ファイル" % len(wanted))


OUT = os.path.join(ROOT, "js", "asset_list.js")


def build_data(_unused=None):
    """js/asset_list.js を生成: ゲームが必要とするファイルの「場所と名前」の一覧(URLもデータも含まない)。
    ゲームは assets/minecraft/ の中のこのパスのファイルを読みます(マイクラのリソースパック方式)。"""
    textures, sounds_files = [], []
    for b, _, files in os.walk(DST):
        for fn in files:
            rel = os.path.relpath(os.path.join(b, fn), DST).replace(os.sep, "/")
            if rel.endswith(".png"):
                textures.append(rel)
            elif rel.endswith(".ogg"):
                sounds_files.append(rel)
    textures.sort(); sounds_files.sort()
    sounds = json.load(open(os.path.join(DST, "sounds.json"), encoding="utf-8"))
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("// 自動生成: tools/sync_assets.py\n")
        f.write("// ゲームが assets/minecraft/ から読むファイルの一覧(場所と名前)。画像/音のデータやURLは含みません。\n")
        f.write("window.ASSET_LIST = " + json.dumps({"textures": textures, "sounds": sounds_files}, indent=1) + ";\n\n")
        f.write("// サウンド定義(音量/ピッチ)\n")
        f.write("window.SOUNDS_JSON = " + json.dumps(sounds, ensure_ascii=False, separators=(",", ":")) + ";\n")
    print("js/asset_list.js 生成: textures %d / sounds %d" % (len(textures), len(sounds_files)))


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    flags = [a for a in sys.argv[1:] if a.startswith("--")]
    if "--rebuild-only" not in flags:
        if not args:
            print(__doc__)
            sys.exit(1)
        sync(args[0], "--prune" in flags)
    build_data()
