'use strict';
// ================================================================
//  キーバインド
// ================================================================
MC.Keys = {
  defs: [
    { id: 'forward', label: 'Walk Forwards', def: 'KeyW' },
    { id: 'left', label: 'Strafe Left', def: 'KeyA' },
    { id: 'back', label: 'Walk Backwards', def: 'KeyS' },
    { id: 'right', label: 'Strafe Right', def: 'KeyD' },
    { id: 'jump', label: 'Jump', def: 'Space' },
    { id: 'sneak', label: 'Sneak', def: 'ShiftLeft' },
    { id: 'sprint', label: 'Sprint', def: 'ControlLeft' },
    { id: 'attack', label: 'Attack/Destroy', def: 'Mouse0' },
    { id: 'use', label: 'Use Item/Place Block', def: 'Mouse2' },
    { id: 'inventory', label: 'Open/Close Inventory', def: 'KeyE' },
    { id: 'swap', label: 'Swap Item With Offhand', def: 'KeyF' },
    { id: 'reset', label: 'Reset Positions', def: 'KeyR' },
    { id: 'debug', label: 'Toggle Debug Info', def: 'F3' },
    { id: 'hitbox', label: 'Toggle Hitboxes', def: 'KeyH' },
    { id: 'perspective', label: 'Toggle Third Person', def: 'KeyV' },
    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => ({ id: 'hotbar' + n, label: 'Hotbar Slot ' + n, def: 'Digit' + n })),
  ],
  bind: {},
  down: new Set(),
  load() {
    for (const d of this.defs) this.bind[d.id] = d.def;
    try {
      const s = JSON.parse(localStorage.getItem('mcmace_keys') || '{}');
      for (const d of this.defs) if (typeof s[d.id] === 'string') this.bind[d.id] = s[d.id];
    } catch (e) {}
  },
  save() { try { localStorage.setItem('mcmace_keys', JSON.stringify(this.bind)); } catch (e) {} },
  set(id, code) { this.bind[id] = code; this.save(); this.down.clear(); if (MC.Game) MC.Game.clearInput(); },
  isDown(id) { return this.down.has(this.bind[id]); },
  idsFor(code) { return this.defs.filter(d => this.bind[d.id] === code).map(d => d.id); },
  label(code) {
    if (!code) return 'None';
    const m = { Mouse0: 'Left Button', Mouse1: 'Middle Button', Mouse2: 'Right Button', Space: 'Space', ShiftLeft: 'Left Shift', ShiftRight: 'Right Shift',
      ControlLeft: 'Left Control', ControlRight: 'Right Control', AltLeft: 'Left Alt', AltRight: 'Right Alt', ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right',
      Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Semicolon: ';', Quote: "'", Backslash: '\\', Comma: ',', Period: '.', Slash: '/', Tab: 'Tab', CapsLock: 'Caps Lock', Enter: 'Enter', Backspace: 'Backspace' };
    if (m[code]) return m[code];
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit\d$/.test(code)) return code.slice(5);
    if (/^Numpad/.test(code)) return 'Num ' + code.slice(6);
    if (/^Mouse\d/.test(code)) return 'Button ' + (parseInt(code.slice(5), 10) + 1);
    return code;
  },
};

// ================================================================
//  ゲーム本体
// ================================================================
const G = MC.Game = {
  tickCount: 0,
  msgs: [],
  hurtFlash: 0,
  nameTimer: 0,
  food: 20, sat: 5, exhaustion: 0,
  absorption: 0, absorbTicks: 0,
  attackTicker: 100,
  swinging: false, swingTicks: 0,
  useDelay: 0,
  eating: 0,                // 食事tick(0=していない)
  spearCharge: 0, chargeCd: 0,
  cooldowns: {},            // itemId -> 残りtick
  cooldownMax: {},
  projs: [], rockets: [],
  jumpCount: 0, pendingGlide: false, thirdPerson: false, lastForwardTap: 0, sprintToggle: false,
  stepDist: 0, nextStep: 1,
  elytraLoop: null,
  fps: 0,
  running: false,

  newEntity(x, y, z) {
    return { x, y, z, px: x, py: y, pz: z, vx: 0, vy: 0, vz: 0, hw: 0.3, h: 1.8, onGround: false, fall: 0, yaw: 0, pitch: 0,
      collX: false, collZ: false, collY: false, jumpDelay: 0, hurtTime: 0, invuln: 0, lastDmg: 0, gliding: false, sprinting: false, sneaking: false,
      limb: 0, limbAmt: 0, prevLimbAmt: 0 };
  },

  init() {
    MC.Keys.load();
    this.loadSettings();
    this.world = new MC.World(MC.CFG.worldSize);
    MC.Inventory.init();
    MC.Inventory.onEquipChange = (slot, now, before) => this.onEquipChange(slot, now, before);
    this.P = this.newEntity(0, 0, 0);
    this.N = this.newEntity(0, 0, 0);
    this.N.rotY = 0;
    this.resetPositions();
  },

  loadSettings() {
    try {
      const s = JSON.parse(localStorage.getItem('mcmace_settings') || '{}');
      for (const k of ['sensitivity', 'fov', 'masterVolume', 'infiniteItems', 'npcAttacks', 'showHitbox']) if (s[k] != null) MC.CFG[k] = s[k];
    } catch (e) {}
  },
  saveSettings() {
    try {
      const o = {}; for (const k of ['sensitivity', 'fov', 'masterVolume', 'infiniteItems', 'npcAttacks', 'showHitbox']) o[k] = MC.CFG[k];
      localStorage.setItem('mcmace_settings', JSON.stringify(o));
    } catch (e) {}
  },

  resetPositions() {
    const c = MC.CFG.worldSize / 2;
    const P = this.P, N = this.N;
    Object.assign(P, { jumpDelay: 0, x: c + 0.5, y: 0, z: c + 3.5, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0, fall: 0, gliding: false, sprinting: false, onGround: true, hurtTime: 0 });
    P.px = P.x; P.py = P.y; P.pz = P.z;
    Object.assign(N, { x: c + 0.5, y: 0, z: c - 0.5, vx: 0, vy: 0, vz: 0, fall: 0, onGround: true, hurtTime: 0, invuln: 0, rotY: 0 });
    N.px = N.x; N.py = N.y; N.pz = N.z;
    this.stopGlide(true);
    this.projs.length = 0; this.rockets.length = 0;
    this.eating = 0; this.spearCharge = 0;
    this.food = 20; this.sat = 5;
    this.msg('Positions reset', '#AAAAAA');
  },
  resetInventory() { MC.Inventory.init(); this.onEquipChange('chest', MC.Inventory.slots[38], null, true); this.msg('Inventory reset', '#AAAAAA'); },

  msg(text, color) { this.msgs.push({ text, color, t: performance.now() }); if (this.msgs.length > 12) this.msgs.shift(); },

  // ------------------------------------------------------------ 画面/入力
  startPlaying() {
    MC.Snd.resume();
    MC.GUI.screen = null; this.onScreenChange();
    this.running = true;
  },
  closeScreen() {
    if (MC.GUI.screen === 'inventory') MC.Inventory.returnAll();
    MC.GUI.screen = null; MC.GUI.prev = null; this.onScreenChange();
  },
  onScreenChange() {
    const s = MC.GUI.screen;
    if (s === null) {
      const cv = MC.Render.glCanvas;
      try { const r = cv.requestPointerLock(); if (r && r.catch) r.catch(() => {}); } catch (e) {}
    } else if (document.pointerLockElement) document.exitPointerLock();
    // 画面を開いたら押しっぱなしの状態をクリア
    if (s !== null) { this.eating = 0; this.spearCharge = 0; this.useHeld = false; }
    MC.Keys.down.clear(); this.clearInput();
    document.body.style.cursor = s === null ? 'none' : 'default';
  },
  simPaused() { const s = MC.GUI.screen; return s === 'pause' || s === 'keys' || s === 'start'; },

  keyDown(e) {
    const K = MC.Keys, GUI = MC.GUI;
    if (GUI.listening) {
      e.preventDefault();
      if (e.code === 'Escape') GUI.listening = null; else { K.set(GUI.listening, e.code); GUI.listening = null; }
      return;
    }
    if (e.code === 'F5' || e.code === 'F12' || (e.ctrlKey && e.code === 'KeyR' && false)) return;
    if (GUI.screen === 'start') return;
    e.preventDefault();
    if (e.repeat) return;
    if (e.code === 'Escape') {
      if (GUI.screen === 'keys') GUI.back();
      else if (GUI.screen === 'inventory') this.closeScreen();
      else if (GUI.screen === 'pause') this.closeScreen();
      return;
    }
    K.down.add(e.code);
    for (const id of K.idsFor(e.code)) this.onAction(id);
  },
  keyUp(e) { MC.Keys.down.delete(e.code); },
  /** 押しっぱなし状態を全部クリア(キー設定変更・画面遷移時の暴走防止) */
  clearInput() { this.jumpCount = 0; this.pendingGlide = false; this.useHeld = false; this.sprintToggle = false; },
  mouseDown(e) {
    const code = 'Mouse' + e.button;
    if (MC.GUI.screen !== null) { MC.GUI.mouseDown(e); return; }
    if (!document.pointerLockElement) { this.onScreenChange(); return; }
    MC.Keys.down.add(code);
    for (const id of MC.Keys.idsFor(code)) this.onAction(id);
  },
  mouseUp(e) {
    MC.Keys.down.delete('Mouse' + e.button);
    MC.GUI.mouseUp(e);
  },

  onAction(id) {
    const GUI = MC.GUI, inv = MC.Inventory;
    if (GUI.screen === 'inventory') {
      if (id === 'inventory') this.closeScreen();
      else if (id.startsWith('hotbar') && GUI.hoverSlot >= 0) inv.swapWithHotbar(GUI.hoverSlot, parseInt(id.slice(6), 10) - 1);
      else if (id === 'swap' && GUI.hoverSlot >= 0 && GUI.hoverSlot !== inv.OFF) {
        const a = inv.slots[GUI.hoverSlot], b = inv.slots[inv.OFF];
        if (inv.accepts(GUI.hoverSlot, b)) { inv.slots[GUI.hoverSlot] = b; inv.slots[inv.OFF] = a; }
      }
      return;
    }
    if (GUI.screen !== null) return;
    switch (id) {
      case 'inventory': GUI.open('inventory'); break;
      case 'swap': inv.swapOffhand(); this.nameTimer = 40; break;
      case 'reset': this.resetPositions(); break;
      case 'debug': MC.CFG.showDebug = !MC.CFG.showDebug; break;
      case 'jump': this.jumpCount++; break;
      case 'hitbox': MC.CFG.showHitbox = !MC.CFG.showHitbox; this.saveSettings(); break;
      case 'perspective': this.thirdPerson = !this.thirdPerson; break;
      case 'attack': this.attack(); break;
      case 'use': this.useHeld = true; this.useItem(true); this.useDelay = 4; break;
      case 'forward': {
        const now = performance.now();
        if (now - this.lastForwardTap < 300 && !this.P.sneaking) this.sprintToggle = true;
        this.lastForwardTap = now; break;
      }
      default:
        if (id.startsWith('hotbar')) this.selectSlot(parseInt(id.slice(6), 10) - 1);
    }
  },
  selectSlot(i) {
    const inv = MC.Inventory;
    if (inv.selected === i) return;
    inv.selected = i; this.nameTimer = 40; this.eating = 0; this.spearCharge = 0;
  },
  wheel(e) {
    if (MC.GUI.screen === 'keys') { MC.GUI.wheel(e); return; }
    if (MC.GUI.screen !== null) return;
    const inv = MC.Inventory;
    this.selectSlot((inv.selected + (e.deltaY > 0 ? 1 : -1) + 9) % 9);
  },
  mouseMove(e) {
    if (MC.GUI.screen !== null) { MC.GUI.mouseMove(e); return; }
    if (!document.pointerLockElement) return;
    const f = MC.CFG.sensitivity * 0.6 + 0.2, k = f * f * f * 8 * 0.15 * MC.DEG;
    const P = this.P;
    P.yaw -= e.movementX * k;
    P.pitch = MC.clamp(P.pitch - e.movementY * k, -90 * MC.DEG, 90 * MC.DEG);
  },

  // ------------------------------------------------------------ 補助
  look(P) {
    const cp = Math.cos(P.pitch);
    return { x: -Math.sin(P.yaw) * cp, y: Math.sin(P.pitch), z: -Math.cos(P.yaw) * cp };
  },
  eyeOff(P) { return P.gliding ? MC.CFG.eyeHeightGlide : P.sneaking ? MC.CFG.eyeHeightSneak : MC.CFG.eyeHeight; },
  eyeY(P) { return P.y + this.eyeOff(P); },
  poseHeight(P) { return P.gliding ? MC.CFG.playerHGlide : P.sneaking ? MC.CFG.playerHSneak : MC.CFG.playerH; },
  cooldownFrac(id) { const c = this.cooldowns[id]; return c > 0 ? c / this.cooldownMax[id] : 0; },
  setCooldown(id, t) { this.cooldowns[id] = t; this.cooldownMax[id] = t; },
  attackPeriod(def) { return def && def.speed ? 20 / def.speed : 5; },
  attackStrength(partial) {
    const inv = MC.Inventory, def = inv.held() ? MC.ITEMS[inv.held().id] : null;
    return MC.clamp((this.attackTicker + (partial || 0)) / this.attackPeriod(def), 0, 1);
  },
  attackProgress() { return this.attackStrength(0.5); },
  consume(slot) {
    if (MC.CFG.infiniteItems) return;
    const inv = MC.Inventory, s = inv.slots[slot];
    if (!s) return; s.count--; if (s.count <= 0) inv.slots[slot] = null;
  },
  sound(ev, o, ent) {
    o = o || {};
    if (ent) o.pos = { x: ent.x, y: ent.y + 1, z: ent.z };
    return MC.Snd.play(ev, o);
  },
  armorSound(stack) {
    if (!stack) return;
    this.sound(stack.id === 'elytra' ? 'item.armor.equip_elytra' : 'item.armor.equip_netherite');
  },
  onEquipChange(slot, now, before, silent) {
    if (MC.Render && MC.Render.syncEquipment) MC.Render.syncEquipment();
    if (!silent) this.armorSound(now);
  },
  aabb(e, grow) { grow = grow || 0; return [e.x - e.hw - grow, e.y - grow, e.z - e.hw - grow, e.x + e.hw + grow, e.y + e.h + grow, e.z + e.hw + grow]; },
  rayAABB(ox, oy, oz, dx, dy, dz, b, maxT) {
    let t0 = 0, t1 = maxT;
    const o = [ox, oy, oz], d = [dx, dy, dz];
    for (let i = 0; i < 3; i++) {
      if (Math.abs(d[i]) < 1e-9) { if (o[i] < b[i] || o[i] > b[i + 3]) return null; }
      else {
        let a = (b[i] - o[i]) / d[i], c = (b[i + 3] - o[i]) / d[i];
        if (a > c) { const t = a; a = c; c = t; }
        t0 = Math.max(t0, a); t1 = Math.min(t1, c);
        if (t0 > t1) return null;
      }
    }
    return t0;
  },

  // ------------------------------------------------------------ 攻撃
  swing() { this.swinging = true; this.swingTicks = 0; },

  attack() {
    const inv = MC.Inventory, P = this.P, N = this.N;
    const st = inv.held(), def = st ? MC.ITEMS[st.id] : null;
    const type = def ? def.type : 'fist';
    const strength = this.attackStrength(0.5);
    this.swing();
    let reach = type === 'spear' ? MC.CFG.spearReach : MC.CFG.reach;
    // スピア: Lunge
    if (type === 'spear') {
      this.sound('item.spear.attack', { vol: 1 });
      if (def.lunge && !P.gliding && this.food >= MC.CFG.lungeMinFood && strength > 0.0) this.lunge(def.lunge);
    }
    const l = this.look(P);
    const ex = P.x, ey = this.eyeY(P), ez = P.z;
    const t = this.rayAABB(ex, ey, ez, l.x, l.y, l.z, this.aabb(N, 0.05), reach);
    const wasTicker = this.attackTicker;
    this.attackTicker = 0;
    if (t == null) return;
    this.hitNpc(def, type, strength, l, t);
  },

  lunge(level) {
    const P = this.P, l = this.look(P), m = MC.CFG.lungeImpulse[level - 1];
    P.vx += l.x * m; P.vz += l.z * m;             // assets: coordinate_scale [1,0,1] = 水平方向のみ
    this.addExhaustion(4 * MC.CFG.lungeHunger[level - 1]);
    this.sound('item.spear.lunge_' + level, { vol: 1 });
  },
  addExhaustion(v) {
    this.exhaustion += v;
    while (this.exhaustion >= 4) {
      this.exhaustion -= 4;
      if (this.sat > 0) this.sat = Math.max(0, this.sat - 1); else this.food = Math.max(0, this.food - 1);
    }
  },

  smashBonus(f) { return f <= 3 ? 4 * f : f <= 8 ? 12 + 2 * (f - 3) : 22 + (f - 8); },

  hitNpc(def, type, strength, l, tHit) {
    const P = this.P, N = this.N, inv = MC.Inventory, PT = MC.Particles;
    const fallBefore = P.fall;
    const base = def ? (def.dmg || 1) : 1;
    const smash = type === 'mace' && P.fall > 1.5 && !P.gliding;
    const crit = !smash && strength > 0.9 && P.fall > 0 && !P.onGround && !P.sprinting && type !== 'fist';
    let dmg = base * (0.2 + strength * strength * 0.8);
    if (crit) dmg *= 1.5;
    const bonus = smash ? this.smashBonus(P.fall) * strength : 0;
    const total = dmg + bonus;
    const hx = P.x + l.x * tHit, hy = this.eyeY(P) + l.y * tHit, hz = P.z + l.z * tHit;
    const mid = { x: N.x, y: N.y + 1.0, z: N.z };

    if (N.invuln > 10) return;                // 無敵時間中
    N.invuln = 20; N.lastDmg = total; N.hurtTime = 10;
    this.sound('entity.player.hurt', {}, N);

    // 効果音
    const sprintHit = P.sprinting && strength > 0.9;
    if (smash) {
      const heavy = P.fall > 5;
      this.sound(N.onGround ? (heavy ? 'item.mace.smash_ground_heavy' : 'item.mace.smash_ground') : 'item.mace.smash_air', { vol: 1 }, N);
    } else if (type === 'spear') {
      this.sound('item.spear.hit', { vol: 1 }, N);
    } else if (crit) this.sound('entity.player.attack.crit', {}, N);
    else if (strength > 0.9) this.sound(sprintHit ? 'entity.player.attack.knockback' : (type === 'sword' && P.onGround ? 'entity.player.attack.sweep' : 'entity.player.attack.strong'), {}, N);
    else this.sound('entity.player.attack.weak', {}, N);
    if (type === 'sword' && strength > 0.9 && !sprintHit && !crit && P.onGround) PT.sweep(P.x + l.x * 1.2, this.eyeY(P) - 0.3 + l.y, P.z + l.z * 1.2);

    // ノックバック(ネザライトは耐性あり)
    let kb = 0.4 + (sprintHit ? 0.5 : 0);
    this.knockback(N, kb, P.x - N.x, P.z - N.z, 0.4);
    if (sprintHit) { P.vx *= 0.6; P.vz *= 0.6; P.sprinting = false; this.sprintToggle = false; }

    // パーティクル
    if (crit) { PT.crit(hx, hy, hz, 12); }
    if (total > 4) PT.hearts(mid.x, N.y + 1.6, mid.z, Math.min(10, Math.floor(total / 4)));

    let label = (def ? def.name : 'Fist');
    if (smash) {
      label = 'Mace SMASH';
      // 周囲ノックバック風(対象自身にも少し強め)
      const heavy = P.fall > 5 ? 2 : 1;
      const dx = N.x - P.x, dz = N.z - P.z, dl = Math.hypot(dx, dz) || 1;
      N.vx += dx / dl * 0.9 * heavy * (1 - inv.knockbackResist()); N.vz += dz / dl * 0.9 * heavy * (1 - inv.knockbackResist()); N.vy = Math.max(N.vy, 0.7);
      if (N.onGround) PT.dust(N.x, 0, N.z, 28, heavy); else PT.gust(N.x, N.y + 0.5, N.z, false);
      const fallShown = fallBefore;
      P.vy = 0.01;                                   // スマッシュ後は落下が止まる
      this.msg('[' + label + '] fall ' + fallShown.toFixed(1) + ' blocks -> ' + total.toFixed(1) + ' dmg (smash +' + bonus.toFixed(1) + ')', '#FFAA00');
    } else {
      this.msg('[' + label + '] ' + total.toFixed(1) + ' dmg' + (crit ? ' (crit)' : '') + (strength < 0.9 ? ' (weak ' + Math.round(strength * 100) + '%)' : ''), '#FFFFFF');
    }

    // Wind Burst: assetsの条件は「落下距離 >= 1.5」(スマッシュ/滑空中かは問わない)
    const wb = (type === 'mace' && def.windBurst) || 0;
    if (wb > 0 && fallBefore >= 1.5) {
      P.vy = MC.CFG.windBurstVy[wb - 1];
      P.fall = 0;
      this.sound('entity.wind_charge.wind_burst', { vol: 1.2 }, P);
      PT.gust(P.x, P.y - 0.3, P.z, true);
      if (!smash) this.msg('[Wind Burst ' + MC.Item.roman(wb) + '] fall ' + fallBefore.toFixed(1) + ' (no smash while gliding)', '#55FFFF');
    } else if (smash) P.fall = 0;
  },

  /** マイクラ式ノックバック。(dx,dz)=攻撃者 - 対象 */
  knockback(e, strength, dx, dz, maxUp) {
    const res = e === this.P ? MC.Inventory.knockbackResist() : MC.Inventory.knockbackResist();
    strength *= 1 - res;
    if (strength <= 0) return;
    let d = Math.hypot(dx, dz);
    if (d < 1e-4) { const a = Math.random() * Math.PI * 2; dx = Math.cos(a); dz = Math.sin(a); d = 1; }
    dx /= d; dz /= d;
    e.vx = e.vx / 2 - dx * strength;
    e.vz = e.vz / 2 - dz * strength;
    if (e.onGround) e.vy = Math.min(maxUp == null ? 0.4 : maxUp, e.vy / 2 + strength);
  },

  hurtMe(dx, dz, strength) {
    const P = this.P;
    this.hurtFlash = 1; P.hurtTime = 10;
    this.sound('entity.player.hurt');
    this.knockback(P, strength, dx, dz);
  },

  // ------------------------------------------------------------ アイテム使用
  useItem(press) {
    const inv = MC.Inventory, P = this.P;
    const st = inv.held();
    if (!st) return;
    const def = MC.ITEMS[st.id];
    switch (def.type) {
      case 'elytra': case 'armor':
        if (!press) return;
        if (inv.useEquip()) { this.nameTimer = 40; this.reequip = true; }
        break;
      case 'pearl': this.throwProjectile('pearl', st); break;
      case 'windcharge': this.throwProjectile('wind', st); break;
      case 'rocket': if (P.gliding) this.launchRocket(); break;
      case 'food':
        if (this.eating === 0 && this.food < 20 + 1) { this.eating = 1; }
        break;
      case 'spear':
        if (press && this.spearCharge === 0) { this.spearCharge = 1; this.sound('item.spear.use', { vol: 1 }); }
        break;
    }
  },

  throwProjectile(kind, st) {
    const P = this.P, l = this.look(P);
    const id = kind === 'pearl' ? 'ender_pearl' : 'wind_charge';
    if (this.cooldowns[id] > 0) return;
    this.swing();
    this.setCooldown(id, kind === 'pearl' ? MC.CFG.pearlCooldown : MC.CFG.windChargeCooldown);
    if (kind === 'pearl') this.sound('entity.ender_pearl.throw', { vol: 0.5, pitch: 0.4 / (Math.random() * 0.4 + 0.8) });
    else this.sound('entity.wind_charge.throw', { vol: 0.5, pitch: 1 / (Math.random() * 0.4 + 0.8) });
    const u = 0.0075;
    let dx = l.x + MC.gauss() * u, dy = l.y + MC.gauss() * u, dz = l.z + MC.gauss() * u;
    const len = Math.hypot(dx, dy, dz); dx /= len; dy /= len; dz /= len;
    const pr = {
      kind, x: P.x, y: this.eyeY(P) - 0.1, z: P.z,
      vx: dx * 1.5 + P.vx, vy: dy * 1.5 + (P.onGround ? 0 : P.vy), vz: dz * 1.5 + P.vz,
      age: 0, px: 0, py: 0, pz: 0,
    };
    pr.px = pr.x; pr.py = pr.y; pr.pz = pr.z;
    this.projs.push(pr);
    this.consume(MC.Inventory.selected);
  },

  launchRocket() {
    const flight = MC.CFG.fireworkFlight;
    const life = 10 * flight + MC.randInt(6) + MC.randInt(7);
    this.rockets.push({ age: 0, life });
    this.swing();
    this.sound('entity.firework_rocket.launch', { vol: 3 });
    this.consume(MC.Inventory.selected);
  },

  explodeWind(cx, cy, cz, skipPearls) {
    const R = MC.CFG.windChargeRadius, K = MC.CFG.windChargeKnock;
    this.sound('entity.wind_charge.wind_burst', { vol: 1 }, { x: cx, y: cy - 1, z: cz });
    MC.Particles.gust(cx, cy, cz, false);
    for (const e of [this.P, this.N]) {
      const ey = e.y + (e === this.P ? this.eyeY(e) - e.y : 1.62);
      let dx = e.x - cx, dy = ey - cy, dz = e.z - cz;
      const d = Math.hypot(dx, dy, dz);
      if (d >= R) continue;
      if (d < 1e-3) { dx = 0; dy = 1; dz = 0; } else { dx /= d; dy /= d; dz /= d; }
      const k = (1 - d / R) * K;
      e.vx += dx * k; e.vy += dy * k; e.vz += dz * k;
      e.fall = 0;
      if (e === this.N) { this.N.hurtTime = 0; }
    }
    // 爆風に巻き込まれた飛行中のエンダーパールも反応してテレポート
    if (!skipPearls) {
      for (const q of this.projs) {
        if (q.kind !== 'pearl' || q.dead) continue;
        if (Math.hypot(q.x - cx, q.y - cy, q.z - cz) < 2.2) { q.dead = true; this.teleportPlayer(q.x, q.y, q.z, 0, 0, 0); }
      }
    }
  },

  teleportPlayer(x, y, z, nx, ny, nz) {
    const P = this.P, PT = MC.Particles;
    PT.portal(P.x, P.y, P.z, 36);
    this.sound('entity.player.teleport', { vol: 1 }, P);
    P.x = x + nx * P.hw; P.z = z + nz * P.hw;
    P.y = y + (ny < 0 ? -P.h - 0.01 : 0);
    // 埋まっていたら押し出す
    for (let i = 0; i < 40 && this.world.boxesIn(P.x - P.hw + 0.001, P.y + 0.001, P.z - P.hw + 0.001, P.x + P.hw - 0.001, P.y + P.h - 0.001, P.z + P.hw - 0.001).length; i++) P.y += 0.1;
    P.px = P.x; P.py = P.y; P.pz = P.z;
    P.fall = 0;
    PT.portal(P.x, P.y, P.z, 36);
    this.sound('entity.player.teleport', { vol: 1 }, P);
  },

  updateProjectiles() {
    const w = this.world, N = this.N;
    // ウィンドチャージとエンダーパールが当たったら: ウィンドチャージは爆発し、パールが反応してテレポート
    for (const a of this.projs) {
      if (a.kind !== 'wind' || a.dead) continue;
      for (const b of this.projs) {
        if (b.kind !== 'pearl' || b.dead) continue;
        const rx = a.x - b.x, ry = a.y - b.y, rz = a.z - b.z;
        const vx = a.vx - b.vx, vy = a.vy - b.vy, vz = a.vz - b.vz;
        const vv = vx * vx + vy * vy + vz * vz;
        const t = vv > 1e-9 ? MC.clamp(-(rx * vx + ry * vy + rz * vz) / vv, 0, 1) : 0;
        const d = Math.hypot(rx + vx * t, ry + vy * t, rz + vz * t);
        if (d < 0.6) {
          a.dead = true;
          const wx = a.x + a.vx * t, wy = a.y + a.vy * t, wz = a.z + a.vz * t;
          const pe = { x: b.x + b.vx * t, y: b.y + b.vy * t, z: b.z + b.vz * t };
          b.dead = true;
          this.teleportPlayer(pe.x, pe.y, pe.z, 0, 0, 0);
          this.explodeWind(wx, wy, wz, true);
          break;
        }
      }
    }
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const p = this.projs[i];
      if (p.dead) { this.projs.splice(i, 1); continue; }
      p.px = p.x; p.py = p.y; p.pz = p.z;
      p.age++;
      const len = Math.hypot(p.vx, p.vy, p.vz) || 1e-6;
      let tBlock = null, tEnt = null, n = null;
      const rb = w.raycast(p.x, p.y, p.z, p.vx, p.vy, p.vz, 1);
      if (rb) { tBlock = rb.t; n = rb; }
      if (p.age > 2) {
        const te = this.rayAABB(p.x, p.y, p.z, p.vx, p.vy, p.vz, this.aabb(N, 0.15), 1);
        if (te != null) tEnt = te;
      }
      let t = null, hitEnt = false;
      if (tBlock != null && (tEnt == null || tBlock <= tEnt)) t = tBlock;
      else if (tEnt != null) { t = tEnt; hitEnt = true; }
      if (t != null) {
        const hx = p.x + p.vx * t, hy = p.y + p.vy * t, hz = p.z + p.vz * t;
        if (p.kind === 'pearl') {
          const nx = n && !hitEnt ? n.nx : 0, ny = n && !hitEnt ? n.ny : 0, nz = n && !hitEnt ? n.nz : 0;
          this.teleportPlayer(hx, hy, hz, nx, ny, nz);
        } else {
          this.explodeWind(hx, hy, hz);
          if (hitEnt) { this.knockback(N, 0.4, this.P.x - N.x, this.P.z - N.z); this.sound('entity.player.hurt', {}, N); N.hurtTime = 10; }
        }
        this.projs.splice(i, 1);
        continue;
      }
      p.x += p.vx; p.y += p.vy; p.z += p.vz;
      if (p.kind === 'pearl') {
        p.vx *= 0.99; p.vy *= 0.99; p.vz *= 0.99; p.vy -= 0.03;
        if (p.age % 1 === 0) MC.Particles.portal(p.x, p.y - 0.1, p.z, 1);
      } else {
        if (p.age % 2 === 0) MC.Particles.smoke(p.x, p.y, p.z);
      }
      if (p.age > 400 || p.y < -20) this.projs.splice(i, 1);
    }
  },

  // ------------------------------------------------------------ エリトラ
  startGlide() {
    const P = this.P;
    P.gliding = true; P.sprinting = false; P.h = MC.CFG.playerHGlide;
    if (!this.elytraLoop) this.elytraLoop = MC.Snd.loop('item.elytra.flying');
  },
  stopGlide(silent) {
    this.P.gliding = false; this.P.h = this.poseHeight(this.P);
    if (this.elytraLoop) { this.elytraLoop.stop(); this.elytraLoop = null; }
  },

  elytraTravel(e) {
    const l = this.look(e), w = this.world;
    let vx = e.vx, vy = e.vy, vz = e.vz;
    const pitch = e.pitch;
    const lookH = Math.hypot(l.x, l.z);
    const moveH = Math.hypot(vx, vz);
    const lift = Math.pow(Math.cos(pitch), 2);
    vy += 0.08 * (-1 + lift * 0.75);
    if (vy < 0 && lookH > 0) {
      const d = vy * -0.1 * lift;
      vx += l.x * d / lookH; vy += d; vz += l.z * d / lookH;
    }
    if (pitch > 0 && lookH > 0) {                  // 上を向いているとき(マイクラのxRot<0)に速度→高度へ変換
      const d = moveH * Math.sin(pitch) * 0.04;
      vx += -l.x * d / lookH; vy += d * 3.2; vz += -l.z * d / lookH;
    }
    if (lookH > 0) {
      vx += (l.x / lookH * moveH - vx) * 0.1;
      vz += (l.z / lookH * moveH - vz) * 0.1;
    }
    e.vx = vx * 0.99; e.vy = vy * 0.98; e.vz = vz * 0.99;
    w.move(e, e.vx, e.vy, e.vz);
    if (e.collX) e.vx = 0; if (e.collZ) e.vz = 0; if (e.collY) e.vy = 0;
  },

  walkTravel(e, forward, strafe, sprint) {
    const w = this.world;
    const friction = e.onGround ? 0.546 : 0.91;
    const accel = e.onGround ? (sprint ? 0.13 : 0.1) * (0.21600002 / (friction * friction * friction)) : (sprint ? 0.026 : 0.02);
    let d = Math.hypot(strafe, forward);
    if (d >= 0.01) {
      if (d < 1) d = 1;
      const k = accel / d; strafe *= k; forward *= k;
      const sy = Math.sin(e.yaw), cy = Math.cos(e.yaw);
      e.vx += -sy * forward + cy * strafe;
      e.vz += -cy * forward - sy * strafe;
    }
    w.move(e, e.vx, e.vy, e.vz);
    if (e.collX) e.vx = 0; if (e.collZ) e.vz = 0; if (e.collY) e.vy = 0;
    e.vy = (e.vy - 0.08) * 0.98;
    e.vx *= friction; e.vz *= friction;
  },

  afterMove(e, prevOnGround) {
    if (e.onGround) {
      if (!prevOnGround && e.fall > 1 && e === this.P) {
        this.sound('block.grass.step', { vol: Math.min(1, 0.3 + e.fall * 0.05), pitch: 0.75 });
        if (e.fall > 3) MC.Particles.dust(e.x, 0, e.z, Math.min(14, Math.floor(e.fall)), 0.4);
      }
      e.fall = 0;
    } else if (e.movedY < 0) e.fall -= e.movedY;
  },

  // ------------------------------------------------------------ 1tick
  tick() {
    const K = MC.Keys, inv = MC.Inventory, P = this.P, N = this.N, cfg = MC.CFG;
    this.tickCount++;
    const open = MC.GUI.screen !== null;
    P.px = P.x; P.py = P.y; P.pz = P.z; N.px = N.x; N.py = N.y; N.pz = N.z;
    P.prevYaw = P.yaw;

    // 入力
    let fwd = 0, str = 0, jump = false;
    if (!open) {
      fwd = (K.isDown('forward') ? 1 : 0) - (K.isDown('back') ? 1 : 0);
      str = (K.isDown('right') ? 1 : 0) - (K.isDown('left') ? 1 : 0);
      jump = K.isDown('jump');
    }
    P.sneaking = !open && K.isDown('sneak') && !P.gliding;
    P.h = this.poseHeight(P);
    if (fwd <= 0) this.sprintToggle = false;
    const canSprint = fwd > 0 && !P.sneaking && this.food > 6 && !P.gliding;
    if (canSprint && (K.isDown('sprint') || this.sprintToggle) && !open) P.sprinting = true;
    else if (!canSprint || (P.collX || P.collZ)) { P.sprinting = false; if (!canSprint) this.sprintToggle = false; }
    if (!K.isDown('sprint') && !this.sprintToggle && fwd <= 0) P.sprinting = false;
    let mf = fwd * 0.98, ms = str * 0.98;
    if (P.sneaking) { mf *= 0.3; ms *= 0.3; }

    // 装備からエリトラが消えたら滑空終了
    if (P.gliding && (P.onGround || !inv.hasElytra())) this.stopGlide();
    // 滑空開始(空中でジャンプキーを押し直す)
    // ダブルジャンプ: 空中でジャンプを押した(or 同tick内に2回押した)らその場で即グライド。落下中かどうかは問わない
    const jc = this.jumpCount; this.jumpCount = 0;
    if (jc > 0 && !open && inv.hasElytra() && !P.gliding) {
      if (!P.onGround) this.startGlide();
      else if (jc >= 2) this.pendingGlide = true;
    }

    // ロケット加速(滑空中)
    for (let i = this.rockets.length - 1; i >= 0; i--) {
      const r = this.rockets[i];
      r.age++;
      if (P.gliding) {
        const l = this.look(P);
        P.vx += l.x * 0.1 + (l.x * 1.5 - P.vx) * 0.5;
        P.vy += l.y * 0.1 + (l.y * 1.5 - P.vy) * 0.5;
        P.vz += l.z * 0.1 + (l.z * 1.5 - P.vz) * 0.5;
        const bx = P.x - l.x * 0.6, by = this.eyeY(P) - 0.5 - l.y * 0.6, bz = P.z - l.z * 0.6;
        MC.Particles.spark(bx, by, bz, -l.x * 0.15 + MC.rand(-0.05, 0.05), -l.y * 0.15 + MC.rand(-0.05, 0.05), -l.z * 0.15 + MC.rand(-0.05, 0.05));
        MC.Particles.smoke(bx, by, bz);
      }
      if (r.age >= r.life || !P.gliding) this.rockets.splice(i, 1);
    }

    // ジャンプ
    if (P.jumpDelay > 0) P.jumpDelay--;
    if (jump && P.onGround && P.jumpDelay === 0 && !P.gliding) {
      P.vy = Math.max(0.42, P.vy);
      if (P.sprinting) { P.vx += -Math.sin(P.yaw) * 0.2; P.vz += -Math.cos(P.yaw) * 0.2; }
      P.jumpDelay = 10;
      if (this.pendingGlide && inv.hasElytra()) this.startGlide();
    }
    this.pendingGlide = false;

    // 移動
    const wasGround = P.onGround;
    if (P.gliding) {
      if (P.vy > -0.5 && P.fall > 1) P.fall = 1;      // マイクラ: 緩やかな滑空では落下距離が1に抑えられる
      this.elytraTravel(P);
    } else this.walkTravel(P, mf, ms, P.sprinting);
    this.afterMove(P, wasGround);
    // 滑空中の(小さい)当たり判定が地面に触れたら滑空解除
    if (P.gliding && (P.onGround || P.y <= 1e-4)) this.stopGlide();

    // 足音
    const hs = Math.hypot(P.x - P.px, P.z - P.pz);
    this.stepDist += hs * 0.6;
    if (this.stepDist > this.nextStep) {
      this.nextStep = this.stepDist + 1;
      if (P.onGround && !P.sneaking && hs > 0.01) this.sound('block.grass.step', { vol: 0.15, pitch: 1 });
    }
    P.prevLimbAmt = P.limbAmt;
    P.limbAmt += (Math.min(1, hs * 4) - P.limbAmt) * 0.4;
    P.limb += hs * 4;

    // NPC
    this.updateNpc();

    // タイマ類
    this.attackTicker++;
    if (this.swinging) { this.swingTicks++; if (this.swingTicks >= 6) { this.swinging = false; this.swingTicks = 0; } }
    if (this.useDelay > 0) this.useDelay--;
    for (const id in this.cooldowns) if (this.cooldowns[id] > 0) this.cooldowns[id]--;
    if (P.hurtTime > 0) P.hurtTime--;
    if (N.hurtTime > 0) N.hurtTime--;
    if (N.invuln > 0) N.invuln--;
    this.hurtFlash = Math.max(0, this.hurtFlash - 0.1);
    if (this.nameTimer > 0) this.nameTimer--;
    if (this.absorbTicks > 0) { this.absorbTicks--; if (this.absorbTicks === 0) this.absorption = 0; }

    // 右クリック長押し / 左クリック長押し
    if (!open) {
      const held = inv.held(), def = held ? MC.ITEMS[held.id] : null;
      if (K.isDown('use') && def) {
        if (def.type === 'food') this.tickEating(held);
        else if (def.type === 'spear') this.tickSpear(def);
        else if (this.useDelay === 0 && def.type !== 'elytra' && def.type !== 'armor') { this.useItem(false); this.useDelay = 4; }
        else if (this.useDelay === 0) this.useDelay = 4;
      } else { this.eating = 0; this.spearCharge = 0; }
      if (K.isDown('attack') && this.attackStrength(0.5) >= 1) this.attack();
    }
    this.updateProjectiles();
  },

  tickEating(held) {
    if (this.eating === 0) { if (this.food < 20 + 1) this.eating = 1; else return; }
    this.eating++;
    const t = this.eating;
    if (t >= 7 && t % 4 === 0 && t < MC.CFG.eatTicks) {
      this.sound('entity.generic.eat', { vol: 0.5 + 0.5 * MC.randInt(2), pitch: (Math.random() - Math.random()) * 0.2 + 1 });
      const l = this.look(this.P);
      MC.Particles.crumbs(this.P.x + l.x * 0.5, this.eyeY(this.P) - 0.3 + l.y * 0.5, this.P.z + l.z * 0.5, 5);
    }
    if (t >= MC.CFG.eatTicks) {
      const d = MC.ITEMS[held.id];
      this.food = Math.min(20, this.food + d.food);
      this.sat = Math.min(this.food, this.sat + d.saturation);
      this.absorption = 4; this.absorbTicks = 2400;
      this.sound('entity.player.burp', { vol: 0.5, pitch: Math.random() * 0.1 + 0.9 });
      this.consume(MC.Inventory.selected);
      this.eating = 0;
    }
  },

  tickSpear(def) {
    const P = this.P, N = this.N;
    this.spearCharge++;
    if (this.chargeCd > 0) { this.chargeCd--; return; }
    const l = this.look(P);
    const t = this.rayAABB(P.x, this.eyeY(P), P.z, l.x, l.y, l.z, this.aabb(N, 0.125), MC.CFG.spearReach);
    if (t == null) return;
    const rel = ((P.vx - N.vx) * l.x + (P.vy - N.vy) * l.y + (P.vz - N.vz) * l.z) * 20;
    if (rel < 2) return;
    const dmg = def.dmg + rel * 0.7;
    this.chargeCd = 10;
    N.hurtTime = 10; N.invuln = 20;
    this.sound('item.spear.hit', { vol: 1 }, N);
    this.sound('entity.player.hurt', {}, N);
    this.knockback(N, 0.4 + Math.min(1.2, rel * 0.06), P.x - N.x, P.z - N.z);
    MC.Particles.crit(N.x, N.y + 1, N.z, 8);
    this.msg('[Spear charge] rel. speed ' + rel.toFixed(1) + ' b/s -> ' + dmg.toFixed(1) + ' dmg', '#55FFFF');
  },

  // ------------------------------------------------------------ NPC
  updateNpc() {
    const N = this.N, P = this.P, cfg = MC.CFG;
    let fwd = 0;
    const dx = P.x - N.x, dz = P.z - N.z, dist = Math.hypot(dx, dz);
    if (N.onGround || true) {
      const target = Math.atan2(dx, dz);
      let diff = target - N.rotY; while (diff > Math.PI) diff -= 2 * Math.PI; while (diff < -Math.PI) diff += 2 * Math.PI;
      N.rotY += diff * 0.3;
    }
    N.yaw = Math.PI + (N.rotY);       // 移動計算用: 前方=(-sin yaw,-cos yaw)=(sin rotY, cos rotY)
    if (cfg.npcAttacks) {
      if (dist > cfg.npcReach - 0.8 && dist < 24 && N.onGround) fwd = 1;
      this.npcAtk = (this.npcAtk || 0) + 1;
      if (dist < cfg.npcReach && Math.abs(P.y - N.y) < 2 && this.npcAtk > 24) {
        this.npcAtk = 0; N.swingT = 6;
        this.sound('entity.player.attack.strong', {}, N);
        this.hurtMe(N.x - P.x, N.z - P.z, 0.4);
      }
    }
    const wasGround = N.onGround;
    this.walkTravel(N, fwd * 0.98 * 0.5, 0, false);
    this.afterMove(N, wasGround);
    const hs = Math.hypot(N.x - N.px, N.z - N.pz);
    N.prevLimbAmt = N.limbAmt;
    N.limbAmt += (Math.min(1, hs * 4) - N.limbAmt) * 0.4; N.limb += hs * 4;
    if (N.swingT > 0) N.swingT--;
  },

  debugLines() {
    const P = this.P;
    const sp = Math.hypot(P.vx, P.vz) * 20, spt = Math.hypot(P.vx, P.vy, P.vz) * 20;
    const st = this.attackStrength(0);
    return [
      'FPS: ' + Math.round(this.fps) + '   (F3: toggle)',
      'XYZ: ' + P.x.toFixed(2) + ' / ' + P.y.toFixed(2) + ' / ' + P.z.toFixed(2),
      'Speed: ' + sp.toFixed(1) + ' b/s (horizontal)  ' + spt.toFixed(1) + ' b/s (total)  vy ' + (P.vy * 20).toFixed(1),
      'Fall Distance: ' + P.fall.toFixed(2) + (P.fall > 1.5 && !P.gliding ? '  [SMASH READY]' : ''),
      'Hitbox: ' + (P.hw * 2).toFixed(1) + ' x ' + P.h.toFixed(1) + '  eye ' + this.eyeOff(P).toFixed(2) + '   [H] hitbox  [V] 3rd person',
      'State: ' + (P.gliding ? 'GLIDING' : P.onGround ? 'ground' : 'air') + (P.sprinting ? ' sprint' : '') + (P.sneaking ? ' sneak' : '') + '   Atk ' + Math.round(st * 100) + '%',
    ];
  },
};
