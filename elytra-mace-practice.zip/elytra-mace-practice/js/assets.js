'use strict';
// ================================================================
//  アセット読み込み(assets_data.js に埋め込まれたdata URIを使う)
//  → file:// で直接 index.html を開いても動くようにするため
// ================================================================
MC.Assets = {
  img: {},      // 'textures/item/mace.png' -> HTMLImageElement
  _tex: {},     // three.js テクスチャキャッシュ
  loaded: 0,
  total: 0,

  /** assets/minecraft/ の中の「場所と名前」が合うファイルを読み込む(リソースパック方式) */
  async load(onProgress) {
    await MC.Pack.open();
    const keys = (window.ASSET_LIST && window.ASSET_LIST.textures) || [];
    this.total = keys.length; this.loaded = 0;
    const failed = [];
    await Promise.all(keys.map(async k => {
      try { this.img[k] = await MC.Pack.image(k); } catch (e) { failed.push(k); }
      this.loaded++; onProgress && onProgress(this.loaded / this.total);
    }));
    if (failed.length) throw new Error('テクスチャを読み込めません (' + failed.length + '件)\n例: assets/minecraft/' + failed[0]);
    MC.Font.init();
    this.ready = true;
  },

  /** 'item/mace' -> Image  / 'textures/...png' もOK */
  image(name) {
    const p = name.startsWith('textures/') ? name : 'textures/' + name + '.png';
    const im = this.img[p];
    if (!im) throw new Error('asset not loaded: ' + p);
    return im;
  },
  has(name) {
    const p = name.startsWith('textures/') ? name : 'textures/' + name + '.png';
    return !!this.img[p];
  },

  /** three.js 用テクスチャ(ニアレスト) */
  tex(name, opts) {
    opts = opts || {};
    const key = name + '|' + (opts.mip ? 'm' : '') + (opts.repeat ? 'r' : '');
    if (this._tex[key]) return this._tex[key];
    const src = opts.canvas || this.image(name);
    const t = new THREE.Texture(src);
    t.magFilter = THREE.NearestFilter;
    t.minFilter = opts.mip ? THREE.NearestMipmapLinearFilter : THREE.NearestFilter;
    t.generateMipmaps = !!opts.mip;
    if (opts.repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
    t.needsUpdate = true;
    this._tex[key] = t;
    return t;
  },

  /** 画像を canvas に写してピクセルを読む */
  pixels(name) {
    const im = this.image(name);
    const c = document.createElement('canvas');
    c.width = im.width; c.height = im.height;
    const x = c.getContext('2d');
    x.drawImage(im, 0, 0);
    return { canvas: c, ctx: x, data: x.getImageData(0, 0, c.width, c.height), w: c.width, h: c.height };
  },
};

// ================================================================
//  ビットマップフォント (textures/font/ascii.png, 8x8)
// ================================================================
MC.Font = {
  widths: [],
  _tinted: {},
  _glyphs: {},
  init() {
    const px = MC.Assets.pixels('font/ascii');
    this.atlas = px.canvas;
    const d = px.data.data;
    for (let code = 0; code < 256; code++) {
      const cx = (code & 15) * 8, cy = (code >> 4) * 8;
      let maxX = -1;
      for (let x = 0; x < 8; x++) for (let y = 0; y < 8; y++) {
        if (d[((cy + y) * px.w + cx + x) * 4 + 3] > 0) maxX = Math.max(maxX, x);
      }
      this.widths[code] = code === 32 ? 4 : (maxX < 0 ? 0 : maxX + 2); // 字幅+1px間隔
    }
  },
  _tint(color) {
    let c = this._tinted[color];
    if (c) return c;
    c = document.createElement('canvas');
    c.width = this.atlas.width; c.height = this.atlas.height;
    const x = c.getContext('2d');
    x.drawImage(this.atlas, 0, 0);
    x.globalCompositeOperation = 'source-in';
    x.fillStyle = color;
    x.fillRect(0, 0, c.width, c.height);
    this._tinted[color] = c;
    return c;
  },
  width(text) {
    let w = 0;
    for (let i = 0; i < text.length; i++) { const c = text.charCodeAt(i); w += this.widths[c < 256 ? c : 63]; }
    return w;
  },
  _shadow(color) {
    const n = parseInt(color.slice(1), 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const h = v => ('0' + (v >> 2).toString(16)).slice(-2);
    return '#' + h(r) + h(g) + h(b);
  },
  /** ctx はGUI座標系(スケール済み)。x,yは左上 */
  draw(ctx, text, x, y, color, shadow) {
    color = color || '#FFFFFF';
    if (shadow !== false) this._run(ctx, text, x + 1, y + 1, this._shadow(color));
    this._run(ctx, text, x, y, color);
  },
  _glyph(color, code) {
    const key = color + code;
    let g = this._glyphs[key];
    if (!g) {
      g = document.createElement('canvas'); g.width = 8; g.height = 8;
      g.getContext('2d').drawImage(this._tint(color), (code & 15) * 8, (code >> 4) * 8, 8, 8, 0, 0, 8, 8);
      this._glyphs[key] = g;
    }
    return g;
  },
  _run(ctx, text, x, y, color) {
    for (let i = 0; i < text.length; i++) {
      let code = text.charCodeAt(i); if (code > 255) code = 63;
      const w = this.widths[code];
      if (code !== 32 && w) ctx.drawImage(this._glyph(color, code), x, y);
      x += w;
    }
  },
  drawCentered(ctx, text, cx, y, color, shadow) { this.draw(ctx, text, cx - Math.floor(this.width(text) / 2), y, color, shadow); },
};

