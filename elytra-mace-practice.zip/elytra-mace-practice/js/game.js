'use strict';
// ================================================================
//  キーバインド
// ================================================================
MC.Keys = {
  defs: [
    { id: 'forward', label: 'Walk Forwards', def: 'KeyW' },
    { id: 'left', label: 'Strafe Left', def: 'KeyA' },
    { id: 'back', label: 'Walk Backwards', def: 'KeyS' },
    { id: 'right', label: 'Strafe Right', def: 'KeyD' },
    { id: 'jump', label: 'Jump', def: 'Space' },
    { id: 'sneak', label: 'Sneak', def: 'ShiftLeft' },
    { id: 'sprint', label: 'Sprint', def: 'ControlLeft' },
    { id: 'attack', label: 'Attack/Destroy', def: 'Mouse0' },
    { id: 'use', label: 'Use Item/Place Block', def: 'Mouse2' },
    { id: 'inventory', label: 'Open/Close Inventory', def: 'KeyE' },
    { id: 'swap', label: 'Swap Item With Offhand', def: 'KeyF' },
    { id: 'reset', label: 'Reset Positions', def: 'KeyR' },
    { id: 'debug', label: 'Toggle Debug Info', def: 'F3' },
    { id: 'hitbox', label: 'Toggle Hitboxes', def: 'KeyH' },
    { id: 'perspective', label: 'Toggle Third Person', def: 'KeyV' },
    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => ({ id: 'hotbar' + n, label: 'Hotbar Slot ' + n, def: 'Digit' + n })),
  ],
  bind: {},
  down: new Set(),
  load() {
    for (const d of this.defs) this.bind[d.id] = d.def;
    try {
      const s = JSON.parse(localStorage.getItem('mcmace_keys') || '{}');
      for (const d of this.defs) if (typeof s[d.id] === 'string') this.bind[d.id] = s[d.id];
    } catch (e) {}
  },
  save() { try { localStorage.setItem('mcmace_keys', JSON.stringify(this.bind)); } catch (e) {} },
  set(id, code) { this.bind[id] = code; this.save(); this.down.clear(); if (MC.Game) MC.Game.clearInput(); },
  isDown(id) { return this.down.has(this.bind[id]); },
  idsFor(code) { return this.defs.filter(d => this.bind[d.id] === code).map(d => d.id); },
  label(code) {
    if (!code) return 'None';
    const m = { Mouse0: 'Left Button', Mouse1: 'Middle Button', Mouse2: 'Right Button', Space: 'Space', ShiftLeft: 'Left Shift', ShiftRight: 'Right Shift',
      ControlLeft: 'Left Control', ControlRight: 'Right Control', AltLeft: 'Left Alt', AltRight: 'Right Alt', ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right',
      Backquote: '`', Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']', Semicolon: ';', Quote: "'", Backslash: '\\', Comma: ',', Period: '.', Slash: '/', Tab: 'Tab', CapsLock: 'Caps Lock', Enter: 'Enter', Backspace: 'Backspace' };
    if (m[code]) return m[code];
    if (/^Key[A-Z]$/.test(code)) return code.slice(3);
    if (/^Digit\d$/.test(code)) return code.slice(5);
    if (/^Numpad/.test(code)) return 'Num ' + code.slice(6);
    if (/^Mouse\d/.test(code)) return 'Button ' + (parseInt(code.slice(5), 10) + 1);
    return code;
  },
};

// ================================================================
//  ゲーム本体
// ================================================================
const G = MC.Game = {
  tickCount: 0,
  msgs: [],
  hurtFlash: 0,
  nameTimer: 0,
  food: 20, sat: 5, exhaustion: 0,
  absorption: 0, absorbTicks: 0,
  attackTicker: 100,
  swinging: false, swingTicks: 0,
  useDelay: 0,
  eating: 0,                // 食事tick(0=していない)
  spearCharge: 0, chargeCd: 0,
  cooldowns: {},            // itemId -> 残りtick
  cooldownMax: {},
  projs: [], rockets: [],
  jumpCount: 0, pendingGlide: false, thirdPerson: false, lastForwardTap: 0, sprintToggle: false,
  stepDist: 0, nextStep: 1,
  elytraLoop: null,
  lastMainId: null,         // 前tickのメインハンドのアイテム(属性スワップ判定用)
  foodTick: 0,
  fps: 0,
  running: false,

  newEntity(x, y, z) {
    return { x, y, z, px: x, py: y, pz: z, vx: 0, vy: 0, vz: 0, hw: 0.3, h: 1.8, onGround: false, fall: 0, yaw: 0, pitch: 0,
      collX: false, collZ: false, collY: false, jumpDelay: 0, hurtTime: 0, invuln: 0, lastDmg: 0, gliding: false, sprinting: false, sneaking: false,
      limb: 0, limbAmt: 0, prevLimbAmt: 0,
      hp: 20, absorb: 0, absorbT: 0, regen: 0, ignoreFall: false, dead: false, lastTaken: 0 };
  },

  init() {
    MC.Keys.load();
    this.loadSettings();
    this.world = new MC.World(MC.CFG.worldSize);
    MC.Inventory.init();
    MC.Inventory.onEquipChange = (slot, now, before) => this.onEquipChange(slot, now, before);
    this.P = this.newEntity(0, 0, 0);
    this.N = this.newEntity(0, 0, 0);
    this.N.rotY = 0;
    this.resetPositions();
  },

  loadSettings() {
    try {
      const s = JSON.parse(localStorage.getItem('mcmace_settings') || '{}');
      for (const k of ['sensitivity', 'fov', 'masterVolume', 'infiniteItems', 'npcAttacks', 'showHitbox', 'damagePlayer', 'damageBot', 'showNametag']) if (s[k] != null) MC.CFG[k] = s[k];
    } catch (e) {}
  },
  saveSettings() {
    try {
      const o = {}; for (const k of ['sensitivity', 'fov', 'masterVolume', 'infiniteItems', 'npcAttacks', 'showHitbox', 'damagePlayer', 'damageBot', 'showNametag']) o[k] = MC.CFG[k];
      localStorage.setItem('mcmace_settings', JSON.stringify(o));
    } catch (e) {}
  },

  resetPositions() {
    const c = MC.CFG.worldSize / 2;
    const P = this.P, N = this.N;
    Object.assign(P, { jumpDelay: 0, x: c + 0.5, y: 0, z: c + 3.5, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0, fall: 0, gliding: false, sprinting: false, onGround: true, hurtTime: 0 });
    P.px = P.x; P.py = P.y; P.pz = P.z;
    Object.assign(N, { x: c + 0.5, y: 0, z: c - 0.5, vx: 0, vy: 0, vz: 0, fall: 0, onGround: true, hurtTime: 0, invuln: 0, rotY: 0 });
    N.px = N.x; N.py = N.y; N.pz = N.z;
    this.stopGlide(true);
    this.projs.length = 0; this.rockets.length = 0;
    this.eating = 0; this.spearCharge = 0;
    this.food = 20; this.sat = 5;
    P.hp = 20; P.absorb = 0; P.regen = 0; P.ignoreFall = false; P.invuln = 0; this.absorption = 0; this.absorbTicks = 0;
    N.hp = 20; N.absorb = 0; N.regen = 0; N.dead = false; N.respawn = 0; N.eatT = 0; N.eatCd = 0; N.atkTick = 100; N.ignoreFall = false;
    this.msg('Positions reset', '#AAAAAA');
  },
  resetInventory() { MC.Inventory.init(); this.onEquipChange('chest', MC.Inventory.slots[38], null, true); this.msg('Inventory reset', '#AAAAAA'); },

  msg(text, color) { this.msgs.push({ text, color, t: performance.now() }); if (this.msgs.length > 12) this.msgs.shift(); },

  // ------------------------------------------------------------ 画面/入力
  startPlaying() {
    MC.Snd.resume();
    MC.GUI.screen = null; this.onScreenChange();
    this.running = true;
  },
  closeScreen() {
    if (MC.GUI.screen === 'inventory') MC.Inventory.returnAll();
    MC.GUI.screen = null; MC.GUI.prev = null; this.onScreenChange();
  },
  onScreenChange() {
    const s = MC.GUI.screen;
    if (s === null) {
      const cv = MC.Render.glCanvas;
      try { const r = cv.requestPointerLock(); if (r && r.catch) r.catch(() => {}); } catch (e) {}
    } else if (document.pointerLockElement) document.exitPointerLock();
    // 画面を開いたら押しっぱなしの状態をクリア
    if (s !== null) { this.eating = 0; this.spearCharge = 0; this.useHeld = false; }
    MC.Keys.down.clear(); this.clearInput();
    document.body.style.cursor = s === null ? 'none' : 'default';
  },
  simPaused() { const s = MC.GUI.screen; return s === 'pause' || s === 'keys' || s === 'start'; },

  keyDown(e) {
    const K = MC.Keys, GUI = MC.GUI;
    if (GUI.listening) {
      e.preventDefault();
      if (e.code === 'Escape') GUI.listening = null; else { K.set(GUI.listening, e.code); GUI.listening = null; }
      return;
    }
    if (e.code === 'F5' || e.code === 'F12' || (e.ctrlKey && e.code === 'KeyR' && false)) return;
    if (GUI.screen === 'start') return;
    e.preventDefault();
    if (e.repeat) return;
    if (e.code === 'Escape') {
      if (GUI.screen === 'keys') GUI.back();
      else if (GUI.screen === 'inventory') this.closeScreen();
      else if (GUI.screen === 'pause') this.closeScreen();
      return;
    }
    K.down.add(e.code);
    for (const id of K.idsFor(e.code)) this.onAction(id);
  },
  keyUp(e) { MC.Keys.down.delete(e.code); },
  /** 押しっぱなし状態を全部クリア(キー設定変更・画面遷移時の暴走防止) */
  clearInput() { this.jumpCount = 0; this.pendingGlide = false; this.useHeld = false; this.sprintToggle = false; },
  mouseDown(e) {
    const code = 'Mouse' + e.button;
    if (MC.GUI.screen !== null) { MC.GUI.mouseDown(e); return; }
    if (!document.pointerLockElement) { this.onScreenChange(); return; }
    MC.Keys.down.add(code);
    for (const id of MC.Keys.idsFor(code)) this.onAction(id);
  },
  mouseUp(e) {
    MC.Keys.down.delete('Mouse' + e.button);
    MC.GUI.mouseUp(e);
  },

  onAction(id) {
    const GUI = MC.GUI, inv = MC.Inventory;
    if (GUI.screen === 'inventory') {
      if (id === 'inventory') this.closeScreen();
      else if (id.startsWith('hotbar') && GUI.hoverSlot >= 0) inv.swapWithHotbar(GUI.hoverSlot, parseInt(id.slice(6), 10) - 1);
      else if (id === 'swap' && GUI.hoverSlot >= 0 && GUI.hoverSlot !== inv.OFF) {
        const a = inv.slots[GUI.hoverSlot], b = inv.slots[inv.OFF];
        if (inv.accepts(GUI.hoverSlot, b)) { inv.slots[GUI.hoverSlot] = b; inv.slots[inv.OFF] = a; }
      }
      return;
    }
    if (GUI.screen !== null) return;
    switch (id) {
      case 'inventory': GUI.open('inventory'); break;
      case 'swap': inv.swapOffhand(); this.nameTimer = 40; break;
      case 'reset': this.resetPositions(); break;
      case 'debug': MC.CFG.showDebug = !MC.CFG.showDebug; break;
      case 'jump': this.jumpCount++; break;
      case 'hitbox': MC.CFG.showHitbox = !MC.CFG.showHitbox; this.saveSettings(); break;
      case 'perspective': this.thirdPerson = !this.thirdPerson; break;
      case 'attack': this.attack(); break;
      case 'use': this.useHeld = true; this.useItem(true); this.useDelay = 4; break;
      case 'forward': {
        const now = performance.now();
        if (now - this.lastForwardTap < 300 && !this.P.sneaking) this.sprintToggle = true;
        this.lastForwardTap = now; break;
      }
      default:
        if (id.startsWith('hotbar')) this.selectSlot(parseInt(id.slice(6), 10) - 1);
    }
  },
  selectSlot(i) {
    const inv = MC.Inventory;
    if (inv.selected === i) return;
    inv.selected = i; this.nameTimer = 40; this.eating = 0; this.spearCharge = 0;
  },
  wheel(e) {
    if (MC.GUI.screen === 'keys') { MC.GUI.wheel(e); return; }
    if (MC.GUI.screen !== null) return;
    const inv = MC.Inventory;
    this.selectSlot((inv.selected + (e.deltaY > 0 ? 1 : -1) + 9) % 9);
  },
  mouseMove(e) {
    if (MC.GUI.screen !== null) { MC.GUI.mouseMove(e); return; }
    if (!document.pointerLockElement) return;
    const f = MC.CFG.sensitivity * 0.6 + 0.2, k = f * f * f * 8 * 0.15 * MC.DEG;
    const P = this.P;
    P.yaw -= e.movementX * k;
    P.pitch = MC.clamp(P.pitch - e.movementY * k, -90 * MC.DEG, 90 * MC.DEG);
  },

  // ------------------------------------------------------------ 補助
  look(P) {
    const cp = Math.cos(P.pitch);
    return { x: -Math.sin(P.yaw) * cp, y: Math.sin(P.pitch), z: -Math.cos(P.yaw) * cp };
  },
  eyeOff(P) { return P.gliding ? MC.CFG.eyeHeightGlide : P.sneaking ? MC.CFG.eyeHeightSneak : MC.CFG.eyeHeight; },
  eyeY(P) { return P.y + this.eyeOff(P); },
  poseHeight(P) { return P.gliding ? MC.CFG.playerHGlide : P.sneaking ? MC.CFG.playerHSneak : MC.CFG.playerH; },
  cooldownFrac(id) { const c = this.cooldowns[id]; return c > 0 ? c / this.cooldownMax[id] : 0; },
  setCooldown(id, t) { this.cooldowns[id] = t; this.cooldownMax[id] = t; },
  attackPeriod(def) { return def && def.speed ? 20 / def.speed : 5; },
  attackStrength(partial) {
    const inv = MC.Inventory, def = inv.held() ? MC.ITEMS[inv.held().id] : null;
    return MC.clamp((this.attackTicker + (partial || 0)) / this.attackPeriod(def), 0, 1);
  },
  attackProgress() { return this.attackStrength(0.5); },
  consume(slot) {
    if (MC.CFG.infiniteItems) return;
    const inv = MC.Inventory, s = inv.slots[slot];
    if (!s) return; s.count--; if (s.count <= 0) inv.slots[slot] = null;
  },
  sound(ev, o, ent) {
    o = o || {};
    if (ent) o.pos = { x: ent.x, y: ent.y + 1, z: ent.z };
    return MC.Snd.play(ev, o);
  },
  armorSound(stack) {
    if (!stack) return;
    this.sound(stack.id === 'elytra' ? 'item.armor.equip_elytra' : 'item.armor.equip_netherite');
  },
  onEquipChange(slot, now, before, silent) {
    if (MC.Render && MC.Render.syncEquipment) MC.Render.syncEquipment();
    if (!silent) this.armorSound(now);
  },
  aabb(e, grow) { grow = grow || 0; return [e.x - e.hw - grow, e.y - grow, e.z - e.hw - grow, e.x + e.hw + grow, e.y + e.h + grow, e.z + e.hw + grow]; },
  rayAABB(ox, oy, oz, dx, dy, dz, b, maxT) {
    let t0 = 0, t1 = maxT;
    const o = [ox, oy, oz], d = [dx, dy, dz];
    for (let i = 0; i < 3; i++) {
      if (Math.abs(d[i]) < 1e-9) { if (o[i] < b[i] || o[i] > b[i + 3]) return null; }
      else {
        let a = (b[i] - o[i]) / d[i], c = (b[i + 3] - o[i]) / d[i];
        if (a > c) { const t = a; a = c; c = t; }
        t0 = Math.max(t0, a); t1 = Math.min(t1, c);
        if (t0 > t1) return null;
      }
    }
    return t0;
  },

  // ------------------------------------------------------------ 攻撃
  swing() { this.swinging = true; this.swingTicks = 0; },

  /** 武器ごとの攻撃範囲(AttackRange)。コンポーネントを持たない物は ENTITY_INTERACTION_RANGE=3.0 */
  attackRangeFor(def) { const R = MC.CFG.attackRange; return def && def.type === 'spear' ? R.spear : R.default; },

  /**
   * 目(ox,oy,oz)から視線 l の先にある e のヒットボックスを狙えるか。
   * ・ヒットボックスを margin だけ広げた箱に視線レイが当たる
   * ・目から箱までの距離が [min, max] に入る
   * ・手前にブロックがあれば当たらない
   * 当たれば視線上の距離 t、外れなら null
   */
  pickEntity(e, ox, oy, oz, l, range) {
    const box = this.aabb(e, range.margin);
    const t = this.rayAABB(ox, oy, oz, l.x, l.y, l.z, box, range.max);
    if (t == null) return null;
    const cx = MC.clamp(ox, box[0], box[3]), cy = MC.clamp(oy, box[1], box[4]), cz = MC.clamp(oz, box[2], box[5]);
    if (Math.hypot(cx - ox, cy - oy, cz - oz) < range.min) return null;
    const b = this.world.raycast(ox, oy, oz, l.x, l.y, l.z, t);
    if (b && b.t < t - 1e-6) return null;
    return t;
  },

  attack() {
    const inv = MC.Inventory, P = this.P, N = this.N;
    const st = inv.held(), def = st ? MC.ITEMS[st.id] : null;
    const type = def ? def.type : 'fist';
    // 属性スワップ: 攻撃力・攻撃速度(=クールダウンの長さ)・エンチャント効果は「この瞬間にメインハンドにある物」で決まる。
    // クールダウンのtickerは持ち替えでは即リセットされない(次のtickで判定される)。
    const strength = this.attackStrength(0.5);
    this.swing();
    const range = this.attackRangeFor(def);
    if (type === 'spear') {
      this.sound('item.spear.attack', { vol: 1 });
      if (def.lunge && !P.gliding && this.food >= MC.CFG.lungeMinFood) this.lunge(def.lunge);
    }
    const l = this.look(P);
    const t = this.pickEntity(N, P.x, this.eyeY(P), P.z, l, range);
    this.attackTicker = 0;                      // 空振りでもリセット(バニラのクライアント仕様)
    if (t == null || N.dead) return;
    this.hitNpc(def, type, strength, l, t);
  },

  lunge(level) {
    const P = this.P, l = this.look(P), m = MC.CFG.lungeImpulse[level - 1];
    P.vx += l.x * m; P.vz += l.z * m;             // assets: coordinate_scale [1,0,1] = 水平方向のみ
    this.addExhaustion(4 * MC.CFG.lungeHunger[level - 1]);
    this.sound('item.spear.lunge_' + level, { vol: 1 });
  },
  addExhaustion(v) {
    this.exhaustion += v;
    while (this.exhaustion >= 4) {
      this.exhaustion -= 4;
      if (this.sat > 0) this.sat = Math.max(0, this.sat - 1); else this.food = Math.max(0, this.food - 1);
    }
  },

  smashBonus(f) { return f <= 3 ? 4 * f : f <= 8 ? 12 + 2 * (f - 3) : 22 + (f - 8); },

  hitNpc(def, type, strength, l, tHit) {
    const P = this.P, N = this.N, inv = MC.Inventory, PT = MC.Particles;
    const fallBefore = P.fall;
    const base = def ? (def.dmg || 1) : 1;
    const smash = type === 'mace' && P.fall > 1.5 && !P.gliding;
    const crit = !smash && strength > 0.9 && P.fall > 0 && !P.onGround && !P.sprinting && type !== 'fist';
    let dmg = base * (0.2 + strength * strength * 0.8);
    if (crit) dmg *= 1.5;
    const bonus = smash ? this.smashBonus(P.fall) * strength : 0;
    const total = dmg + bonus;
    const hx = P.x + l.x * tHit, hy = this.eyeY(P) + l.y * tHit, hz = P.z + l.z * tHit;
    const mid = { x: N.x, y: N.y + 1.0, z: N.z };

    const hp0 = N.hp + N.absorb;
    if (!this.damageEntity(N, total, { src: 'player' })) {      // 無敵時間中(ダメージが前回以下)
      this.sound('entity.player.attack.nodamage', {}, N);
      return;
    }
    this.sound('entity.player.hurt', {}, N);

    const sprintHit = P.sprinting && strength > 0.9;
    if (smash) {
      const heavy = P.fall > 5;
      this.sound(N.onGround ? (heavy ? 'item.mace.smash_ground_heavy' : 'item.mace.smash_ground') : 'item.mace.smash_air', { vol: 1 }, N);
    } else if (type === 'spear') {
      this.sound('item.spear.hit', { vol: 1 }, N);
    } else if (crit) this.sound('entity.player.attack.crit', {}, N);
    else if (strength > 0.9) this.sound(sprintHit ? 'entity.player.attack.knockback' : (type === 'sword' && P.onGround ? 'entity.player.attack.sweep' : 'entity.player.attack.strong'), {}, N);
    else this.sound('entity.player.attack.weak', {}, N);
    if (type === 'sword' && strength > 0.9 && !sprintHit && !crit && P.onGround) PT.sweep(P.x + l.x * 1.2, this.eyeY(P) - 0.3 + l.y, P.z + l.z * 1.2);

    // ノックバック(ネザライト4点 = 耐性40%)
    this.knockback(N, 0.4 + (sprintHit ? 0.5 : 0), P.x - N.x, P.z - N.z, 0.4);
    if (sprintHit) { P.vx *= 0.6; P.vz *= 0.6; P.sprinting = false; this.sprintToggle = false; }

    if (crit) PT.crit(hx, hy, hz, 12);
    if (total > 4) PT.hearts(mid.x, N.y + 1.6, mid.z, Math.min(10, Math.floor(total / 4)));

    const taken = N.lastTaken;
    const hpTxt = MC.CFG.damageBot ? '  ->  Bot HP ' + Math.max(0, Math.ceil(N.hp + N.absorb)) : '';
    let label = (def ? def.name : 'Fist');
    if (smash) {
      label = 'Mace SMASH';
      const heavy = P.fall > 5 ? 2 : 1;
      const dx = N.x - P.x, dz = N.z - P.z, dl = Math.hypot(dx, dz) || 1;
      N.vx += dx / dl * 0.9 * heavy * 0.6; N.vz += dz / dl * 0.9 * heavy * 0.6; N.vy = Math.max(N.vy, 0.7);
      if (N.onGround) PT.dust(N.x, 0, N.z, 28, heavy); else PT.gust(N.x, N.y + 0.5, N.z, false);
      P.vy = 0.01;                                   // スマッシュ後は落下が止まる
      P.ignoreFall = true;                           // スマッシュ後は落下ダメージを受けない
      this.msg('[' + label + '] fall ' + fallBefore.toFixed(1) + ' blocks -> ' + total.toFixed(1) + ' dmg (smash +' + bonus.toFixed(1) + ', after armor ' + taken.toFixed(1) + ')' + hpTxt, '#FFAA00');
    } else {
      this.msg('[' + label + '] ' + total.toFixed(1) + ' dmg' + (crit ? ' (crit)' : '') + (strength < 0.9 ? ' (weak ' + Math.round(strength * 100) + '%)' : '') + ' (after armor ' + taken.toFixed(1) + ')' + hpTxt, '#FFFFFF');
    }

    // Wind Burst: assetsの条件は「落下距離 >= 1.5」(スマッシュ/滑空中かは問わない)
    const wb = (type === 'mace' && def.windBurst) || 0;
    if (wb > 0 && fallBefore >= 1.5) {
      P.vy = MC.CFG.windBurstVy[wb - 1];
      P.fall = 0; P.ignoreFall = true;
      this.sound('entity.wind_charge.wind_burst', { vol: 1.2 }, P);
      PT.gust(P.x, P.y - 0.3, P.z, true);
      if (!smash) this.msg('[Wind Burst ' + MC.Item.roman(wb) + '] fall ' + fallBefore.toFixed(1) + ' (no smash while gliding)', '#55FFFF');
    } else if (smash) P.fall = 0;
  },

  // ------------------------------------------------------------ 体力 / ダメージ
  /** CombatRules.getDamageAfterAbsorb */
  afterArmor(dmg, armor, tough) {
    const f = 2 + tough / 4;
    const g = MC.clamp(armor - dmg / f, armor * 0.2, 20);
    return dmg * (1 - g / 25);
  },
  armorOf(e) {
    if (e === this.P) return { armor: MC.Inventory.armorPoints(), tough: MC.Inventory.armorToughness() };
    return { armor: 20, tough: 12 };                // Bot: ネザライト一式
  },
  dmgEnabled(e) { return e === this.P ? MC.CFG.damagePlayer : MC.CFG.damageBot; },

  /**
   * ダメージを与える。バニラの無敵時間(20tick、後半10tickは前回より大きい分だけ)に従う。
   * o: { src, bypassArmor, silentIfOff }   戻り値: ダメージが通ったか(false=無敵時間で無効)
   */
  damageEntity(e, amount, o) {
    o = o || {};
    if (e.dead) return false;
    const isP = e === this.P;
    const enabled = this.dmgEnabled(e);
    if (!enabled && o.silentIfOff) return false;
    let eff = amount;
    if (e.invuln > 10) {
      if (amount <= e.lastDmg) return false;
      eff = amount - e.lastDmg; e.lastDmg = amount;
    } else { e.lastDmg = amount; e.invuln = 20; }
    e.hurtTime = 10;
    if (isP) { this.hurtFlash = 1; this.sound('entity.player.hurt'); }
    let dmg = eff;
    if (!o.bypassArmor) { const a = this.armorOf(e); dmg = this.afterArmor(eff, a.armor, a.tough); }
    e.lastTaken = dmg;
    if (enabled) {
      let ab = isP ? this.absorption : e.absorb;
      const takeAb = Math.min(ab, dmg); ab -= takeAb; dmg -= takeAb;
      if (isP) this.absorption = ab; else e.absorb = ab;
      e.hp -= dmg;
      if (e.hp <= 0) { e.hp = 0; this.killEntity(e, o); }
    }
    return true;
  },
  heal(e, amt) { e.hp = Math.min(20, e.hp + amt); },

  killEntity(e, o) {
    if (e === this.P) {
      this.msg('You died!' + (o && o.src ? ' (' + o.src + ')' : ''), '#FF5555');
      const spawn = { x: MC.CFG.worldSize / 2 + 0.5, z: MC.CFG.worldSize / 2 + 3.5 };
      const P = this.P;
      this.stopGlide(true);
      Object.assign(P, { x: spawn.x, y: 0, z: spawn.z, vx: 0, vy: 0, vz: 0, fall: 0, onGround: true, hp: 20, invuln: 0, ignoreFall: false, regen: 0 });
      P.px = P.x; P.py = P.y; P.pz = P.z;
      this.absorption = 0; this.absorbTicks = 0; this.food = 20; this.sat = 5; this.rockets.length = 0; this.projs.length = 0;
    } else {
      this.msg('Bot was defeated!', '#55FF55');
      e.dead = true; e.respawn = 60;
      MC.Particles.crit(e.x, e.y + 1, e.z, 20);
      this.sound('entity.player.hurt', {}, e);
    }
  },
  respawnBot() {
    const c = MC.CFG.worldSize / 2, N = this.N;
    Object.assign(N, { x: c + 0.5, y: 0, z: c - 0.5, vx: 0, vy: 0, vz: 0, fall: 0, onGround: true, hurtTime: 0, invuln: 0, rotY: 0,
      hp: 20, absorb: 0, regen: 0, dead: false, respawn: 0, eatT: 0, eatCd: 0, atkTick: 100, ignoreFall: false });
    N.px = N.x; N.py = N.y; N.pz = N.z;
  },

  /** 自然回復・再生エフェクト(バニラの FoodData に準拠) */
  healthTick() {
    const P = this.P, N = this.N;
    // プレイヤー
    if (P.hp < 20) {
      if (this.sat > 0 && this.food >= 20) {
        if (++this.foodTick >= 10) { const f = Math.min(this.sat, 6); this.heal(P, f / 6); this.addExhaustion(f); this.foodTick = 0; }
      } else if (this.food >= 18) {
        if (++this.foodTick >= 80) { this.heal(P, 1); this.addExhaustion(6); this.foodTick = 0; }
      } else this.foodTick = 0;
    } else this.foodTick = 0;
    if (P.regen > 0) { P.regen--; if (P.regen % 25 === 0 && P.hp < 20) { this.heal(P, 1); this.addExhaustion(0.5); } }
    // Bot
    if (!N.dead) {
      if (N.hp < 20) { N.botFood = (N.botFood || 0) + 1; if (N.botFood >= 80) { this.heal(N, 1); N.botFood = 0; } } else N.botFood = 0;
      if (N.regen > 0) { N.regen--; if (N.regen % 25 === 0 && N.hp < 20) this.heal(N, 1); }
      if (N.absorbT > 0) { N.absorbT--; if (N.absorbT === 0) N.absorb = 0; }
    }
  },

  /** マイクラ式ノックバック。(dx,dz)=攻撃者 - 対象 */
  knockback(e, strength, dx, dz, maxUp) {
    const res = e === this.P ? MC.Inventory.knockbackResist() : 0.4;     // Bot: ネザライト4点
    strength *= 1 - res;
    if (strength <= 0) return;
    let d = Math.hypot(dx, dz);
    if (d < 1e-4) { const a = Math.random() * Math.PI * 2; dx = Math.cos(a); dz = Math.sin(a); d = 1; }
    dx /= d; dz /= d;
    e.vx = e.vx / 2 - dx * strength;
    e.vz = e.vz / 2 - dz * strength;
    if (e.onGround) e.vy = Math.min(maxUp == null ? 0.4 : maxUp, e.vy / 2 + strength);
  },

  hurtMe(dx, dz, strength) {
    const P = this.P;
    this.hurtFlash = 1; P.hurtTime = 10;
    this.sound('entity.player.hurt');
    this.knockback(P, strength, dx, dz);
  },

  // ------------------------------------------------------------ アイテム使用
  useItem(press) {
    const inv = MC.Inventory, P = this.P;
    const st = inv.held();
    if (!st) return;
    const def = MC.ITEMS[st.id];
    switch (def.type) {
      case 'elytra': case 'armor':
        if (!press) return;
        if (inv.useEquip()) { this.nameTimer = 40; this.reequip = true; }
        break;
      case 'pearl': this.throwProjectile('pearl', st); break;
      case 'windcharge': this.throwProjectile('wind', st); break;
      case 'rocket': if (P.gliding) this.launchRocket(); break;
      case 'food':
        if (this.eating === 0 && this.food < 20 + 1) { this.eating = 1; }
        break;
      case 'spear':
        if (press && this.spearCharge === 0) { this.spearCharge = 1; this.sound('item.spear.use', { vol: 1 }); }
        break;
    }
  },

  throwProjectile(kind, st) {
    const P = this.P, l = this.look(P);
    const id = kind === 'pearl' ? 'ender_pearl' : 'wind_charge';
    if (this.cooldowns[id] > 0) return;
    this.swing();
    this.setCooldown(id, kind === 'pearl' ? MC.CFG.pearlCooldown : MC.CFG.windChargeCooldown);
    if (kind === 'pearl') this.sound('entity.ender_pearl.throw', { vol: 0.5, pitch: 0.4 / (Math.random() * 0.4 + 0.8) });
    else this.sound('entity.wind_charge.throw', { vol: 0.5, pitch: 1 / (Math.random() * 0.4 + 0.8) });
    const u = 0.0075;
    let dx = l.x + MC.gauss() * u, dy = l.y + MC.gauss() * u, dz = l.z + MC.gauss() * u;
    const len = Math.hypot(dx, dy, dz); dx /= len; dy /= len; dz /= len;
    const pr = {
      kind, x: P.x, y: this.eyeY(P) - 0.1, z: P.z,
      vx: dx * 1.5 + P.vx, vy: dy * 1.5 + (P.onGround ? 0 : P.vy), vz: dz * 1.5 + P.vz,
      age: 0, px: 0, py: 0, pz: 0,
    };
    pr.px = pr.x; pr.py = pr.y; pr.pz = pr.z;
    this.projs.push(pr);
    this.consume(MC.Inventory.selected);
  },

  launchRocket() {
    const flight = MC.CFG.fireworkFlight;
    const life = 10 * flight + MC.randInt(6) + MC.randInt(7);
    this.rockets.push({ age: 0, life });
    this.swing();
    this.consume(MC.Inventory.selected);
  },

  explodeWind(cx, cy, cz, skipPearls) {
    const R = MC.CFG.windChargeRadius, K = MC.CFG.windChargeKnock;
    this.sound('entity.wind_charge.wind_burst', { vol: 1 }, { x: cx, y: cy - 1, z: cz });
    MC.Particles.gust(cx, cy, cz, false);
    for (const e of [this.P, this.N]) {
      const ey = e.y + (e === this.P ? this.eyeY(e) - e.y : 1.62);
      let dx = e.x - cx, dy = ey - cy, dz = e.z - cz;
      const d = Math.hypot(dx, dy, dz);
      if (d >= R) continue;
      if (d < 1e-3) { dx = 0; dy = 1; dz = 0; } else { dx /= d; dy /= d; dz /= d; }
      const k = (1 - d / R) * K;
      e.vx += dx * k; e.vy += dy * k; e.vz += dz * k;
      e.fall = 0; e.ignoreFall = true;
      if (e === this.N) { this.N.hurtTime = 0; }
    }
    // 爆風に巻き込まれた飛行中のエンダーパールも反応してテレポート
    if (!skipPearls) {
      for (const q of this.projs) {
        if (q.kind !== 'pearl' || q.dead) continue;
        if (Math.hypot(q.x - cx, q.y - cy, q.z - cz) < 2.2) { q.dead = true; this.teleportPlayer(q.x, q.y, q.z, 0, 0, 0); }
      }
    }
  },

  teleportPlayer(x, y, z, nx, ny, nz) {
    const P = this.P, PT = MC.Particles;
    PT.portal(P.x, P.y, P.z, 36);
    this.sound('entity.player.teleport', { vol: 1 }, P);
    P.x = x + nx * P.hw; P.z = z + nz * P.hw;
    P.y = y + (ny < 0 ? -P.h - 0.01 : 0);
    // 埋まっていたら押し出す
    for (let i = 0; i < 40 && this.world.boxesIn(P.x - P.hw + 0.001, P.y + 0.001, P.z - P.hw + 0.001, P.x + P.hw - 0.001, P.y + P.h - 0.001, P.z + P.hw - 0.001).length; i++) P.y += 0.1;
    P.px = P.x; P.py = P.y; P.pz = P.z;
    P.fall = 0;
    this.damageEntity(P, 5, { src: 'ender pearl', bypassArmor: true, silentIfOff: true });   // エンダーパールの着弾ダメージ
    PT.portal(P.x, P.y, P.z, 36);
    this.sound('entity.player.teleport', { vol: 1 }, P);
  },

  updateProjectiles() {
    const w = this.world, N = this.N;
    // ウィンドチャージとエンダーパールが当たったら: ウィンドチャージは爆発し、パールが反応してテレポート
    for (const a of this.projs) {
      if (a.kind !== 'wind' || a.dead) continue;
      for (const b of this.projs) {
        if (b.kind !== 'pearl' || b.dead) continue;
        const rx = a.x - b.x, ry = a.y - b.y, rz = a.z - b.z;
        const vx = a.vx - b.vx, vy = a.vy - b.vy, vz = a.vz - b.vz;
        const vv = vx * vx + vy * vy + vz * vz;
        const t = vv > 1e-9 ? MC.clamp(-(rx * vx + ry * vy + rz * vz) / vv, 0, 1) : 0;
        const d = Math.hypot(rx + vx * t, ry + vy * t, rz + vz * t);
        if (d < 0.6) {
          a.dead = true;
          const wx = a.x + a.vx * t, wy = a.y + a.vy * t, wz = a.z + a.vz * t;
          const pe = { x: b.x + b.vx * t, y: b.y + b.vy * t, z: b.z + b.vz * t };
          b.dead = true;
          this.teleportPlayer(pe.x, pe.y, pe.z, 0, 0, 0);
          this.explodeWind(wx, wy, wz, true);
          break;
        }
      }
    }
    for (let i = this.projs.length - 1; i >= 0; i--) {
      const p = this.projs[i];
      if (p.dead) { this.projs.splice(i, 1); continue; }
      p.px = p.x; p.py = p.y; p.pz = p.z;
      p.age++;
      const len = Math.hypot(p.vx, p.vy, p.vz) || 1e-6;
      let tBlock = null, tEnt = null, n = null;
      const rb = w.raycast(p.x, p.y, p.z, p.vx, p.vy, p.vz, 1);
      if (rb) { tBlock = rb.t; n = rb; }
      if (p.age > 2) {
        const te = this.rayAABB(p.x, p.y, p.z, p.vx, p.vy, p.vz, this.aabb(N, 0.15), 1);
        if (te != null) tEnt = te;
      }
      let t = null, hitEnt = false;
      if (tBlock != null && (tEnt == null || tBlock <= tEnt)) t = tBlock;
      else if (tEnt != null) { t = tEnt; hitEnt = true; }
      if (t != null) {
        const hx = p.x + p.vx * t, hy = p.y + p.vy * t, hz = p.z + p.vz * t;
        if (p.kind === 'pearl') {
          const nx = n && !hitEnt ? n.nx : 0, ny = n && !hitEnt ? n.ny : 0, nz = n && !hitEnt ? n.nz : 0;
          this.teleportPlayer(hx, hy, hz, nx, ny, nz);
        } else {
          this.explodeWind(hx, hy, hz);
          if (hitEnt) { this.knockback(N, 0.4, this.P.x - N.x, this.P.z - N.z); this.sound('entity.player.hurt', {}, N); N.hurtTime = 10; }
        }
        this.projs.splice(i, 1);
        continue;
      }
      p.x += p.vx; p.y += p.vy; p.z += p.vz;
      if (p.kind === 'pearl') {
        p.vx *= 0.99; p.vy *= 0.99; p.vz *= 0.99; p.vy -= 0.03;
        if (p.age % 1 === 0) MC.Particles.portal(p.x, p.y - 0.1, p.z, 1);
      } else {
        if (p.age % 2 === 0) MC.Particles.smoke(p.x, p.y, p.z);
      }
      if (p.age > 400 || p.y < -20) this.projs.splice(i, 1);
    }
  },

  // ------------------------------------------------------------ エリトラ
  startGlide() {
    const P = this.P;
    P.gliding = true; P.sprinting = false; P.h = MC.CFG.playerHGlide;
    if (!this.elytraLoop) this.elytraLoop = MC.Snd.loop('item.elytra.flying');
  },
  stopGlide(silent) {
    this.P.gliding = false; this.P.h = this.poseHeight(this.P);
    if (this.elytraLoop) { this.elytraLoop.stop(); this.elytraLoop = null; }
  },

  elytraTravel(e) {
    const l = this.look(e), w = this.world;
    let vx = e.vx, vy = e.vy, vz = e.vz;
    const pitch = e.pitch;
    const lookH = Math.hypot(l.x, l.z);
    const moveH = Math.hypot(vx, vz);
    const lift = Math.pow(Math.cos(pitch), 2);
    vy += 0.08 * (-1 + lift * 0.75);
    if (vy < 0 && lookH > 0) {
      const d = vy * -0.1 * lift;
      vx += l.x * d / lookH; vy += d; vz += l.z * d / lookH;
    }
    if (pitch > 0 && lookH > 0) {                  // 上を向いているとき(マイクラのxRot<0)に速度→高度へ変換
      const d = moveH * Math.sin(pitch) * 0.04;
      vx += -l.x * d / lookH; vy += d * 3.2; vz += -l.z * d / lookH;
    }
    if (lookH > 0) {
      vx += (l.x / lookH * moveH - vx) * 0.1;
      vz += (l.z / lookH * moveH - vz) * 0.1;
    }
    e.vx = vx * 0.99; e.vy = vy * 0.98; e.vz = vz * 0.99;
    const before = Math.hypot(e.vx, e.vz);
    w.move(e, e.vx, e.vy, e.vz);
    if (e.collX) e.vx = 0; if (e.collZ) e.vz = 0; if (e.collY) e.vy = 0;
    if (e.collX || e.collZ) {                       // 運動エネルギーダメージ: (速度の減少 × 10 - 3)、鎧では軽減されない
      const f = (before - Math.hypot(e.vx, e.vz)) * 10 - 3;
      if (f > 0) this.damageEntity(e, f, { src: 'kinetic energy', bypassArmor: true, silentIfOff: true });
    }
  },

  walkTravel(e, forward, strafe, sprint) {
    const w = this.world;
    const friction = e.onGround ? 0.546 : 0.91;
    const accel = e.onGround ? (sprint ? 0.13 : 0.1) * (0.21600002 / (friction * friction * friction)) : (sprint ? 0.026 : 0.02);
    let d = Math.hypot(strafe, forward);
    if (d >= 0.01) {
      if (d < 1) d = 1;
      const k = accel / d; strafe *= k; forward *= k;
      const sy = Math.sin(e.yaw), cy = Math.cos(e.yaw);
      e.vx += -sy * forward + cy * strafe;
      e.vz += -cy * forward - sy * strafe;
    }
    w.move(e, e.vx, e.vy, e.vz);
    if (e.collX) e.vx = 0; if (e.collZ) e.vz = 0; if (e.collY) e.vy = 0;
    e.vy = (e.vy - 0.08) * 0.98;
    e.vx *= friction; e.vz *= friction;
  },

  afterMove(e, prevOnGround) {
    if (e.onGround) {
      if (!prevOnGround) {
        // 落下ダメージ: ceil(落下距離 - 3)。ウィンドバースト/ウィンドチャージ後(ignoreFall)は無効。鎧では軽減されない
        if (e.fall > 3 && !e.ignoreFall) this.damageEntity(e, Math.ceil(e.fall - 3), { src: 'fall', bypassArmor: true, silentIfOff: true });
        e.ignoreFall = false;
      }
      if (!prevOnGround && e.fall > 1 && e === this.P) {
        this.sound('block.grass.step', { vol: Math.min(1, 0.3 + e.fall * 0.05), pitch: 0.75 });
        if (e.fall > 3) MC.Particles.dust(e.x, 0, e.z, Math.min(14, Math.floor(e.fall)), 0.4);
      }
      e.fall = 0;
    } else if (e.movedY < 0) e.fall -= e.movedY;
  },

  // ------------------------------------------------------------ 1tick
  tick() {
    const K = MC.Keys, inv = MC.Inventory, P = this.P, N = this.N, cfg = MC.CFG;
    this.tickCount++;
    const open = MC.GUI.screen !== null;
    P.px = P.x; P.py = P.y; P.pz = P.z; N.px = N.x; N.py = N.y; N.pz = N.z;
    P.prevYaw = P.yaw;

    // 持ち替え検出(Player.tick): メインハンドのアイテムの種類が変わっていたら攻撃クールダウンをリセット。
    // 持ち替えと攻撃が同じtick内に起きた場合はリセット前に攻撃が処理される = 属性スワップ。
    { const h = inv.held(), hid = h ? h.id : null; if (hid !== this.lastMainId) { this.attackTicker = 0; this.lastMainId = hid; } }

    // 入力
    let fwd = 0, str = 0, jump = false;
    if (!open) {
      fwd = (K.isDown('forward') ? 1 : 0) - (K.isDown('back') ? 1 : 0);
      str = (K.isDown('right') ? 1 : 0) - (K.isDown('left') ? 1 : 0);
      jump = K.isDown('jump');
    }
    P.sneaking = !open && K.isDown('sneak') && !P.gliding;
    P.h = this.poseHeight(P);
    if (fwd <= 0) this.sprintToggle = false;
    const canSprint = fwd > 0 && !P.sneaking && this.food > 6 && !P.gliding;
    if (canSprint && (K.isDown('sprint') || this.sprintToggle) && !open) P.sprinting = true;
    else if (!canSprint || (P.collX || P.collZ)) { P.sprinting = false; if (!canSprint) this.sprintToggle = false; }
    if (!K.isDown('sprint') && !this.sprintToggle && fwd <= 0) P.sprinting = false;
    let mf = fwd * 0.98, ms = str * 0.98;
    if (P.sneaking) { mf *= 0.3; ms *= 0.3; }

    // 装備からエリトラが消えたら滑空終了
    if (P.gliding && (P.onGround || !inv.hasElytra())) this.stopGlide();
    // 滑空開始(空中でジャンプキーを押し直す)
    // ダブルジャンプ: 空中でジャンプを押した(or 同tick内に2回押した)らその場で即グライド。落下中かどうかは問わない
    const jc = this.jumpCount; this.jumpCount = 0;
    if (jc > 0 && !open && inv.hasElytra() && !P.gliding) {
      if (!P.onGround) this.startGlide();
      else if (jc >= 2) this.pendingGlide = true;
    }

    // ジャンプ
    if (P.jumpDelay > 0) P.jumpDelay--;
    if (jump && P.onGround && P.jumpDelay === 0 && !P.gliding) {
      P.vy = Math.max(0.42, P.vy);
      if (P.sprinting) { P.vx += -Math.sin(P.yaw) * 0.2; P.vz += -Math.cos(P.yaw) * 0.2; }
      P.jumpDelay = 10;
      if (this.pendingGlide && inv.hasElytra()) this.startGlide();
    }
    this.pendingGlide = false;

    // 移動
    const wasGround = P.onGround;
    if (P.gliding) {
      if (P.vy > -0.5 && P.fall > 1) P.fall = 1;      // マイクラ: 緩やかな滑空では落下距離が1に抑えられる
      this.elytraTravel(P);
    } else this.walkTravel(P, mf, ms, P.sprinting);
    this.afterMove(P, wasGround);
    // 滑空中の(小さい)当たり判定が地面に触れたら滑空解除
    if (P.gliding && (P.onGround || P.y <= 1e-4)) this.stopGlide();

    // ロケット(FireworkRocketEntity): プレイヤーのtickの後に実行される。
    //  ・滑空フラグ(isFallFlying)が立っている間だけ加速 … エリトラを外して滑空が終わると加速しない
    //  ・ロケット自体は寿命(10×Flight + rand(6) + rand(7) tick)まで残るので、その間にまた滑空すれば再び加速する
    for (let i = this.rockets.length - 1; i >= 0; i--) {
      const r = this.rockets[i];
      if (r.age === 0) this.sound('entity.firework_rocket.launch', { vol: 3 });
      if (P.gliding) {
        const l = this.look(P);
        P.vx += l.x * 0.1 + (l.x * 1.5 - P.vx) * 0.5;
        P.vy += l.y * 0.1 + (l.y * 1.5 - P.vy) * 0.5;
        P.vz += l.z * 0.1 + (l.z * 1.5 - P.vz) * 0.5;
        const bx = P.x - l.x * 0.6, by = this.eyeY(P) - 0.5 - l.y * 0.6, bz = P.z - l.z * 0.6;
        MC.Particles.spark(bx, by, bz, -l.x * 0.15 + MC.rand(-0.05, 0.05), -l.y * 0.15 + MC.rand(-0.05, 0.05), -l.z * 0.15 + MC.rand(-0.05, 0.05));
        MC.Particles.smoke(bx, by, bz);
      }
      r.age++;
      if (r.age > r.life) this.rockets.splice(i, 1);
    }

    // 足音
    const hs = Math.hypot(P.x - P.px, P.z - P.pz);
    this.stepDist += hs * 0.6;
    if (this.stepDist > this.nextStep) {
      this.nextStep = this.stepDist + 1;
      if (P.onGround && !P.sneaking && hs > 0.01) this.sound('block.grass.step', { vol: 0.15, pitch: 1 });
    }
    P.prevLimbAmt = P.limbAmt;
    P.limbAmt += (Math.min(1, hs * 4) - P.limbAmt) * 0.4;
    P.limb += hs * 4;

    // Bot
    this.updateNpc();
    this.entityPush();
    this.healthTick();

    // タイマ類
    this.attackTicker++;
    if (this.swinging) { this.swingTicks++; if (this.swingTicks >= 6) { this.swinging = false; this.swingTicks = 0; } }
    if (this.useDelay > 0) this.useDelay--;
    for (const id in this.cooldowns) if (this.cooldowns[id] > 0) this.cooldowns[id]--;
    if (P.hurtTime > 0) P.hurtTime--;
    if (N.hurtTime > 0) N.hurtTime--;
    if (N.invuln > 0) N.invuln--;
    if (P.invuln > 0) P.invuln--;
    this.hurtFlash = Math.max(0, this.hurtFlash - 0.1);
    if (this.nameTimer > 0) this.nameTimer--;
    if (this.absorbTicks > 0) { this.absorbTicks--; if (this.absorbTicks === 0) this.absorption = 0; }

    // 右クリック長押し / 左クリック長押し
    if (!open) {
      const held = inv.held(), def = held ? MC.ITEMS[held.id] : null;
      if (K.isDown('use') && def) {
        if (def.type === 'food') this.tickEating(held);
        else if (def.type === 'spear') this.tickSpear(def);
        else if (this.useDelay === 0 && def.type !== 'elytra' && def.type !== 'armor') { this.useItem(false); this.useDelay = 4; }
        else if (this.useDelay === 0) this.useDelay = 4;
      } else { this.eating = 0; this.spearCharge = 0; }
      if (K.isDown('attack') && this.attackStrength(0.5) >= 1) this.attack();
    }
    this.updateProjectiles();
  },

  tickEating(held) {
    if (this.eating === 0) { if (this.food < 20 + 1) this.eating = 1; else return; }
    this.eating++;
    const t = this.eating;
    if (t >= 7 && t % 4 === 0 && t < MC.CFG.eatTicks) {
      this.sound('entity.generic.eat', { vol: 0.5 + 0.5 * MC.randInt(2), pitch: (Math.random() - Math.random()) * 0.2 + 1 });
      const l = this.look(this.P);
      MC.Particles.crumbs(this.P.x + l.x * 0.5, this.eyeY(this.P) - 0.3 + l.y * 0.5, this.P.z + l.z * 0.5, 5);
    }
    if (t >= MC.CFG.eatTicks) {
      const d = MC.ITEMS[held.id];
      this.food = Math.min(20, this.food + d.food);
      this.sat = Math.min(this.food, this.sat + d.saturation);
      this.absorption = 4; this.absorbTicks = 2400; this.P.regen = 100;      // 再生II 5秒 + 吸収I 2分(金リンゴ)
      this.sound('entity.player.burp', { vol: 0.5, pitch: Math.random() * 0.1 + 0.9 });
      this.consume(MC.Inventory.selected);
      this.eating = 0;
    }
  },

  tickSpear(def) {
    const P = this.P, N = this.N;
    this.spearCharge++;
    if (this.chargeCd > 0) { this.chargeCd--; return; }
    const l = this.look(P);
    const t = this.pickEntity(N, P.x, this.eyeY(P), P.z, l, MC.CFG.attackRange.spear);
    if (t == null || N.dead) return;
    const rel = ((P.vx - N.vx) * l.x + (P.vy - N.vy) * l.y + (P.vz - N.vz) * l.z) * 20;
    if (rel < 2) return;
    const dmg = def.dmg + rel * 0.7;
    this.chargeCd = 10;
    if (!this.damageEntity(N, dmg, { src: 'player' })) return;
    this.sound('item.spear.hit', { vol: 1 }, N);
    this.sound('entity.player.hurt', {}, N);
    this.knockback(N, 0.4 + Math.min(1.2, rel * 0.06), P.x - N.x, P.z - N.z);
    MC.Particles.crit(N.x, N.y + 1, N.z, 8);
    this.msg('[Spear charge] rel. speed ' + rel.toFixed(1) + ' b/s -> ' + dmg.toFixed(1) + ' dmg', '#55FFFF');
  },

  // ------------------------------------------------------------ Bot(プレイヤーのように戦う)
  /** エンティティ同士の押し合い(Entity.push) */
  entityPush() {
    const P = this.P, N = this.N;
    if (N.dead) return;
    const a = this.aabb(P), b = this.aabb(N);
    if (a[0] < b[3] && a[3] > b[0] && a[1] < b[4] && a[4] > b[1] && a[2] < b[5] && a[5] > b[2]) {
      let d0 = N.x - P.x, d1 = N.z - P.z, d2 = Math.max(Math.abs(d0), Math.abs(d1));
      if (d2 >= 0.01) {
        d2 = Math.sqrt(d2); d0 /= d2; d1 /= d2;
        let d3 = 1 / d2; if (d3 > 1) d3 = 1;
        d0 *= d3 * 0.05; d1 *= d3 * 0.05;
        P.vx -= d0; P.vz -= d1; N.vx += d0; N.vz += d1;
      }
    }
  },

  updateNpc() {
    const N = this.N, P = this.P, cfg = MC.CFG, w = this.world;
    if (N.dead) {
      if (--N.respawn <= 0) this.respawnBot();
      return;
    }
    const wasGround = N.onGround;
    let fwd = 0, strafe = 0, wantJump = false;
    const dx = P.x - N.x, dz = P.z - N.z, hd = Math.hypot(dx, dz);
    const ney = N.y + 1.62;
    // 狙う点: プレイヤーの胴(少し揺らす = 完璧なエイムにしない)
    if (N.aimT == null || --N.aimT <= 0) { N.aimOx = MC.rand(-0.15, 0.15); N.aimOy = MC.rand(0.9, 1.4); N.aimOz = MC.rand(-0.15, 0.15); N.aimT = 8 + MC.randInt(10); }
    const ax = P.x + N.aimOx, ay = P.y + N.aimOy, az = P.z + N.aimOz;
    const target = Math.atan2(ax - N.x, az - N.z);
    let diff = target - N.rotY; while (diff > Math.PI) diff -= 2 * Math.PI; while (diff < -Math.PI) diff += 2 * Math.PI;
    N.rotY += MC.clamp(diff, -0.6, 0.6) * 0.6;            // 1tickに曲がれる量を制限(人間っぽい視点移動)
    N.yaw = Math.PI + N.rotY;
    N.pitch = Math.atan2(ay - ney, Math.max(0.01, Math.hypot(ax - N.x, az - N.z)));
    const sword = MC.ITEMS.netherite_sword;
    N.atkTick = (N.atkTick == null ? 100 : N.atkTick) + 1;
    const period = 20 / sword.speed;
    const strength = MC.clamp((N.atkTick + 0.5) / period, 0, 1);

    if (cfg.npcAttacks) {
      const inW = false;
      // ---- 金リンゴ: 体力が減ったら食べる(後ろに下がりながら)
      if (N.eatCd > 0) N.eatCd--;
      if (N.eatT > 0) {
        N.eatT++;
        const t = N.eatT;
        if (t >= 7 && t % 4 === 0 && t < cfg.eatTicks) {
          this.sound('entity.generic.eat', { vol: 0.5 + 0.5 * MC.randInt(2), pitch: (Math.random() - Math.random()) * 0.2 + 1 }, N);
          MC.Particles.crumbs(N.x + Math.sin(N.rotY) * 0.4, N.y + 1.3, N.z + Math.cos(N.rotY) * 0.4, 4);
        }
        if (t >= cfg.eatTicks) {
          N.eatT = 0; N.eatCd = 160;
          N.absorb = 4; N.absorbT = 2400; N.regen = 100;             // 再生II 5秒 + 吸収I 2分
          this.sound('entity.player.burp', { vol: 0.5, pitch: Math.random() * 0.1 + 0.9 }, N);
        }
        if (hd < 4) fwd = -0.7;
        strafe = (N.strafeDir || 0) * 0.5;
        N.sprinting = false;
      } else if (N.hp + N.absorb <= cfg.botEatBelow && N.regen <= 0 && N.eatCd <= 0) {
        N.eatT = 1;
      } else {
        // ---- 戦闘: 接近 → 左右に動く → 間合いに入ったらクリティカル狙いのジャンプ → クールダウン満了で攻撃
        if (hd > 3.3) { fwd = 1; N.sprinting = true; }
        else if (hd > 2.3) { fwd = 1; N.sprinting = hd > 2.8 && strength > 0.7 ? N.sprinting : false; }
        else if (hd < 1.3) { fwd = -0.6; N.sprinting = false; }
        else N.sprinting = false;
        N.strafeT = (N.strafeT || 0) - 1;
        if (N.strafeT <= 0) { N.strafeDir = [-1, 0, 1][MC.randInt(3)]; N.strafeT = 8 + MC.randInt(25); }
        if (hd < 4.5) strafe = N.strafeDir * 0.85;
        // クリティカル: 地面で、ほぼ攻撃できる状態&間合いならジャンプして落下中に殴る
        if (N.onGround && hd < 3.6 && strength > 0.55 && !N.sprinting && Math.random() < 0.18) wantJump = true;
        const l = { x: Math.sin(N.rotY) * Math.cos(N.pitch), y: Math.sin(N.pitch), z: Math.cos(N.rotY) * Math.cos(N.pitch) };
        const range = MC.CFG.attackRange.default;
        const hit = this.pickEntity(P, N.x, ney, N.z, l, range);
        const rising = !N.onGround && N.vy > 0;
        if (hit != null && strength >= 0.9 && !rising) this.botAttack(strength, l);
      }
      if (inW) wantJump = true;
    } else { N.sprinting = false; N.eatT = 0; }

    if (wantJump && N.onGround && N.jumpDelay <= 0) {
      N.vy = 0.42;
      if (N.sprinting) { N.vx += -Math.sin(N.yaw) * 0.2; N.vz += -Math.cos(N.yaw) * 0.2; }
      N.jumpDelay = 10;
    }
    if (N.jumpDelay > 0) N.jumpDelay--;
    this.walkTravel(N, fwd * 0.98, strafe * 0.98, N.sprinting);
    this.afterMove(N, wasGround);
    if (N.y < -64) { N.y = 0; N.vy = 0; }
    const hs = Math.hypot(N.x - N.px, N.z - N.pz);
    N.prevLimbAmt = N.limbAmt;
    N.limbAmt += (Math.min(1, hs * 4) - N.limbAmt) * 0.4; N.limb += hs * 4;
    if (N.swingT > 0) N.swingT--;
  },

  /** Botの攻撃(ネザライトの剣。クールダウン・クリティカル・スプリントノックバックはプレイヤーと同じ式) */
  botAttack(strength, l) {
    const N = this.N, P = this.P, PT = MC.Particles, sword = MC.ITEMS.netherite_sword;
    N.swingT = 6; N.atkTick = 0;
    const crit = strength > 0.9 && N.fall > 0 && !N.onGround && !N.sprinting;
    let dmg = sword.dmg * (0.2 + strength * strength * 0.8);
    if (crit) dmg *= 1.5;
    const sprintHit = N.sprinting && strength > 0.9;
    if (!this.damageEntity(P, dmg, { src: 'Bot' })) { this.sound('entity.player.attack.nodamage', {}, N); return; }
    if (crit) this.sound('entity.player.attack.crit', {}, N);
    else this.sound(sprintHit ? 'entity.player.attack.knockback' : 'entity.player.attack.strong', {}, N);
    this.knockback(P, 0.4 + (sprintHit ? 0.5 : 0), N.x - P.x, N.z - P.z, 0.4);
    if (sprintHit) { N.vx *= 0.6; N.vz *= 0.6; N.sprinting = false; }
    if (crit) PT.crit(P.x, P.y + 1.2, P.z, 12);
    this.msg('[Bot hit] ' + dmg.toFixed(1) + ' dmg' + (crit ? ' (crit)' : '') + ' (after armor ' + P.lastTaken.toFixed(1) + ')' + (MC.CFG.damagePlayer ? '  ->  your HP ' + Math.max(0, Math.ceil(P.hp + this.absorption)) : ''), '#FF7777');
  },

  debugLines() {
    const P = this.P;
    const sp = Math.hypot(P.vx, P.vz) * 20, spt = Math.hypot(P.vx, P.vy, P.vz) * 20;
    const st = this.attackStrength(0);
    return [
      'FPS: ' + Math.round(this.fps) + '   (F3: toggle)',
      'XYZ: ' + P.x.toFixed(2) + ' / ' + P.y.toFixed(2) + ' / ' + P.z.toFixed(2),
      'Speed: ' + sp.toFixed(1) + ' b/s (horizontal)  ' + spt.toFixed(1) + ' b/s (total)  vy ' + (P.vy * 20).toFixed(1),
      'Fall Distance: ' + P.fall.toFixed(2) + (P.fall > 1.5 && !P.gliding ? '  [SMASH READY]' : ''),
      'Hitbox: ' + (P.hw * 2).toFixed(1) + ' x ' + P.h.toFixed(1) + '  eye ' + this.eyeOff(P).toFixed(2) + '   [H] hitbox  [V] 3rd person',
      'HP: ' + P.hp.toFixed(1) + (this.absorption ? ' +' + this.absorption : '') + (MC.CFG.damagePlayer ? '' : ' (damage off)') + '   Bot HP: ' + this.N.hp.toFixed(1) + (this.N.absorb ? ' +' + this.N.absorb : '') + (MC.CFG.damageBot ? '' : ' (damage off)') + (this.N.dead ? ' (dead)' : ''),
      'State: ' + (P.gliding ? 'GLIDING' : P.onGround ? 'ground' : 'air') + (P.sprinting ? ' sprint' : '') + (P.sneaking ? ' sneak' : '') + '   Atk ' + Math.round(st * 100) + '%',
    ];
  },
};
