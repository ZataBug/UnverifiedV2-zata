'use strict';
// ================================================================
//  インベントリ(マイクラ準拠)
//   slots 0-8   : ホットバー
//         9-35  : メインインベントリ
//         36-39 : 防具(36=ブーツ 37=レギンス 38=胸 39=頭)
//         40    : オフハンド
//         41-44 : 2x2クラフト枠(入れ物としてのみ。閉じると戻る)
// ================================================================
MC.Inventory = {
  slots: new Array(45).fill(null),
  cursor: null,
  selected: 0,
  FEET: 36, LEGS: 37, CHEST: 38, HEAD: 39, OFF: 40, CRAFT0: 41,
  armorIndex: { feet: 36, legs: 37, chest: 38, head: 39 },
  onEquipChange: null,     // (slotName, newStack, oldStack) => void

  init() {
    this.slots.fill(null);
    const K = ['mace', 'elytra', 'netherite_spear', 'ender_pearl', 'wind_charge', 'netherite_axe', 'netherite_sword', 'golden_apple', 'firework_rocket'];
    K.forEach((id, i) => { this.slots[i] = MC.Item.make(id, MC.Item.max(id)); });
    this.slots[this.FEET] = MC.Item.make('netherite_boots');
    this.slots[this.LEGS] = MC.Item.make('netherite_leggings');
    this.slots[this.CHEST] = MC.Item.make('netherite_chestplate');
    this.slots[this.HEAD] = MC.Item.make('netherite_helmet');
    this.cursor = null;
    this.selected = 0;
  },

  held() { return this.slots[this.selected]; },
  equipment() { return { head: this.slots[39], chest: this.slots[38], legs: this.slots[37], feet: this.slots[36] }; },
  hasElytra() { const c = this.slots[this.CHEST]; return !!(c && c.id === 'elytra'); },
  armorPoints() {
    let p = 0; const e = this.equipment();
    for (const k in e) if (e[k] && MC.ITEMS[e[k].id].type === 'armor') p += MC.ARMOR_POINTS[k];
    return p;
  },
  knockbackResist() {   // ネザライト 1ピース = 0.1
    let r = 0; const e = this.equipment();
    for (const k in e) if (e[k] && MC.ARMOR_MATERIAL[e[k].id] === 'netherite') r += 0.1;
    return r;
  },

  isArmorSlot(i) { return i >= 36 && i <= 39; },
  accepts(i, stack) {
    if (!stack) return true;
    if (!this.isArmorSlot(i)) return true;
    const d = MC.ITEMS[stack.id];
    return d.slot === ['feet', 'legs', 'chest', 'head'][i - 36];
  },

  _notify(i, before) {
    if (this.isArmorSlot(i) && this.onEquipChange) this.onEquipChange(['feet', 'legs', 'chest', 'head'][i - 36], this.slots[i], before);
  },
  _set(i, v) { const before = this.slots[i]; this.slots[i] = v; if (before !== v) this._notify(i, before); },

  /** スロットクリック。button: 0=左 1=右 */
  click(i, button, shift) {
    const s = this.slots[i], c = this.cursor;
    if (shift && button === 0) { this.quickMove(i); return; }
    if (button === 0) {
      if (!c) { if (s) { this.cursor = s; this._set(i, null); } }
      else if (!s) { if (this.accepts(i, c)) { this._set(i, c); this.cursor = null; } }
      else if (s.id === c.id && MC.Item.max(s.id) > 1) {
        const n = Math.min(MC.Item.max(s.id) - s.count, c.count);
        s.count += n; c.count -= n; if (c.count <= 0) this.cursor = null;
      } else if (this.accepts(i, c)) { this._set(i, c); this.cursor = s; }
    } else if (button === 1) {
      if (!c) {
        if (s) {
          const half = Math.ceil(s.count / 2);
          this.cursor = { id: s.id, count: half };
          s.count -= half; if (s.count <= 0) this._set(i, null);
        }
      } else if (!s) {
        if (this.accepts(i, c)) {
          this._set(i, { id: c.id, count: 1 });
          c.count--; if (c.count <= 0) this.cursor = null;
        }
      } else if (s.id === c.id && s.count < MC.Item.max(s.id)) {
        s.count++; c.count--; if (c.count <= 0) this.cursor = null;
      } else if (this.accepts(i, c)) { this._set(i, c); this.cursor = s; }
    }
  },

  _merge(range, stack) {
    const max = MC.Item.max(stack.id);
    if (max > 1) for (const t of range) {
      const o = this.slots[t];
      if (o && o.id === stack.id && o.count < max) {
        const n = Math.min(max - o.count, stack.count); o.count += n; stack.count -= n;
        if (stack.count <= 0) return true;
      }
    }
    for (const t of range) {
      if (!this.slots[t]) { this._set(t, stack); return true; }
    }
    return false;
  },

  quickMove(i) {
    const s = this.slots[i];
    if (!s) return;
    const d = MC.ITEMS[s.id];
    const range = (a, b) => { const r = []; for (let k = a; k < b; k++) r.push(k); return r; };
    let targets;
    if (i < 36 || i >= 41) {
      if (d.slot && !this.slots[this.armorIndex[d.slot]]) { this._set(this.armorIndex[d.slot], s); this._set(i, null); return; }
      targets = i < 9 ? range(9, 36) : range(0, 9);
      if (i >= 41) targets = range(9, 36).concat(range(0, 9));
    } else targets = range(9, 36).concat(range(0, 9));
    const before = s.count;
    this._set(i, null);
    const moved = this._merge(targets, s);
    if (!moved) { if (s.count > 0) this.slots[i] = s; if (this.isArmorSlot(i)) this._notify(i, null); }
  },

  /** スロットにマウスを乗せたまま数字キー: そのスロットとホットバー n を入れ替え */
  swapWithHotbar(i, n) {
    if (i === n) return;
    const a = this.slots[i], b = this.slots[n];
    if (!this.accepts(i, b)) return;
    this._set(i, b); this._set(n, a);
  },

  /** 手に持った防具/エリトラを右クリックで装備(今の装備と入れ替え) */
  useEquip() {
    const h = this.slots[this.selected];
    if (!h) return false;
    const d = MC.ITEMS[h.id];
    if (!d.slot) return false;
    const ai = this.armorIndex[d.slot];
    const cur = this.slots[ai];
    this._set(ai, h);
    this.slots[this.selected] = cur;
    return true;
  },

  swapOffhand() {
    const a = this.slots[this.selected], b = this.slots[this.OFF];
    this.slots[this.selected] = b; this.slots[this.OFF] = a;
  },

  /** 画面を閉じたとき: カーソルとクラフト枠の中身をインベントリへ戻す */
  returnAll() {
    const all = [];
    if (this.cursor) { all.push(this.cursor); this.cursor = null; }
    for (let k = 41; k < 45; k++) if (this.slots[k]) { all.push(this.slots[k]); this.slots[k] = null; }
    const range = []; for (let k = 9; k < 36; k++) range.push(k); for (let k = 0; k < 9; k++) range.push(k);
    for (const st of all) this._merge(range, st);
  },
};
