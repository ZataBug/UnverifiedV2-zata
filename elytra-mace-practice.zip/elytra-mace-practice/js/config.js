'use strict';
// ================================================================
//  共通名前空間 + 調整用パラメータ
//  挙動を変えたいときは基本ここの数値をいじればOK
// ================================================================
const MC = window.MC = {};

MC.CFG = {
  worldSize: 128,          // ワールド一辺(ブロック)
  fov: 70,                 // 縦FOV
  sensitivity: 0.5,        // マイクラ準拠(0..1, 0.5 = 100%)
  masterVolume: 1.0,

  // ---- プレイヤー ----
  eyeHeight: 1.62,
  eyeHeightSneak: 1.27,
  playerW: 0.6,
  playerH: 1.8,
  playerHSneak: 1.5,
  playerHGlide: 0.6,       // エリトラ滑空中(FALL_FLYING)は 0.6x0.6
  eyeHeightGlide: 0.4,
  reach: 3.0,              // 通常の攻撃リーチ
  spearReach: 4.5,         // スピアのリーチ

  // ---- アイテム性能 ----
  windBurstVy: [1.14, 1.66, 2.09],     // メイス Wind Burst I/II/III の上向き速度(blocks/tick)。assetsのknockback_multiplier(1.2/1.75/2.2)に比例させた調整値 ≒ 7/14/21ブロック
  lungeImpulse: [0.6, 0.85, 1.1], // スピア Lunge I/II/III の加速量(視線方向)
  lungeHunger: [1, 2, 3],              // 消費する満腹度
  lungeMinFood: 6,
  windChargeKnock: 3.0,                // ウィンドチャージ爆風の強さ(自分用の調整値)
  windChargeRadius: 2.8,
  fireworkFlight: 1,                   // ロケットの飛行時間レベル(1〜3)
  pearlCooldown: 20,                   // tick
  windChargeCooldown: 10,
  eatTicks: 32,

  // ---- 練習モード ----
  infiniteItems: true,     // 消費アイテムが減らない
  npcAttacks: false,
  npcReach: 2.0,           // NPCの攻撃リーチ(バニラは約3.0)
  showHitbox: true,        // ヒットボックス表示(Hキー)       // NPCが自分を殴ってくる(ダメージは無し、ノックバックのみ)
  showDebug: true,         // F3 でも切替
};

MC.TICK = 1 / 20;
MC.DEG = Math.PI / 180;

// 防具ステータス(防御力表示 & ノックバック耐性用)
MC.ARMOR_POINTS = { head: 3, chest: 8, legs: 6, feet: 3 };

MC.rand = (a, b) => a + Math.random() * (b - a);
MC.randInt = (n) => Math.floor(Math.random() * n);
MC.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
MC.lerp = (a, b, t) => a + (b - a) * t;
MC.gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
