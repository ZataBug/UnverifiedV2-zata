'use strict';
// ================================================================
//  サウンド: sounds.json のイベント名で鳴らす (例: 'item.mace.smash_air')
//  volume / pitch は元のsounds.jsonの値 × 呼び出し側の値
// ================================================================
MC.Snd = {
  ctx: null, master: null, buffers: {}, ready: false,

  async init(onProgress) {
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = MC.CFG.masterVolume;
    this.master.connect(this.ctx.destination);
    const keys = Object.keys(window.ASSET_DATA).filter(k => k.endsWith('.ogg'));
    let done = 0;
    await Promise.all(keys.map(async k => {
      try {
        const uri = window.ASSET_DATA[k];
        const bin = atob(uri.slice(uri.indexOf(',') + 1));
        const buf = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
        this.buffers[k] = await this.ctx.decodeAudioData(buf.buffer);
      } catch (e) { console.warn('audio decode failed', k, e); }
      done++; onProgress && onProgress(done / keys.length);
    }));
    this.ready = true;
  },

  resume() { if (this.ctx && this.ctx.state !== 'running') this.ctx.resume(); },
  setMaster(v) { if (this.master) this.master.gain.value = v; },

  _pick(event) {
    const ev = window.SOUNDS_JSON[event];
    if (!ev) { console.warn('unknown sound event', event); return null; }
    const s = ev.sounds[MC.randInt(ev.sounds.length)];
    if (typeof s === 'string') return { name: s, vol: 1, pitch: 1 };
    if (s.type === 'event') return this._pick(s.name);
    return { name: s.name, vol: s.volume == null ? 1 : s.volume, pitch: s.pitch == null ? 1 : s.pitch, att: s.attenuation_distance };
  },

  /**
   * opts: { vol, pitch, pos:{x,y,z} (省略=自分の位置/非定位) }
   */
  play(event, opts) {
    if (!this.ready) return null;
    opts = opts || {};
    const p = this._pick(event);
    if (!p) return null;
    const buf = this.buffers['sounds/' + p.name + '.ogg'];
    if (!buf) return null;
    const vol = (opts.vol == null ? 1 : opts.vol) * p.vol;
    const pitch = (opts.pitch == null ? 1 : opts.pitch) * p.pitch;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = pitch;
    const g = this.ctx.createGain();
    g.gain.value = vol;
    src.connect(g);
    if (opts.pos) {
      const pn = this.ctx.createPanner();
      pn.panningModel = 'equalpower';
      pn.distanceModel = 'linear';
      pn.refDistance = 0.5;
      pn.maxDistance = (p.att || 16) * Math.max(1, vol);
      pn.rolloffFactor = 1;
      this._setPos(pn, opts.pos);
      g.connect(pn); pn.connect(this.master);
    } else g.connect(this.master);
    src.start();
    return src;
  },

  /** ループ音。{ set(vol,pitch), stop() } */
  loop(event) {
    if (!this.ready) return { set() {}, stop() {} };
    const p = this._pick(event);
    const buf = p && this.buffers['sounds/' + p.name + '.ogg'];
    if (!buf) return { set() {}, stop() {} };
    const src = this.ctx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const g = this.ctx.createGain(); g.gain.value = 0;
    src.connect(g); g.connect(this.master);
    src.start();
    const base = p.vol;
    return {
      set: (vol, pitch) => {
        g.gain.setTargetAtTime(vol * base, this.ctx.currentTime, 0.03);
        src.playbackRate.value = pitch == null ? 1 : pitch;
      },
      stop: () => { try { g.gain.setTargetAtTime(0, this.ctx.currentTime, 0.02); src.stop(this.ctx.currentTime + 0.1); } catch (e) {} },
    };
  },

  _setPos(node, p) {
    if (node.positionX) { node.positionX.value = p.x; node.positionY.value = p.y; node.positionZ.value = p.z; }
    else node.setPosition(p.x, p.y, p.z);
  },

  /** 毎フレーム呼ぶ: リスナー = カメラ */
  setListener(pos, fwd) {
    if (!this.ready) return;
    const l = this.ctx.listener;
    if (l.positionX) {
      l.positionX.value = pos.x; l.positionY.value = pos.y; l.positionZ.value = pos.z;
      l.forwardX.value = fwd.x; l.forwardY.value = fwd.y; l.forwardZ.value = fwd.z;
      l.upX.value = 0; l.upY.value = 1; l.upZ.value = 0;
    } else {
      l.setPosition(pos.x, pos.y, pos.z);
      l.setOrientation(fwd.x, fwd.y, fwd.z, 0, 1, 0);
    }
  },
};
