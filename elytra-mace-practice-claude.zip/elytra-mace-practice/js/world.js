'use strict';
// ================================================================
//  ワールド: 128x128 の草ブロック床。ブロック単位の当たり判定。
//   - ブロックは y = -1 (上面が y=0) から下3段
//   - ワールド外(x,z が範囲外)は高さ無限の壁として扱い、外には出られない
//   - 設置/破壊は無し(setBlock を使えば足せる設計)
// ================================================================
MC.World = class World {
  constructor(size) {
    this.size = size || MC.CFG.worldSize;
    this.FLOOR_TOP = -1;      // 一番上のブロック層
    this.FLOOR_BOTTOM = -3;   // 一番下のブロック層
    this.extra = new Map();   // "x,y,z" -> 1 追加ブロック(将来用)
  }

  isSolid(x, y, z) {
    if (x < 0 || z < 0 || x >= this.size || z >= this.size) return true; // 境界の壁
    if (y <= this.FLOOR_TOP && y >= this.FLOOR_BOTTOM) return true;
    return this.extra.size ? this.extra.has(x + ',' + y + ',' + z) : false;
  }
  setBlock(x, y, z, on) { const k = x + ',' + y + ',' + z; on ? this.extra.set(k, 1) : this.extra.delete(k); }

  /** 範囲内の衝突ボックス [x0,y0,z0,x1,y1,z1] */
  boxesIn(x0, y0, z0, x1, y1, z1) {
    const out = [];
    const ix0 = Math.floor(x0), ix1 = Math.floor(x1), iy0 = Math.floor(y0), iy1 = Math.floor(y1), iz0 = Math.floor(z0), iz1 = Math.floor(z1);
    for (let x = ix0; x <= ix1; x++) for (let y = iy0; y <= iy1; y++) for (let z = iz0; z <= iz1; z++) {
      if (this.isSolid(x, y, z)) out.push([x, y, z, x + 1, y + 1, z + 1]);
    }
    return out;
  }

  /**
   * エンティティ移動(マイクラ方式: Y → 大きい方の水平軸 → 小さい方)
   * e: { x,y,z (足元中心), hw (半幅), h (高さ) }  結果を e に書き戻す。
   * e.collX / collZ / collY / onGround を更新
   */
  move(e, dx, dy, dz) {
    const hw = e.hw, h = e.h;
    const bb = [e.x - hw, e.y, e.z - hw, e.x + hw, e.y + h, e.z + hw];
    const ox = dx, oy = dy, oz = dz;
    const boxes = this.boxesIn(bb[0] + Math.min(dx, 0) - 0.01, bb[1] + Math.min(dy, 0) - 0.01, bb[2] + Math.min(dz, 0) - 0.01,
      bb[3] + Math.max(dx, 0) + 0.01, bb[4] + Math.max(dy, 0) + 0.01, bb[5] + Math.max(dz, 0) + 0.01);
    const EPS = 1e-7;
    // Y
    for (const b of boxes) {
      if (bb[3] > b[0] + EPS && bb[0] < b[3] - EPS && bb[5] > b[2] + EPS && bb[2] < b[5] - EPS) {
        if (dy > 0 && b[1] >= bb[4] - EPS) dy = Math.min(dy, b[1] - bb[4]);
        else if (dy < 0 && b[4] <= bb[1] + EPS) dy = Math.max(dy, b[4] - bb[1]);
      }
    }
    bb[1] += dy; bb[4] += dy;
    const axisX = () => {
      for (const b of boxes) {
        if (bb[4] > b[1] + EPS && bb[1] < b[4] - EPS && bb[5] > b[2] + EPS && bb[2] < b[5] - EPS) {
          if (dx > 0 && b[0] >= bb[3] - EPS) dx = Math.min(dx, b[0] - bb[3]);
          else if (dx < 0 && b[3] <= bb[0] + EPS) dx = Math.max(dx, b[3] - bb[0]);
        }
      }
      bb[0] += dx; bb[3] += dx;
    };
    const axisZ = () => {
      for (const b of boxes) {
        if (bb[4] > b[1] + EPS && bb[1] < b[4] - EPS && bb[3] > b[0] + EPS && bb[0] < b[3] - EPS) {
          if (dz > 0 && b[2] >= bb[5] - EPS) dz = Math.min(dz, b[2] - bb[5]);
          else if (dz < 0 && b[5] <= bb[2] + EPS) dz = Math.max(dz, b[5] - bb[2]);
        }
      }
      bb[2] += dz; bb[5] += dz;
    };
    if (Math.abs(ox) >= Math.abs(oz)) { axisX(); axisZ(); } else { axisZ(); axisX(); }
    e.x = (bb[0] + bb[3]) / 2; e.y = bb[1]; e.z = (bb[2] + bb[5]) / 2;
    e.collX = Math.abs(dx - ox) > 1e-9;
    e.collZ = Math.abs(dz - oz) > 1e-9;
    e.collY = Math.abs(dy - oy) > 1e-9;
    e.onGround = e.collY && oy < 0;
    e.movedY = dy;
    e.movedX = dx; e.movedZ = dz;
  }

  /** ブロックに対するレイキャスト(DDA)。dは正規化不要。t は o+d*t の t。 */
  raycast(ox, oy, oz, dx, dy, dz, maxT) {
    let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
    const sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
    const tdx = dx !== 0 ? Math.abs(1 / dx) : Infinity, tdy = dy !== 0 ? Math.abs(1 / dy) : Infinity, tdz = dz !== 0 ? Math.abs(1 / dz) : Infinity;
    let tx = dx !== 0 ? ((dx > 0 ? x + 1 - ox : ox - x) * tdx) : Infinity;
    let ty = dy !== 0 ? ((dy > 0 ? y + 1 - oy : oy - y) * tdy) : Infinity;
    let tz = dz !== 0 ? ((dz > 0 ? z + 1 - oz : oz - z) * tdz) : Infinity;
    if (this.isSolid(x, y, z)) return { t: 0, x, y, z, nx: 0, ny: 0, nz: 0 };
    let t = 0;
    for (let i = 0; i < 2000; i++) {
      let nx = 0, ny = 0, nz = 0;
      if (tx < ty && tx < tz) { t = tx; tx += tdx; x += sx; nx = -sx; }
      else if (ty < tz) { t = ty; ty += tdy; y += sy; ny = -sy; }
      else { t = tz; tz += tdz; z += sz; nz = -sz; }
      if (t > maxT) return null;
      if (this.isSolid(x, y, z)) return { t, x, y, z, nx, ny, nz };
    }
    return null;
  }

  // ------------------------------------------------------------
  //  描画
  // ------------------------------------------------------------
  build(scene) {
    const S = this.size;
    const A = MC.Assets;
    // 草ブロックの色(平原バイオーム)
    const GRASS = '#91BD59';
    const tint = (img) => {
      const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
      const x = c.getContext('2d');
      x.drawImage(img, 0, 0);
      x.globalCompositeOperation = 'multiply'; x.fillStyle = GRASS; x.fillRect(0, 0, c.width, c.height);
      x.globalCompositeOperation = 'destination-in'; x.drawImage(img, 0, 0);
      return c;
    };
    const topCanvas = tint(A.image('block/grass_block_top'));
    const topTex = A.tex('world_top', { canvas: topCanvas, mip: true, repeat: true });
    topTex.repeat.set(S, S);
    topTex.anisotropy = 8;
    const top = new THREE.Mesh(new THREE.PlaneGeometry(S, S), new THREE.MeshBasicMaterial({ map: topTex }));
    top.rotation.x = -Math.PI / 2; top.position.set(S / 2, 0, S / 2);
    scene.add(top);

    // 側面テクスチャ: 草の側面 + 土 x2
    const col = document.createElement('canvas'); col.width = 16; col.height = 48;
    const cx = col.getContext('2d');
    cx.drawImage(A.image('block/grass_block_side'), 0, 0);
    cx.drawImage(tint(A.image('block/grass_block_side_overlay')), 0, 0);
    cx.drawImage(A.image('block/dirt'), 0, 16);
    cx.drawImage(A.image('block/dirt'), 0, 32);
    const sideTex = A.tex('world_side', { canvas: col, repeat: true });
    sideTex.repeat.set(S, 1); sideTex.wrapT = THREE.ClampToEdgeWrapping;
    const sideMat = new THREE.MeshBasicMaterial({ map: sideTex });
    const mkSide = (px, pz, ry) => {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(S, 3), sideMat);
      m.position.set(px, -1.5, pz); m.rotation.y = ry; scene.add(m);
    };
    mkSide(S / 2, 0, Math.PI);      // 北(z=0) 外向き = -Z
    mkSide(S / 2, S, 0);            // 南(z=S) 外向き = +Z
    mkSide(0, S / 2, -Math.PI / 2); // 西(x=0) 外向き = -X
    mkSide(S, S / 2, Math.PI / 2);  // 東(x=S) 外向き = +X

    // ワールドボーダー(近づくと青い格子が浮かぶ)
    const bc = document.createElement('canvas'); bc.width = bc.height = 16;
    const bx = bc.getContext('2d');
    bx.fillStyle = 'rgba(60,140,255,0.28)'; bx.fillRect(0, 0, 16, 16);
    bx.fillStyle = 'rgba(160,210,255,0.9)'; bx.fillRect(0, 0, 16, 1); bx.fillRect(0, 0, 1, 16);
    const bt = A.tex('world_border', { canvas: bc, repeat: true });
    this.borderMats = [];
    const H = 400;
    const mkWall = (px, pz, ry) => {
      const t = bt.clone(); t.needsUpdate = true; t.repeat.set(S, H);
      const mat = new THREE.MeshBasicMaterial({ map: t, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide });
      const m = new THREE.Mesh(new THREE.PlaneGeometry(S, H), mat);
      m.position.set(px, H / 2 - 5, pz); m.rotation.y = ry; m.renderOrder = 5; scene.add(m);
      this.borderMats.push(mat);
    };
    mkWall(S / 2, 0, 0); mkWall(S / 2, S, 0); mkWall(0, S / 2, Math.PI / 2); mkWall(S, S / 2, Math.PI / 2);
  }

  updateBorder(px, pz) {
    if (!this.borderMats) return;
    const S = this.size;
    const d = [pz, S - pz, px, S - px];
    for (let i = 0; i < 4; i++) this.borderMats[i].opacity = MC.clamp(1 - d[i] / 10, 0, 1) * 0.85;
  }
};
