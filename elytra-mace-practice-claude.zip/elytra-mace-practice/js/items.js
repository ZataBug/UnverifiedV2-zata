'use strict';
// ================================================================
//  アイテム定義(ここに足せば新アイテムを追加できる)
//
//  tex     : GUI/ドロップ用テクスチャ ("textures/" と ".png" を除いたパス)
//  handTex : 手持ち用テクスチャ(省略時 tex)。スピアは32x32の専用テクスチャ
//  model   : 手持ち表示の変換 ('generated' | 'handheld' | 'handheld_mace' | 'spear')
//  type    : ゲーム側の挙動 (mace/spear/sword/axe/elytra/armor/pearl/windcharge/rocket/food)
//  slot    : 装備スロット (head/chest/legs/feet)
//  dmg/speed : 攻撃力 / 攻撃速度(1秒あたりの回数)
//  新テクスチャ/サウンドを使うときは assets_manifest.json にも追記して
//  tools/sync_assets.py を実行すること。
// ================================================================
MC.ITEMS = {
  mace: {
    name: 'Mace', tex: 'item/mace', model: 'handheld_mace', type: 'mace',
    stack: 1, rarity: 'epic', glint: true, enchants: [['Wind Burst', 3]],
    windBurst: 3, dmg: 6, speed: 0.6,
  },
  elytra: {
    name: 'Elytra', tex: 'item/elytra', model: 'generated', type: 'elytra',
    stack: 1, rarity: 'uncommon', slot: 'chest',
  },
  netherite_spear: {
    name: 'Netherite Spear', tex: 'item/netherite_spear', handTex: 'item/netherite_spear_in_hand',
    model: 'spear', type: 'spear', stack: 1, rarity: 'common', glint: true,
    enchants: [['Lunge', 3]], lunge: 3, dmg: 5, speed: 1.54,
  },
  ender_pearl: {
    name: 'Ender Pearl', tex: 'item/ender_pearl', model: 'generated', type: 'pearl', stack: 16, rarity: 'common',
  },
  wind_charge: {
    name: 'Wind Charge', tex: 'item/wind_charge', model: 'generated', type: 'windcharge', stack: 64, rarity: 'common',
  },
  netherite_axe: {
    name: 'Netherite Axe', tex: 'item/netherite_axe', model: 'handheld', type: 'axe',
    stack: 1, rarity: 'common', dmg: 10, speed: 1.0,
  },
  netherite_sword: {
    name: 'Netherite Sword', tex: 'item/netherite_sword', model: 'handheld', type: 'sword',
    stack: 1, rarity: 'common', dmg: 8, speed: 1.6,
  },
  golden_apple: {
    name: 'Golden Apple', tex: 'item/golden_apple', model: 'generated', type: 'food',
    stack: 64, rarity: 'rare', food: 4, saturation: 9.6,
  },
  firework_rocket: {
    name: 'Firework Rocket', tex: 'item/firework_rocket', model: 'generated', type: 'rocket',
    stack: 64, rarity: 'common', lines: () => ['Flight Duration: ' + MC.CFG.fireworkFlight],
  },
  netherite_helmet: {
    name: 'Netherite Helmet', tex: 'item/netherite_helmet', model: 'generated', type: 'armor',
    stack: 1, rarity: 'common', slot: 'head',
  },
  netherite_chestplate: {
    name: 'Netherite Chestplate', tex: 'item/netherite_chestplate', model: 'generated', type: 'armor',
    stack: 1, rarity: 'common', slot: 'chest',
  },
  netherite_leggings: {
    name: 'Netherite Leggings', tex: 'item/netherite_leggings', model: 'generated', type: 'armor',
    stack: 1, rarity: 'common', slot: 'legs',
  },
  netherite_boots: {
    name: 'Netherite Boots', tex: 'item/netherite_boots', model: 'generated', type: 'armor',
    stack: 1, rarity: 'common', slot: 'feet',
  },
};

// 装備として描画するときの防具素材(textures/entity/equipment/humanoid/<material>.png)
MC.ARMOR_MATERIAL = { netherite_helmet: 'netherite', netherite_chestplate: 'netherite', netherite_leggings: 'netherite', netherite_boots: 'netherite' };

MC.RARITY_COLOR = { common: '#FFFFFF', uncommon: '#FFFF55', rare: '#55FFFF', epic: '#FF55FF' };

MC.Item = {
  make(id, count) { return { id, count: count || 1 }; },
  def(stack) { return stack ? MC.ITEMS[stack.id] : null; },
  max(id) { return MC.ITEMS[id].stack; },
  /** 表示名の色(エンチャント付きはレアリティが1段階上がる) */
  color(stack) {
    const d = MC.ITEMS[stack.id];
    let r = d.rarity || 'common';
    if (d.enchants && (r === 'common' || r === 'uncommon')) r = 'rare';
    return MC.RARITY_COLOR[r];
  },
  roman(n) { return ['', 'I', 'II', 'III', 'IV', 'V'][n] || String(n); },
  /** ツールチップ行 [ [text,color], ... ] */
  tooltip(stack) {
    const d = MC.ITEMS[stack.id];
    const lines = [[d.name, MC.Item.color(stack)]];
    if (d.enchants) for (const [n, l] of d.enchants) lines.push([n + ' ' + MC.Item.roman(l), '#AAAAAA']);
    if (d.lines) for (const t of d.lines()) lines.push([t, '#AAAAAA']);
    return lines;
  },
};
