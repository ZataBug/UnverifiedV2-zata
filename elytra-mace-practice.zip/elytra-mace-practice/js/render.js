'use strict';
// ================================================================
//  描画: メインシーン / 一人称の手 / インベントリのプレビュー
// ================================================================
MC.Render = {
  fovCur: 70,

  init(canvas) {
    const G = MC.Game;
    this.glCanvas = canvas;
    const r = this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    r.setSize(window.innerWidth, window.innerHeight, false);
    r.outputEncoding = THREE.LinearEncoding;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x78a7ff);
    this.camera = new THREE.PerspectiveCamera(MC.CFG.fov, window.innerWidth / window.innerHeight, 0.05, 1500);
    this.camera.rotation.order = 'YXZ';

    G.world.build(this.scene);
    MC.Particles.init(this.scene);

    // NPC
    const npc = this.npcModel = new MC.Models.Humanoid('entity/player/wide/kai');
    npc.setEquipment({ head: MC.Item.make('netherite_helmet'), chest: MC.Item.make('netherite_chestplate'), legs: MC.Item.make('netherite_leggings'), feet: MC.Item.make('netherite_boots') });
    this.scene.add(npc.root);
    this.npcTag = this.makeHealthTag(); this.scene.add(this.npcTag.spr);
    this.playerTag = this.makeHealthTag(); this.scene.add(this.playerTag.spr);

    this.spriteMap = new Map();
    this.eyeCur = MC.CFG.eyeHeight;
    // 三人称用の自分のモデル
    this.playerGroup = new THREE.Group(); this.playerGroup.rotation.order = 'YXZ';
    this.playerModel = new MC.Models.Humanoid('entity/player/wide/steve');
    this.playerGroup.add(this.playerModel.root); this.playerGroup.visible = false;
    this.scene.add(this.playerGroup);
    this.pmDirty = true;
    this.initHitboxes();
    this.initWindCharge();
    this.Hand.init(this);
    this.Preview.init();
    MC.Preview = this.Preview;
  },

  /** PvPサーバー風のヘルスネームタグ: [剣] ランク | 名前  /  体力 ♥ */
  makeHealthTag() {
    const canvas = document.createElement('canvas');
    const tex = new THREE.CanvasTexture(canvas); tex.magFilter = tex.minFilter = THREE.NearestFilter; tex.generateMipmaps = false;
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
    return { spr, canvas, tex, key: '', w: 1, h: 1 };
  },
  updateHealthTag(tag, rank, name, hp, absorb, x, y, z, visible) {
    tag.spr.visible = !!visible;
    if (!visible) return;
    const total = Math.max(0, Math.ceil(hp + absorb));
    const key = rank + '|' + name + '|' + total + '|' + (absorb > 0 ? 1 : 0);
    if (key !== tag.key) {
      tag.key = key;
      const F = MC.Font, S = 4;                       // 1フォントpx = 4キャンバスpx
      const sword = MC.Assets.image('item/netherite_sword');
      const heart = MC.Assets.image('gui/sprites/hud/' + (absorb > 0 ? 'heart/absorbing_full' : 'heart/full'));
      const l1 = (rank ? F.width(rank + ' ') : 0) + F.width('| ') + F.width(name);
      const hpTxt = String(total);
      const w1 = 10 + l1, w2 = F.width(hpTxt) * 2 + 3 + 14;
      const W = Math.ceil(Math.max(w1, w2)) + 6, H = 34;
      const c = tag.canvas; c.width = W * S; c.height = H * S;
      const x2 = c.getContext('2d'); x2.imageSmoothingEnabled = false;
      x2.setTransform(S, 0, 0, S, 0, 0);
      const outline = (txt, tx, ty, color, sc) => {
        x2.save(); x2.translate(tx, ty); x2.scale(sc, sc);
        for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) F._run(x2, txt, dx * 0.7, dy * 0.7, '#000000');
        F._run(x2, txt, 0, 0, color);
        x2.restore();
      };
      // 1行目: 剣アイコン + ランク(オレンジ) + | + 名前
      let tx = Math.floor((W - w1) / 2) + 1;
      x2.drawImage(sword, tx, 1, 9, 9); tx += 10;
      if (rank) { outline(rank + ' ', tx, 2, '#FFAA00', 1); tx += F.width(rank + ' '); }
      outline('| ', tx, 2, '#FFFFFF', 1); tx += F.width('| ');
      outline(name, tx, 2, '#FFFFFF', 1);
      // 2行目: 大きな体力数値 + ハート
      let hx = Math.floor((W - w2) / 2) + 1;
      outline(hpTxt, hx, 13, '#FFFFFF', 2); hx += F.width(hpTxt) * 2 + 3;
      x2.drawImage(heart, hx, 14, 13, 13);
      tag.w = W; tag.h = H; tag.tex.needsUpdate = true;
      tag.spr.scale.set(W * 0.03, H * 0.03, 1);
    }
    tag.spr.position.set(x, y + 0.35 + tag.h * 0.03 / 2, z);
  },

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.Hand.camera.aspect = w / h; this.Hand.camera.updateProjectionMatrix();
  },

  syncEquipment() { this.Preview.dirty = true; this.pmDirty = true; },

  // ---------------------------------------------------------- ヒットボックス
  initHitboxes() {
    this.hbEdges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 1));
    this.hbGroup = new THREE.Group(); this.scene.add(this.hbGroup);
    const mkBox = (color) => { const m = new THREE.LineSegments(this.hbEdges, new THREE.LineBasicMaterial({ color })); m.renderOrder = 20; this.hbGroup.add(m); return m; };
    const lg = new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 1], 3));
    const mkLine = (color) => { const m = new THREE.Line(lg, new THREE.LineBasicMaterial({ color })); m.renderOrder = 20; this.hbGroup.add(m); return m; };
    this.hb = {
      mkBox,
      npcBox: mkBox(0xffffff), npcEye: mkBox(0xff2020), npcLook: mkLine(0x4060ff),
      pBox: mkBox(0xffffff), pEye: mkBox(0xff2020), pLook: mkLine(0x4060ff),
    };
  },
  setBox(m, cx, y0, cz, hw, h) { m.position.set(cx, y0 + h / 2, cz); m.scale.set(hw * 2, h, hw * 2); },
  setLook(m, x, y, z, dx, dy, dz, len) { m.position.set(x, y, z); m.lookAt(x + dx, y + dy, z + dz); m.scale.set(1, 1, len); },

  // ---------------------------------------------------------- ウィンドチャージ(3D)
  initWindCharge() {
    const im = MC.Assets.image('entity/projectiles/wind_charge');
    const crop = (y, h) => {
      const c = document.createElement('canvas'); c.width = 64; c.height = h;
      c.getContext('2d').drawImage(im, 0, y, 64, h, 0, 0, 64, h);
      const t = new THREE.CanvasTexture(c); t.magFilter = t.minFilter = THREE.NearestFilter; t.generateMipmaps = false;
      t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
    };
    this.wcCoreTex = crop(0, 8); this.wcWindTex = crop(8, 24);
  },
  makeWindCharge() {
    const g = new THREE.Group();
    const mat = (tex) => new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.DoubleSide });
    const core = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2), new THREE.MeshBasicMaterial({ color: 0xdfe8ff, transparent: true, opacity: 0.9 }));
    const shell = new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.27, 0.27), mat(this.wcCoreTex));
    const w1 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), mat(this.wcWindTex));
    const w2 = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.36, 0.36), mat(this.wcWindTex));
    g.add(core, shell, w1, w2);
    g.userData = { w1, w2, core, shell };
    return g;
  },

  projectileSprite(p) {
    let s = this.spriteMap.get(p);
    if (!s) {
      if (p.kind === 'wind') s = this.makeWindCharge();
      else {
        const tex = MC.Assets.tex('item/ender_pearl');
        s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, alphaTest: 0.1 }));
        s.scale.set(0.5, 0.5, 1);
      }
      s.userData.hb = this.hb.mkBox(0xffffff);
      this.scene.add(s); this.spriteMap.set(p, s);
    }
    return s;
  },

  /** 毎フレーム */
  frame(dt, alpha) {
    const G = MC.Game, P = G.P, N = G.N, cam = this.camera, L = MC.lerp;
    // カメラ(被ダメ時の画面揺れ・ダッシュ時のFOV変化は無し)
    this.eyeCur += (G.eyeOff(P) - this.eyeCur) * Math.min(1, dt * 14);
    const ex = L(P.px, P.x, alpha), eyBase = L(P.py, P.y, alpha), ez = L(P.pz, P.z, alpha);
    const ey = eyBase + this.eyeCur;
    const fwd = G.look(P);
    if (G.thirdPerson) cam.position.set(ex - fwd.x * 4, Math.max(0.3, ey - fwd.y * 4), ez - fwd.z * 4);
    else cam.position.set(ex, ey, ez);
    cam.rotation.set(P.pitch, P.yaw, 0);
    if (Math.abs(cam.fov - MC.CFG.fov) > 0.01) { cam.fov = MC.CFG.fov; cam.updateProjectionMatrix(); }
    MC.Snd.setListener({ x: ex, y: ey, z: ez }, fwd);
    G.world.updateBorder(P.x, P.z);

    // エリトラ音
    if (G.elytraLoop) {
      const f = P.vx * P.vx + P.vy * P.vy + P.vz * P.vz;
      const vol = f >= 1e-7 ? MC.clamp(f / 4, 0, 1) : 0;
      G.elytraLoop.set(vol, vol > 0.8 ? 1 + (vol - 0.8) : 1);
    }

    // NPC
    const m = this.npcModel;
    m.root.position.set(L(N.px, N.x, alpha), L(N.py, N.y, alpha), L(N.pz, N.z, alpha));
    m.root.rotation.y = N.rotY;
    const ndx = P.x - N.x, ndz = P.z - N.z, nd = Math.hypot(ndx, ndz) || 1;
    m.head.rotation.x = -Math.atan2((G.eyeY(P) - (N.y + 1.62)), nd) * 0.9;
    m.animate(N.limb, L(N.prevLimbAmt, N.limbAmt, alpha));
    if (N.swingT > 0) m.rArm.rotation.x = -Math.sin((6 - N.swingT) / 6 * Math.PI) * 1.6;
    if (N.hurtTime > 0) m.setTint(1, 0.4, 0.4); else m.setTint(1, 1, 1);
    m.root.visible = !N.dead;
    // 手に持つ物と腕の動き(食事中は金リンゴを顔の前に)
    m.setHeld(N.eatT > 0 ? MC.ITEMS.golden_apple : MC.ITEMS.netherite_sword);
    if (N.eatT > 0) m.rArm.rotation.x = -1.35 + Math.sin(N.eatT * 1.3) * 0.08;
    this.updateHealthTag(this.npcTag, MC.CFG.botRank, MC.CFG.botName, N.hp, N.absorb, m.root.position.x, m.root.position.y + 1.85, m.root.position.z, MC.CFG.showNametag && !N.dead);
    this.updateHealthTag(this.playerTag, '', 'You', P.hp, G.absorption, ex, eyBase + 1.85, ez, MC.CFG.showNametag && G.thirdPerson);

    // 三人称: 自分のモデル
    const pg = this.playerGroup, pm = this.playerModel;
    pg.visible = !!G.thirdPerson;
    if (G.thirdPerson) {
      if (this.pmDirty) { pm.setEquipment(MC.Inventory.equipment()); this.pmDirty = false; }
      const px = ex, py = eyBase;
      if (P.gliding) {
        pg.position.set(px, py + 0.3, ez); pm.root.position.y = -1.05;
        pg.rotation.set(Math.PI / 2 - P.pitch, P.yaw + Math.PI, 0);
        pm.setWingPose(1); pm.head.rotation.x = 0; pm.animate(0, 0);
      } else {
        pg.position.set(px, py, ez); pm.root.position.y = 0;
        pg.rotation.set(0, P.yaw + Math.PI, 0);
        pm.setWingPose(0); pm.head.rotation.x = -P.pitch; pm.animate(P.limb, L(P.prevLimbAmt, P.limbAmt, alpha));
      }
    }

    // ヒットボックス(白=当たり判定 / 赤=目の高さ / 青=視線)
    const hb = this.hb, showHb = !!MC.CFG.showHitbox;
    this.hbGroup.visible = showHb;
    if (showHb) {
      const nx = m.root.position.x, ny = m.root.position.y, nz = m.root.position.z;
      this.setBox(hb.npcBox, nx, ny, nz, N.hw, N.h);
      this.setBox(hb.npcEye, nx, ny + 1.62 - 0.005, nz, N.hw, 0.01);
      const nl = Math.cos(m.head.rotation.x);
      this.setLook(hb.npcLook, nx, ny + 1.62, nz, Math.sin(N.rotY) * nl, -Math.sin(m.head.rotation.x), Math.cos(N.rotY) * nl, 2);
      hb.pBox.visible = hb.pEye.visible = hb.pLook.visible = !!G.thirdPerson;
      if (G.thirdPerson) {
        this.setBox(hb.pBox, ex, eyBase, ez, P.hw, P.h);
        this.setBox(hb.pEye, ex, eyBase + G.eyeOff(P) - 0.005, ez, P.hw, 0.01);
        this.setLook(hb.pLook, ex, eyBase + G.eyeOff(P), ez, fwd.x, fwd.y, fwd.z, 2);
      }
    }

    // 飛び道具
    const alive = new Set(G.projs);
    for (const [p, s] of this.spriteMap) if (!alive.has(p)) { this.scene.remove(s); this.hbGroup.remove(s.userData.hb); this.spriteMap.delete(p); }
    for (const p of G.projs) {
      const s = this.projectileSprite(p);
      const x = L(p.px, p.x, alpha), y = L(p.py, p.y, alpha), z = L(p.pz, p.z, alpha);
      s.position.set(x, y, z);
      const hs = p.kind === 'pearl' ? 0.25 : 0.3125;
      s.userData.hb.visible = !!MC.CFG.showHitbox;
      this.setBox(s.userData.hb, x, y - hs / 2, z, hs / 2, hs);
      if (p.kind === 'wind') {
        const u = s.userData, t = performance.now() / 1000;
        s.rotation.set(t * 3, t * 5, 0); u.w1.rotation.set(0, t * 6, 0); u.w2.rotation.set(0, -t * 7, t * 2);
      }
    }
    // 風の筋をスクロール
    { const t = performance.now() / 1000; this.wcWindTex.offset.set((t * 1.5) % 1, (-t * 0.8) % 1); this.wcCoreTex.offset.set((t * 0.6) % 1, 0); }

    MC.Particles.update(dt, G.world);

    const r = this.renderer;
    r.autoClear = true;
    r.render(this.scene, cam);
    // 手(深度を消して上から描く)
    if (MC.GUI.screen !== 'start' && !G.thirdPerson) {
      r.autoClear = false; r.clearDepth();
      this.Hand.render(alpha, dt);
      r.autoClear = true;
    }
  },
};

// ================================================================
//  一人称の手 / 手持ちアイテム(ItemInHandRendererの再現)
// ================================================================
MC.Render.Hand = {
  height: 1, oHeight: 1, shownKey: null, shownStack: null, meshes: {},

  init() {
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(MC.CFG.fov, window.innerWidth / window.innerHeight, 0.01, 10);
    this.root = new THREE.Group(); this.root.matrixAutoUpdate = false;
    this.scene.add(this.root);
    // 素手用の腕
    const A = MC.Assets;
    const mat = new THREE.MeshBasicMaterial({ map: A.tex('entity/player/wide/steve'), vertexColors: true, alphaTest: 0.5 });
    this.arm = new THREE.Group();
    const geo = MC.Models.boxGeo(4, 12, 4, 40, 16, 64, 64);
    const am = new THREE.Mesh(geo, mat); am.position.set(0, -6 / 16, 0);
    const sleeve = new THREE.Mesh(MC.Models.boxGeo(4, 12, 4, 40, 32, 64, 64, 0.25), mat); sleeve.position.copy(am.position);
    this.arm.add(am, sleeve);
    this.root.add(this.arm); this.arm.visible = false;
    const held = MC.Inventory.held();
    this.shownKey = held ? MC.Inventory.selected + ':' + held.id : '-';
    this.shownStack = held;
  },

  getMesh(def) {
    const key = def.name;
    if (!this.meshes[key]) {
      const g = MC.Models.itemMesh(def);
      const wrap = new THREE.Group(); wrap.matrixAutoUpdate = false;
      wrap.matrix.copy(MC.Models.displayMatrix(def.model));
      wrap.add(g); wrap.userData.glint = g.userData.glint;
      wrap.visible = false;
      this.root.add(wrap);
      this.meshes[key] = wrap;
    }
    return this.meshes[key];
  },

  /** ゲームtickごと */
  tick() {
    const G = MC.Game, inv = MC.Inventory;
    const held = inv.held();
    const key = held ? inv.selected + ':' + held.id : '-';
    const reequip = key !== this.shownKey;
    const f = G.attackStrength(0);
    const target = reequip ? 0 : f * f * f;
    this.oHeight = this.height;
    this.height += MC.clamp(target - this.height, -0.4, 0.4);
    if (this.height < 0.1) { this.shownKey = key; this.shownStack = held; }
  },

  render(alpha, dt) {
    const G = MC.Game, cfg = MC.CFG;
    const cam = this.camera;
    if (Math.abs(cam.fov - cfg.fov) > 0.01) { cam.fov = cfg.fov; cam.updateProjectionMatrix(); }
    for (const k in this.meshes) this.meshes[k].visible = false;
    this.arm.visible = false;
    const st = this.shownStack;
    const e = 1 - MC.lerp(this.oHeight, this.height, alpha);       // 0=上がりきった状態
    const p = G.swinging ? (G.swingTicks + alpha) / 6 : 0;
    const M = new THREE.Matrix4();
    const T = (x, y, z) => M.multiply(new THREE.Matrix4().makeTranslation(x, y, z));
    const RX = d => M.multiply(new THREE.Matrix4().makeRotationX(d * MC.DEG));
    const RY = d => M.multiply(new THREE.Matrix4().makeRotationY(d * MC.DEG));
    const RZ = d => M.multiply(new THREE.Matrix4().makeRotationZ(d * MC.DEG));
    const side = 1;
    const def = st ? MC.ITEMS[st.id] : null;
    const sq = Math.sqrt(p);
    const t = performance.now() / 1000;

    if (!st) {
      // 素手(腕)
      const g = -0.3 * Math.sin(sq * Math.PI), h = 0.4 * Math.sin(sq * Math.PI * 2), i = -0.4 * Math.sin(p * Math.PI);
      T(side * (g + 0.64), h - 0.6 + e * -0.6, i - 0.72);
      RY(side * 45);
      const j = Math.sin(p * p * Math.PI), k = Math.sin(sq * Math.PI);
      RY(side * k * 70); RZ(side * j * -20);
      RY(-10); RX(100);
      T(0, 0.02, 0.05);
      this.root.matrix.copy(M); this.root.matrixWorldNeedsUpdate = true;
      this.arm.visible = true;
      this.arm.matrixAutoUpdate = true;
    } else {
      const mesh = this.getMesh(def);
      mesh.visible = true;
      if (mesh.userData.glint) { mesh.userData.glint.offset.set((t / 3) % 1, (t / 4.5) % 1); }
      const using = (G.eating > 0 && def.type === 'food');
      if (using) {
        // 食事アニメーション
        const total = MC.CFG.eatTicks;
        const f = total - G.eating - alpha + 1, gg = f / total;
        if (gg < 0.8) T(0, Math.abs(Math.cos(f / 4 * Math.PI) * 0.1), 0);
        const hh = 1 - Math.pow(Math.max(0, gg), 27);
        T(hh * 0.6 * side, hh * -0.5, 0);
        RY(side * hh * 90); RX(hh * 10); RZ(side * hh * 30);
      } else {
        const gx = -0.4 * Math.sin(sq * Math.PI), hy = 0.2 * Math.sin(sq * Math.PI * 2), iz = -0.2 * Math.sin(p * Math.PI);
        T(side * gx, hy, iz);
      }
      T(side * 0.56, -0.52 + e * -0.6, -0.72);
      if (!using) {
        const f = Math.sin(p * p * Math.PI), g2 = Math.sin(sq * Math.PI);
        RY(side * (45 + f * -20));
        RZ(side * g2 * -20);
        RX(g2 * -80);
        RY(side * -45);
        if (def.type === 'spear') T(0, 0, -0.9 * Math.sin(p * Math.PI));
      }
      if (def.type === 'spear' && G.spearCharge > 0) {
        const c = Math.min(1, G.spearCharge / 10);
        T(-0.1 * c, 0.1 * c, 0.15 * c); RX(-10 * c);
      }
      this.root.matrix.copy(M);
    }
    if (!st) { this.arm.updateMatrix(); }
    this.root.updateMatrixWorld(true);
    MC.Render.renderer.render(this.scene, this.camera);
  },
};

// ================================================================
//  インベントリ内のプレイヤー表示
// ================================================================
MC.Render.Preview = {
  init() {
    const r = this.renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, preserveDrawingBuffer: true });
    r.setClearColor(0x000000, 0);
    this.scene = new THREE.Scene();
    this.model = new MC.Models.Humanoid('entity/player/wide/steve');
    this.scene.add(this.model.root);
    const w = 49 / 30 / 2;
    this.camera = new THREE.OrthographicCamera(-w, w, 64 / 30, -6 / 30, 0.1, 20);
    this.camera.position.set(0, 0, 5); this.camera.lookAt(0, 0, 0);
    this.size = 0;
    this.dirty = true;
  },
  render(dx, dy) {
    const G = MC.GUI;
    const pw = Math.round(49 * G.pxScale), ph = Math.round(70 * G.pxScale);
    if (this.size !== pw) { this.renderer.setPixelRatio(1); this.renderer.setSize(pw, ph, false); this.size = pw; }
    const m = this.model;
    m.setEquipment(MC.Inventory.equipment());
    const f = Math.atan(dx / 40), g = Math.atan(dy / 40);
    m.root.rotation.y = f * 20 * MC.DEG * 1.0;
    m.head.rotation.x = g * 20 * MC.DEG;
    m.root.rotation.x = 0;
    this.renderer.render(this.scene, this.camera);
    return this.renderer.domElement;
  },
};
